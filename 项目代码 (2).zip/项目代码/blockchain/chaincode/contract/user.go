package contract

import (
	"encoding/json"
	"fmt"
	"math"
	"time"

	"github.com/hyperledger/fabric-contract-api-go/contractapi"
)

// 用户的增删改查
// 传入ID、姓名、用户类型、余额
func (s *SmartContract) CreateUser(ctx contractapi.TransactionContextInterface, id string, name string, userType string, balance int) error {
	createTime := time.Now().In(time.FixedZone("CST", 8*3600)).Format("2006-01-02 15:04:05")
	user := User{
		ID:              id,
		Name:            name,
		UserType:        userType,
		Balance:         balance,
		CreateTime:      createTime,
		AssetList:       []string{},
		StakedAmount:    0,
		IsStaked:        false,
		ReputationScore: 5.0, // 初始信誉分
		RatingCount:     0,
		TotalRating:     0,
		PenaltyCount:    0,
		LastUpdateTime:  createTime,
		StakeRecords:    []StakeRecord{},
		BalanceRecords:  []BalanceRecord{},
	}
	// 如果初始余额非零，记录初始余额流水
	if balance > 0 {
		user.BalanceRecords = append(user.BalanceRecords, BalanceRecord{
			ID:           fmt.Sprintf("bl_%s_%s", id, createTime),
			UserID:       id,
			Amount:       balance,
			BalanceAfter: balance,
			Type:         "admin_recharge",
			Description:  fmt.Sprintf("账户创建，初始余额 %d", balance),
			RelatedTxID:  "init",
			Time:         createTime,
		})
	}
	userJSON, err := json.Marshal(user)
	if err != nil {
		return err
	}
	return ctx.GetStub().PutState(id, userJSON)
}

// 查询用户信息
// 传入ID
// 返回用户信息
func (s *SmartContract) ReadUser(ctx contractapi.TransactionContextInterface, user_id string) (*User, error) {
	userJSON, err := ctx.GetStub().GetState(user_id)
	if err != nil {
		return nil, err
	}
	if userJSON == nil {
		return nil, nil
	}
	var user User
	err = json.Unmarshal(userJSON, &user)
	if err != nil {
		return nil, err
	}
	return &user, nil
}

// 查询用户余额
// 传入ID
// 返回用户余额
func (s *SmartContract) GetUserBalance(ctx contractapi.TransactionContextInterface, user_id string) (int, error) {
	userJSON, err := ctx.GetStub().GetState(user_id)
	if err != nil {
		return 0, err
	}
	if userJSON == nil {
		return 0, nil
	}
	var user User
	err = json.Unmarshal(userJSON, &user)
	if err != nil {
		return 0, err
	}
	return user.Balance, nil
}

// 更新用户信息
// 传入ID、姓名、用户类型、余额
func (s *SmartContract) UpdateUser(ctx contractapi.TransactionContextInterface, id string, name string, userType string, balance int) error {
	user, err := s.ReadUser(ctx, id)
	if err != nil {
		return err
	}
	if user == nil {
		return err
	}

	// 计算余额变化
	oldBalance := user.Balance
	balanceChange := balance - oldBalance

	user.Name = name
	user.UserType = userType
	user.Balance = balance

	// 记录管理员修改余额的流水
	updateTime := time.Now().In(time.FixedZone("CST", 8*3600)).Format("2006-01-02 15:04:05")
	recordType := "admin_modify"
	description := fmt.Sprintf("管理员修改余额，从 %d 变更为 %d，变动 %d", oldBalance, balance, balanceChange)
	if balanceChange > 0 {
		recordType = "admin_recharge"
		description = fmt.Sprintf("管理员充值 %d，余额从 %d 变更为 %d", balanceChange, oldBalance, balance)
	}
	user.BalanceRecords = append(user.BalanceRecords, BalanceRecord{
		ID:           fmt.Sprintf("bl_%s_%s", id, updateTime),
		UserID:       id,
		Amount:       balanceChange,
		BalanceAfter: balance,
		Type:         recordType,
		Description:  description,
		RelatedTxID:  "admin",
		Time:         updateTime,
	})

	userJSON, err := json.Marshal(user)
	if err != nil {
		return err
	}
	return ctx.GetStub().PutState(id, userJSON)
}

// 删除用户信息
// 传入ID
func (s *SmartContract) DeleteUser(ctx contractapi.TransactionContextInterface, id string) error {
	return ctx.GetStub().DelState(id)
}

// 获取用户类型
// 传入ID
func (s *SmartContract) GetUserType(ctx contractapi.TransactionContextInterface, user_id string) (string, error) {
	user, err := s.ReadUser(ctx, user_id)
	if err != nil {
		return "", err
	}
	if user == nil {
		return "", nil
	}
	return user.UserType, nil
}

// 查询所有用户信息
func (s *SmartContract) GetAllUsers(ctx contractapi.TransactionContextInterface) ([]*User, error) {
	resultsIterator, err := ctx.GetStub().GetStateByRange("", "")
	if err != nil {
		return nil, fmt.Errorf("failed to get state by range: %v", err)
	}
	defer resultsIterator.Close()

	var userList []*User

	for resultsIterator.HasNext() {
		queryResponse, err := resultsIterator.Next()
		if err != nil {
			return nil, fmt.Errorf("failed to iterate results: %v", err)
		}

		// 先检查是否是有效的 JSON
		if !json.Valid(queryResponse.Value) {
			continue // 跳过无效 JSON
		}

		var user User
		err = json.Unmarshal(queryResponse.Value, &user)
		if err != nil || user.UserType == "" { // 仅保留有效的 Asset
			continue
		}

		userList = append(userList, &user)
	}

	return userList, nil
}

// 质押代币
// 传入用户ID，固定质押100代币
func (s *SmartContract) StakeTokens(ctx contractapi.TransactionContextInterface, userID string) error {
	user, err := s.ReadUser(ctx, userID)
	if err != nil {
		return err
	}
	if user == nil {
		return fmt.Errorf("user not found")
	}

	// 检查用户类型，管理员和监督审查者不需要质押
	if user.UserType == "管理员" || user.UserType == "监督审查者" {
		return fmt.Errorf("admin and supervisor auditor users do not need to stake")
	}

	// 检查是否已质押
	if user.IsStaked {
		return fmt.Errorf("user already staked")
	}

	// 固定质押金额100代币
	requiredAmount := 100
	if user.Balance < requiredAmount {
		return fmt.Errorf("insufficient balance, need %d tokens", requiredAmount)
	}

	// 更新用户余额和质押状态
	user.Balance -= requiredAmount
	user.StakedAmount = requiredAmount
	user.IsStaked = true

	// 创建质押记录
	stakeTime := time.Now().In(time.FixedZone("CST", 8*3600)).Format("2006-01-02 15:04:05")
	txID := ctx.GetStub().GetTxID()
	stakeRecord := StakeRecord{
		ID:     fmt.Sprintf("stake_%s_%s", userID, stakeTime),
		UserID: userID,
		Amount: requiredAmount,
		Action: "stake",
		Time:   stakeTime,
		TxID:   txID,
	}

	user.StakeRecords = append(user.StakeRecords, stakeRecord)

	// 记录余额变动流水
	user.BalanceRecords = append(user.BalanceRecords, BalanceRecord{
		ID:           fmt.Sprintf("bl_%s_%s", userID, stakeTime),
		UserID:       userID,
		Amount:       -requiredAmount,
		BalanceAfter: user.Balance,
		Type:         "stake",
		Description:  fmt.Sprintf("质押 %d 代币", requiredAmount),
		RelatedTxID:  txID,
		Time:         stakeTime,
	})

	// 保存更新后的用户
	userJSON, err := json.Marshal(user)
	if err != nil {
		return err
	}

	return ctx.GetStub().PutState(userID, userJSON)
}

// 解押代币
// 传入用户ID，解押全部质押金额
func (s *SmartContract) UnstakeTokens(ctx contractapi.TransactionContextInterface, userID string) error {
	user, err := s.ReadUser(ctx, userID)
	if err != nil {
		return err
	}
	if user == nil {
		return fmt.Errorf("user not found")
	}

	// 检查是否已质押
	if !user.IsStaked || user.StakedAmount == 0 {
		return fmt.Errorf("user has no stake to unstake")
	}

	// 检查是否有未完成的争议或惩罚（简化版本，以后可以扩展）
	if user.PenaltyCount > 0 {
		return fmt.Errorf("cannot unstake while having penalties")
	}

	// 返还质押金额
	unstakeAmount := user.StakedAmount
	user.Balance += unstakeAmount
	user.StakedAmount = 0
	user.IsStaked = false

	// 创建解押记录
	unstakeTime := time.Now().In(time.FixedZone("CST", 8*3600)).Format("2006-01-02 15:04:05")
	txID := ctx.GetStub().GetTxID()
	unstakeRecord := StakeRecord{
		ID:     fmt.Sprintf("unstake_%s_%s", userID, unstakeTime),
		UserID: userID,
		Amount: unstakeAmount,
		Action: "unstake",
		Time:   unstakeTime,
		TxID:   txID,
	}

	user.StakeRecords = append(user.StakeRecords, unstakeRecord)

	// 记录余额变动流水
	user.BalanceRecords = append(user.BalanceRecords, BalanceRecord{
		ID:           fmt.Sprintf("bl_%s_%s", userID, unstakeTime),
		UserID:       userID,
		Amount:       unstakeAmount,
		BalanceAfter: user.Balance,
		Type:         "unstake",
		Description:  fmt.Sprintf("解押 %d 代币", unstakeAmount),
		RelatedTxID:  txID,
		Time:         unstakeTime,
	})

	// 保存更新后的用户
	userJSON, err := json.Marshal(user)
	if err != nil {
		return err
	}

	return ctx.GetStub().PutState(userID, userJSON)
}

// 检查质押状态
// 返回 "true" 或 "false"
func (s *SmartContract) CheckStakeStatus(ctx contractapi.TransactionContextInterface, userID string) (string, error) {
	user, err := s.ReadUser(ctx, userID)
	if err != nil {
		return "false", err
	}
	if user == nil {
		return "false", nil
	}

	// 管理员和监督审查者用户自动返回true（不需要质押）
	if user.UserType == "管理员" || user.UserType == "监督审查者" {
		return "true", nil
	}

	if user.IsStaked && user.StakedAmount >= 100 {
		return "true", nil
	}

	return "false", nil
}

// 获取质押记录
func (s *SmartContract) GetStakeRecords(ctx contractapi.TransactionContextInterface, userID string) ([]StakeRecord, error) {
	user, err := s.ReadUser(ctx, userID)
	if err != nil {
		return nil, err
	}
	if user == nil {
		return nil, fmt.Errorf("user not found")
	}

	return user.StakeRecords, nil
}

// 获取用户信誉分
func (s *SmartContract) GetReputation(ctx contractapi.TransactionContextInterface, userID string) (float64, error) {
	user, err := s.ReadUser(ctx, userID)
	if err != nil {
		return 0.0, err
	}
	if user == nil {
		return 0.0, fmt.Errorf("user not found")
	}

	return user.ReputationScore, nil
}

// 更新用户信誉分（基于新评分）
func (s *SmartContract) UpdateReputation(ctx contractapi.TransactionContextInterface, sellerID string, rating int) error {
	user, err := s.ReadUser(ctx, sellerID)
	if err != nil {
		return err
	}
	if user == nil {
		return fmt.Errorf("user not found")
	}

	// 验证评分范围（1-10）
	if rating < 1 || rating > 10 {
		return fmt.Errorf("rating must be between 1 and 10")
	}

	// 更新评分统计（保持向后兼容）
	user.RatingCount++
	user.TotalRating += rating

	// 计算新的信誉分（基于新算法）
	newReputation, err := s.calculateNewReputationScore(ctx, user)
	if err != nil {
		return fmt.Errorf("failed to calculate new reputation score: %v", err)
	}

	// 更新信誉分和最后更新时间
	user.ReputationScore = newReputation
	user.LastUpdateTime = time.Now().In(time.FixedZone("CST", 8*3600)).Format("2006-01-02 15:04:05")

	// 保存更新后的用户
	userJSON, err := json.Marshal(user)
	if err != nil {
		return err
	}

	return ctx.GetStub().PutState(sellerID, userJSON)
}

// 计算信誉分（私有辅助函数）
func (s *SmartContract) calculateReputationScore(user *User, newRating int) float64 {
	// 基础分
	baseScore := 5.0

	// 评分影响：加权平均
	// 最近评分权重更高，高价值交易权重更高（这里简化处理）
	var ratingImpact float64
	if user.RatingCount > 0 {
		averageRating := float64(user.TotalRating) / float64(user.RatingCount)
		// 加权：新评分占更高权重（30%）
		weightedAverage := (averageRating*0.7 + float64(newRating)*0.3)
		ratingImpact = (weightedAverage - 5.0) / 5.0 // 归一化到[-1, 1]范围
	} else {
		ratingImpact = (float64(newRating) - 5.0) / 5.0
	}

	// 惩罚影响：每次惩罚扣1分
	penaltyImpact := float64(user.PenaltyCount) * 1.0

	// 时间衰减：每月衰减0.1分
	timeDecay := s.calculateTimeDecay(user.LastUpdateTime)

	// 计算最终信誉分
	reputation := baseScore + ratingImpact*2.0 - penaltyImpact - timeDecay

	// 确保在0-10范围内
	reputation = math.Max(0.0, math.Min(10.0, reputation))

	return reputation
}

// 计算时间衰减
func (s *SmartContract) calculateTimeDecay(lastUpdateTime string) float64 {
	// 解析时间
	layout := "2006-01-02 15:04:05"
	lastTime, err := time.Parse(layout, lastUpdateTime)
	if err != nil {
		return 0.0
	}

	// 计算与当前时间的月份差
	now := time.Now()
	monthsDiff := (now.Year()-lastTime.Year())*12 + int(now.Month()) - int(lastTime.Month())

	// 每月衰减0.1分
	return float64(monthsDiff) * 0.1
}

// getSellerRatings 获取卖家收到的所有评分记录
func (s *SmartContract) getSellerRatings(ctx contractapi.TransactionContextInterface, sellerID string) ([]RatingRecord, error) {
	// 获取所有资产
	allAssets, err := s.GetAllAssets(ctx)
	if err != nil {
		return nil, err
	}

	var sellerRatings []RatingRecord

	// 遍历所有资产，收集该卖家的评分记录
	for _, asset := range allAssets {
		for _, rating := range asset.Ratings {
			// 检查评分是否属于该卖家
			if rating.SellerID == sellerID {
				// 复制rating并添加时间差信息（我们稍后计算）
				sellerRatings = append(sellerRatings, rating)
			}
		}
	}

	return sellerRatings, nil
}

// calculateNewReputationScore 计算新的信誉分（基于新算法）
func (s *SmartContract) calculateNewReputationScore(ctx contractapi.TransactionContextInterface, seller *User) (float64, error) {
	// 获取卖家所有评分记录
	ratings, err := s.getSellerRatings(ctx, seller.ID)
	if err != nil {
		return 0.0, err
	}

	// 如果没有评分记录，返回当前信誉分或默认值
	if len(ratings) == 0 {
		return seller.ReputationScore, nil
	}

	now := time.Now()
	var weightedSum float64
	var totalWeight float64

	// 计算加权平均值 Base_Value = Σ (Qqu_current ∗ Weight_i) / Σ (Weight_i)
	for _, rating := range ratings {
		// 获取评分者（买家）的信誉分
		buyerReputation, err := s.GetReputation(ctx, rating.RaterID)
		if err != nil {
			// 如果获取失败，使用默认值5.0
			buyerReputation = 5.0
		}

		// 解析评分时间
		ratingTime, err := time.Parse("2006-01-02 15:04:05", rating.Time)
		if err != nil {
			// 时间解析失败，跳过该评分
			continue
		}

		// 计算时间差（天数）
		deltaT := now.Sub(ratingTime).Hours() / 24.0

		// 计算权重 Weight_i = Buyer_Reputation_Score ∗ exp(−λ ∗ ΔT)
		weight := buyerReputation * math.Exp(-DecayLambda*deltaT)

		// 累加加权和
		weightedSum += float64(rating.Rating) * weight
		totalWeight += weight
	}

	// 计算Base_Value
	if totalWeight <= 0 {
		// 如果所有权重为0，使用简单平均值
		var sum float64
		for _, rating := range ratings {
			sum += float64(rating.Rating)
		}
		return sum / float64(len(ratings)), nil
	}

	baseValue := weightedSum / totalWeight

	// 计算Trend_Factor = Base_Value + Bonus − Penalty
	var trendFactor float64

	if baseValue > StabilityThreshold {
		// 计算奖励因子 Bonus = (Base_Value - StabilityThreshold) * ConsistencyReward
		bonus := (baseValue - StabilityThreshold) * ConsistencyReward
		trendFactor = baseValue + bonus
	} else if baseValue < StabilityThreshold {
		// 计算惩罚因子 Penalty = |Base_Value - StabilityThreshold| * VolatilityPenalty
		penalty := math.Abs(baseValue-StabilityThreshold) * VolatilityPenalty
		trendFactor = baseValue - penalty
	} else {
		// Base_Value等于StabilityThreshold
		trendFactor = baseValue
	}

	// 计算新信誉分 Data_Reputation_new = α ∗ Data_Reputation_old + (1 − α) ∗ Trend_Factor
	oldReputation := seller.ReputationScore
	newReputation := Alpha*oldReputation + (1-Alpha)*trendFactor

	// 确保在0-10范围内
	newReputation = math.Max(0.0, math.Min(10.0, newReputation))

	return newReputation, nil
}

// 添加惩罚记录
func (s *SmartContract) AddPenalty(ctx contractapi.TransactionContextInterface, userID string, reason string) error {
	user, err := s.ReadUser(ctx, userID)
	if err != nil {
		return err
	}
	if user == nil {
		return fmt.Errorf("user not found")
	}

	// 增加惩罚计数
	user.PenaltyCount++

	// 重新计算信誉分（因为惩罚会影响信誉分）
	newReputation, err := s.calculateNewReputationScore(ctx, user)
	if err != nil {
		return fmt.Errorf("failed to calculate new reputation score: %v", err)
	}

	// 应用惩罚影响：每次惩罚扣1分
	penaltyImpact := float64(user.PenaltyCount) * 1.0
	newReputation -= penaltyImpact

	// 确保在0-10范围内
	newReputation = math.Max(0.0, math.Min(10.0, newReputation))

	user.ReputationScore = newReputation
	user.LastUpdateTime = time.Now().In(time.FixedZone("CST", 8*3600)).Format("2006-01-02 15:04:05")

	// 保存更新后的用户
	userJSON, err := json.Marshal(user)
	if err != nil {
		return err
	}

	return ctx.GetStub().PutState(userID, userJSON)
}

// 重新计算用户信誉分（基于所有评分）
func (s *SmartContract) CalculateReputation(ctx contractapi.TransactionContextInterface, userID string) (float64, error) {
	user, err := s.ReadUser(ctx, userID)
	if err != nil {
		return 0.0, err
	}
	if user == nil {
		return 0.0, fmt.Errorf("user not found")
	}

	// 如果没有评分，返回当前信誉分
	if user.RatingCount == 0 {
		return user.ReputationScore, nil
	}

	// 使用新算法重新计算信誉分
	newReputation, err := s.calculateNewReputationScore(ctx, user)
	if err != nil {
		return 0.0, err
	}

	// 更新用户信誉分
	user.ReputationScore = newReputation
	user.LastUpdateTime = time.Now().In(time.FixedZone("CST", 8*3600)).Format("2006-01-02 15:04:05")

	// 保存更新
	userJSON, err := json.Marshal(user)
	if err != nil {
		return 0.0, err
	}

	err = ctx.GetStub().PutState(userID, userJSON)
	if err != nil {
		return 0.0, err
	}

	return newReputation, nil
}
