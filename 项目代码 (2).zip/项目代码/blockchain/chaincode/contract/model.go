package contract

import "github.com/hyperledger/fabric-contract-api-go/contractapi"

type SmartContract struct {
	contractapi.Contract
}

// 用户结构体，包含用户ID、用户名、用户角色、用户余额、用户资产列表
type User struct {
	ID              string          `json:"id"`
	Name            string          `json:"name"`
	UserType        string          `json:"userType"`
	Balance         int             `json:"balance"`
	CreateTime      string          `json:"create_time"`
	AssetList       []string        `json:"asset_list"`
	StakedAmount    int             `json:"staked_amount"`     // 质押金额
	IsStaked        bool            `json:"is_staked"`         // 是否已质押
	ReputationScore float64         `json:"reputation_score"`  // 信誉分（0-10）
	RatingCount     int             `json:"rating_count"`      // 评分次数
	TotalRating     int             `json:"total_rating"`      // 评分总和
	PenaltyCount    int             `json:"penalty_count"`     // 惩罚次数
	LastUpdateTime  string          `json:"last_update_time"`  // 最后更新时间
	StakeRecords    []StakeRecord   `json:"stake_records"`     // 质押记录
	BalanceRecords  []BalanceRecord `json:"balance_records"`   // 余额变动流水
}

// 资产结构体，包含资产ID、资产名称、资产作者、当前持有者、资产详情、资产价格、租借时间
type Asset struct {
	ID           string         `json:"id"`
	Name         string         `json:"name"`
	AssetType    string         `json:"asset_type"`
	Org          string         `json:"org"`
	Detail       string         `json:"detail"`
	Author       string         `json:"author"`
	Sha256       string         `json:"sha256"`
	IPFSHash     string         `json:"ipfs_hash"`
	CurrentOwner string         `json:"current_owner"`
	Price        int            `json:"price"`
	ForSell      bool           `json:"for_sell"`
	AuthPrice    int            `json:"auth_price"`
	ForAuth      bool           `json:"for_auth"`
	CreateTime   string         `json:"create_time"`
	ExList       []ExHistory    `json:"ex_list"`
	AvgRating    float64        `json:"avg_rating"`     // 平均评分（0-10）
	RatingCount  int            `json:"rating_count"`   // 评分次数
	Ratings      []RatingRecord `json:"ratings"`        // 评分记录
	// 审核相关字段
	AuditStatus  string         `json:"audit_status"`   // 审核状态：pending, approved, rejected
	AuditorID    string         `json:"auditor_id"`     // 审核者ID
	AuditTime    string         `json:"audit_time"`     // 审核时间
	AuditReward  int            `json:"audit_reward"`   // 审核激励金额
		PreviousQualityScore float64 `json:"previous_quality_score"` // 上一次质量评分
		PreviousPrice       int     `json:"previous_price"`         // 上一次价格
		LastPriceUpdateTime string  `json:"last_price_update_time"` // 上次价格更新时间
	Priority         float64        `json:"priority"`           // 优先级（基于评分、信誉等）
	PriceHistoryList []PriceHistory `json:"price_history_list"`  // 历史价格记录
}

// 交易历史结构体，包含交易ID、交易时间、交易发起者、交易接收者、交易金额、是否为授权交易
type ExHistory struct {
	ID     string `json:"id"`
	Time   string `json:"time"`
	From   string `json:"from"`
	To     string `json:"to"`
	Price  int    `json:"price"`
	IsAuth bool   `json:"is_auth"`
	Txid   string `json:"txid"`
}

// 质押记录结构体
type StakeRecord struct {
	ID     string `json:"id"`      // 记录ID
	UserID string `json:"user_id"` // 用户ID
	Amount int    `json:"amount"`  // 质押金额
	Action string `json:"action"`  // 操作：stake/unstake
	Time   string `json:"time"`    // 操作时间
	TxID   string `json:"tx_id"`   // 交易ID
}

// 评分记录结构体
type RatingRecord struct {
	ID       string `json:"id"`        // 评分ID
	AssetID  string `json:"asset_id"`  // 资产ID
	SellerID string `json:"seller_id"` // 卖家ID
	RaterID  string `json:"rater_id"`  // 评分者ID
	Rating   int    `json:"rating"`    // 评分（1-10）
	Comment  string `json:"comment"`   // 评论（可选）
	Time     string `json:"time"`      // 评分时间
	TxID     string `json:"tx_id"`     // 交易ID
}

// 余额变动流水记录结构体
type BalanceRecord struct {
	ID           string `json:"id"`            // 流水ID
	UserID       string `json:"user_id"`       // 用户ID
	Amount       int    `json:"amount"`        // 变动金额（正数为收入，负数为支出）
	BalanceAfter int    `json:"balance_after"` // 变动后余额
	Type         string `json:"type"`          // 变动类型
	Description  string `json:"description"`   // 变动描述
	RelatedTxID  string `json:"related_tx_id"` // 关联交易ID
	Time         string `json:"time"`          // 变动时间
}

// 价格历史记录结构体
type PriceHistory struct {
	Time      string  `json:"time"`       // 价格变动时间
	OldPrice  int     `json:"old_price"`  // 旧价格
	NewPrice  int     `json:"new_price"`  // 新价格
	AvgRating float64 `json:"avg_rating"` // 变动时的平均评分
	TxID      string  `json:"tx_id"`      // 关联交易ID
}