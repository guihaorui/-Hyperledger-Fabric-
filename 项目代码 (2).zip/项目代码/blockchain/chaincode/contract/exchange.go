package contract

import (
	"encoding/json"
	"errors"
	"fmt"
	"time"

	"github.com/hyperledger/fabric-contract-api-go/contractapi"
)

// 转账 , 从用户A转账到用户B
// 传入参数：用户A、用户B、金额
func (s *SmartContract) Transfer(ctx contractapi.TransactionContextInterface, usera string, userb string, amount int) error {
	if usera == userb {
		return errors.New("cant transfer to yourself")
	}
	usera_obj, err := s.ReadUser(ctx, usera)
	if err != nil {
		return err
	}
	if usera_obj == nil {
		return errors.New("usera dosen's exist")
	}
	userb_obj, err := s.ReadUser(ctx, userb)
	if err != nil {
		return err
	}
	if userb_obj == nil {
		return errors.New("userb dosen's exist")
	}
	if usera_obj.Balance < amount {
		return errors.New("usera insufficient balance")
	}

	// 检查转出方质押状态
	useraStaked, err := s.CheckStakeStatus(ctx, usera)
	if err != nil {
		return err
	}
	if useraStaked != "true" {
		return errors.New("usera must stake tokens before transferring")
	}
	usera_obj.Balance -= amount
	userb_obj.Balance += amount
	useraJSON, err := json.Marshal(usera_obj)
	if err != nil {
		return err
	}
	userbJSON, err := json.Marshal(userb_obj)
	if err != nil {
		return err
	}
	err = ctx.GetStub().PutState(usera, useraJSON)
	if err != nil {
		return err
	}
	err = ctx.GetStub().PutState(userb, userbJSON)
	if err != nil {
		return err
	}

	// 记录转账流水
	_ = s.addBalanceRecord(ctx, usera, -amount, usera_obj.Balance, "transfer_out",
		fmt.Sprintf("转账给用户 %s，金额 %d", userb, amount))
	_ = s.addBalanceRecord(ctx, userb, amount, userb_obj.Balance, "transfer_in",
		fmt.Sprintf("收到用户 %s 转账，金额 %d", usera, amount))

	return nil

}

// 购买
// 1. 读取资产
// 2. 检验用户余额
// 3. 转账
// 4. 更新资产
// 5. 更新用户
// 传入参数：购买人、资产ID、是否授权
func (s *SmartContract) Buy(ctx contractapi.TransactionContextInterface, buyer string, asset_id string, is_auth bool) error {
	// 读取资产
	asset, err := s.ReadAsset(ctx, asset_id)
	if err != nil {
		return err
	}
	if asset == nil {
		return errors.New("asset doesn's exist")
	}

	// 检查资产审核状态
	if asset.AuditStatus != "approved" {
		return errors.New("asset not approved for sale")
	}

	// 实例化卖家和买家结构体
	seller := asset.CurrentOwner
	seller_obj, err := s.ReadUser(ctx, seller)
	if err != nil {
		return err
	}
	buyer_obj, err := s.ReadUser(ctx, buyer)
	if err != nil {
		return err
	}

	// 检查质押状态
	buyerStaked, err := s.CheckStakeStatus(ctx, buyer)
	if err != nil {
		return err
	}
	if buyerStaked != "true" {
		return errors.New("buyer must stake tokens before purchasing")
	}

	// 对于普通交易（非授权），检查卖家质押状态
	if !is_auth {
		sellerStaked, err := s.CheckStakeStatus(ctx, seller)
		if err != nil {
			return err
		}
		if sellerStaked != "true" {
			return errors.New("seller must stake tokens before selling")
		}
	}

	// 检验用户余额
	if is_auth {
		if asset.AuthPrice > buyer_obj.Balance {
			return errors.New("buyer's balance insufficient for auth purchase")
		}
	} else {
		if asset.Price > buyer_obj.Balance {
			return errors.New("buyer's balance insufficient")
		}
	}

	// 转账
	if seller == buyer {
		return fmt.Errorf("cant buy from yourself")
	}

	// 如果是授权交易,修改双方余额
	var commission int
	if is_auth {
		if !asset.ForAuth {
			return errors.New("asset not for auth")
		}
		// 计算审核者佣金（1%）
		commission = asset.AuthPrice / 100
		// 如果审核者是卖家，则不需要支付佣金（卖家获得全价）
		if asset.AuditorID == seller {
			commission = 0
		}
		seller_obj.Balance += asset.AuthPrice - commission
		buyer_obj.Balance -= asset.AuthPrice
		// 如果资产有审核者且佣金大于0，给审核者佣金
		if asset.AuditorID != "" && commission > 0 {
			auditor, err := s.ReadUser(ctx, asset.AuditorID)
			if err != nil {
				return err
			}
			if auditor != nil {
				auditor.Balance += commission
				auditor.BalanceRecords = append(auditor.BalanceRecords, BalanceRecord{
					ID:           fmt.Sprintf("bl_%s_%d", asset.AuditorID, time.Now().UnixNano()),
					UserID:       asset.AuditorID,
					Amount:       commission,
					BalanceAfter: auditor.Balance,
					Type:         "audit_reward",
					Description:  fmt.Sprintf("audit commission for asset %s: %d", asset.Name, commission),
					RelatedTxID:  ctx.GetStub().GetTxID(),
					Time:         time.Now().In(time.FixedZone("CST", 8*3600)).Format("2006-01-02 15:04:05"),
				})
				auditorJSON, err := json.Marshal(auditor)
				if err != nil {
					return err
				}
				err = ctx.GetStub().PutState(asset.AuditorID, auditorJSON)
				if err != nil {
					return err
				}
			}
		}
	} else {
		if !asset.ForSell {
			return errors.New("asset not for sell")
		}
		// 计算审核者佣金（1%）
		commission = asset.Price / 100
		// 如果审核者是卖家，则不需要支付佣金（卖家获得全价）
		if asset.AuditorID == seller {
			commission = 0
		}
		seller_obj.Balance += asset.Price - commission
		buyer_obj.Balance -= asset.Price
		// 如果资产有审核者且佣金大于0，给审核者佣金
		if asset.AuditorID != "" && commission > 0 {
			auditor, err := s.ReadUser(ctx, asset.AuditorID)
			if err != nil {
				return err
			}
			if auditor != nil {
				auditor.Balance += commission
				auditor.BalanceRecords = append(auditor.BalanceRecords, BalanceRecord{
					ID:           fmt.Sprintf("bl_%s_%d", asset.AuditorID, time.Now().UnixNano()),
					UserID:       asset.AuditorID,
					Amount:       commission,
					BalanceAfter: auditor.Balance,
					Type:         "audit_reward",
					Description:  fmt.Sprintf("audit commission for asset %s: %d", asset.Name, commission),
					RelatedTxID:  ctx.GetStub().GetTxID(),
					Time:         time.Now().In(time.FixedZone("CST", 8*3600)).Format("2006-01-02 15:04:05"),
				})
				auditorJSON, err := json.Marshal(auditor)
				if err != nil {
					return err
				}
				err = ctx.GetStub().PutState(asset.AuditorID, auditorJSON)
				if err != nil {
					return err
				}
			}
		}
		// 如果是普通交易,需要删除卖家资产列表中的资产、资产的所属
		//从原来用户资产列表中删除
		newList := []string{}
		for _, v := range seller_obj.AssetList {
			if v != asset_id {
				newList = append(newList, v)
			}
		}
		seller_obj.AssetList = newList
		asset.CurrentOwner = buyer
	}

	// 添加到新用户资产列表
	buyer_obj.AssetList = append(buyer_obj.AssetList, asset_id)

	// 时间
	ts, err := ctx.GetStub().GetTxTimestamp()
	if err != nil {
		return err
	}
	timeStr := time.Unix(ts.Seconds, int64(ts.Nanos)).In(time.FixedZone("CST", 8*3600)).Format("2006-01-02 15:04:05")

	// 添加到资产的交易记录
	// 根据交易类型确定价格
	transactionPrice := asset.Price
	if is_auth {
		transactionPrice = asset.AuthPrice
	}
	ex := ExHistory{
		ID:     asset_id,
		Time:   timeStr,
		From:   seller,
		To:     buyer,
		Price:  transactionPrice,
		IsAuth: is_auth,
		Txid:   ctx.GetStub().GetTxID(),
	}
	asset.ExList = append(asset.ExList, ex)

	assetJSON, err := json.Marshal(asset)
	if err != nil {
		return err
	}
	err = ctx.GetStub().PutState(asset_id, assetJSON)
	if err != nil {
		return err
	}

	// 更新用户
	// 记录买家余额流水
	buyerBalanceRecord := BalanceRecord{
		ID:           fmt.Sprintf("bl_%s_%s", buyer, timeStr),
		UserID:       buyer,
		Amount:       -transactionPrice,
		BalanceAfter: buyer_obj.Balance,
		Type:         "buy_asset",
		Description:  fmt.Sprintf("购买资产 %s，金额 %d", asset.Name, transactionPrice),
		RelatedTxID:  ctx.GetStub().GetTxID(),
		Time:         timeStr,
	}
	if is_auth {
		buyerBalanceRecord.Type = "auth_buy"
		buyerBalanceRecord.Description = fmt.Sprintf("授权购买资产 %s，金额 %d", asset.Name, transactionPrice)
	}
	buyer_obj.BalanceRecords = append(buyer_obj.BalanceRecords, buyerBalanceRecord)

	// 记录卖家余额流水
	sellerBalanceRecord := BalanceRecord{
		ID:           fmt.Sprintf("bl_%s_%s", seller, timeStr),
		UserID:       seller,
		Amount:       transactionPrice,
		BalanceAfter: seller_obj.Balance,
		Type:         "sell_asset",
		Description:  fmt.Sprintf("出售资产 %s，收入 %d", asset.Name, transactionPrice),
		RelatedTxID:  ctx.GetStub().GetTxID(),
		Time:         timeStr,
	}
	if is_auth {
		sellerBalanceRecord.Type = "auth_sell"
		sellerBalanceRecord.Amount = transactionPrice - commission
		sellerBalanceRecord.Description = fmt.Sprintf("授权出售资产 %s，收入 %d", asset.Name, transactionPrice-commission)
	}
	seller_obj.BalanceRecords = append(seller_obj.BalanceRecords, sellerBalanceRecord)

	sellerJSON, err := json.Marshal(seller_obj)
	if err != nil {
		return err
	}
	buyerJSON, err := json.Marshal(buyer_obj)
	if err != nil {
		return err
	}
	err = ctx.GetStub().PutState(seller, sellerJSON)
	if err != nil {
		return err
	}
	err = ctx.GetStub().PutState(buyer, buyerJSON)
	if err != nil {
		return err
	}
	return nil
}

// 给资产评分
// 传入参数：资产ID、评分者ID、评分（1-10）、评论（可选）
func (s *SmartContract) RateAsset(ctx contractapi.TransactionContextInterface, assetID string, raterID string, rating int, comment string) error {
	// 验证评分范围
	if rating < 1 || rating > 10 {
		return errors.New("rating must be between 1 and 10")
	}

	// 读取资产
	asset, err := s.ReadAsset(ctx, assetID)
	if err != nil {
		return err
	}
	if asset == nil {
		return errors.New("asset not found")
	}

	// 检查评分者是否是资产的授权购买者（只有购买授权才能评分，购买资产所有权不能评分）
	canRate := false
	if len(asset.ExList) > 0 {
		lastTransaction := asset.ExList[len(asset.ExList)-1]
		if lastTransaction.To == raterID && lastTransaction.IsAuth {
			canRate = true
		}
	}

	if !canRate {
		return errors.New("only authorized buyers can rate this asset, asset ownership transfer does not grant rating permission")
	}

	// 检查是否已经评分过
	for _, existingRating := range asset.Ratings {
		if existingRating.RaterID == raterID {
			return errors.New("you have already rated this asset")
		}
	}

	// 检查评分者质押状态
	staked, err := s.CheckStakeStatus(ctx, raterID)
	if err != nil {
		return fmt.Errorf("failed to check stake status: %v", err)
	}
	if staked != "true" {
		return errors.New("rater must stake tokens before rating")
	}

	// 获取卖家ID
	sellerID := asset.Author
	if sellerID == "" {
		sellerID = asset.CurrentOwner
	}

	// 创建评分记录
	ratingTime := time.Now().In(time.FixedZone("CST", 8*3600)).Format("2006-01-02 15:04:05")
	txID := ctx.GetStub().GetTxID()
	ratingRecord := RatingRecord{
		ID:       fmt.Sprintf("rating_%s_%s_%s", assetID, raterID, ratingTime),
		AssetID:  assetID,
		SellerID: sellerID,
		RaterID:  raterID,
		Rating:   rating,
		Comment:  comment,
		Time:     ratingTime,
		TxID:     txID,
	}

	// 更新资产评分记录
	asset.Ratings = append(asset.Ratings, ratingRecord)
	asset.RatingCount = len(asset.Ratings)

	// 重新计算平均评分
	total := 0
	for _, r := range asset.Ratings {
		total += r.Rating
	}
	if asset.RatingCount > 0 {
		asset.AvgRating = float64(total) / float64(asset.RatingCount)
	}

	// 更新资产优先级：基于平均评分（评分越高优先级越高）
	asset.Priority = asset.AvgRating

	// 触发价格更新（评分变化触发） - 原子操作：更新价格并保存资产
	err = s.UpdatePriceForAsset(ctx, asset)
	if err != nil {
		return fmt.Errorf("评分成功但价格更新失败: %v", err)
	}

	// 更新卖家信誉分（价格更新成功后）
	err = s.UpdateReputation(ctx, sellerID, rating)
	if err != nil {
		// 信誉分更新失败，但评分和价格已更新，返回部分成功错误
		return fmt.Errorf("评分和价格更新成功，但信誉分更新失败: %v", err)
	}

	return nil
}

// 获取资产评分记录
func (s *SmartContract) GetAssetRatings(ctx contractapi.TransactionContextInterface, assetID string) ([]RatingRecord, error) {
	asset, err := s.ReadAsset(ctx, assetID)
	if err != nil {
		return nil, err
	}
	if asset == nil {
		return nil, errors.New("asset not found")
	}

	return asset.Ratings, nil
}

// 获取用户收到的评分记录
func (s *SmartContract) GetUserRatings(ctx contractapi.TransactionContextInterface, userID string) ([]RatingRecord, error) {
	// 这里需要遍历所有资产找到该用户的评分
	// 简化实现：返回空数组，实际可能需要更复杂的查询
	return []RatingRecord{}, nil
}

// GetAllTransactions 获取所有资产的所有交易历史（用于刷单检测分析）
func (s *SmartContract) GetAllTransactions(ctx contractapi.TransactionContextInterface) ([]ExHistory, error) {
	// 获取所有资产
	assets, err := s.GetAllAssets(ctx)
	if err != nil {
		return nil, fmt.Errorf("获取资产失败: %v", err)
	}

	// 收集所有交易历史
	allTransactions := []ExHistory{}
	for _, asset := range assets {
		allTransactions = append(allTransactions, asset.ExList...)
	}

	return allTransactions, nil
}

// GetUserTransactionHistory 获取用户所有交易历史（作为买家或卖家）
func (s *SmartContract) GetUserTransactionHistory(ctx contractapi.TransactionContextInterface, userID string) ([]ExHistory, error) {
	// 获取所有资产
	assets, err := s.GetAllAssets(ctx)
	if err != nil {
		return nil, fmt.Errorf("获取资产失败: %v", err)
	}

	// 收集用户相关的交易
	userTransactions := []ExHistory{}
	for _, asset := range assets {
		for _, tx := range asset.ExList {
			if tx.From == userID || tx.To == userID {
				userTransactions = append(userTransactions, tx)
			}
		}
	}

	return userTransactions, nil
}

// GetTransactionsByTimeRange 获取时间段内的所有交易
func (s *SmartContract) GetTransactionsByTimeRange(ctx contractapi.TransactionContextInterface, startTime, endTime string) ([]ExHistory, error) {
	// 获取所有交易
	allTransactions, err := s.GetAllTransactions(ctx)
	if err != nil {
		return nil, err
	}

	// 过滤时间范围内的交易
	filteredTransactions := []ExHistory{}
	for _, tx := range allTransactions {
		// 解析交易时间
		// 注意：这里需要处理时间解析错误，简化实现
		if tx.Time >= startTime && tx.Time <= endTime {
			filteredTransactions = append(filteredTransactions, tx)
		}
	}

	return filteredTransactions, nil
}

// addBalanceRecord 添加用户余额变动流水记录
func (s *SmartContract) addBalanceRecord(ctx contractapi.TransactionContextInterface, userID string, amount int, balanceAfter int, recordType string, description string) error {
	user, err := s.ReadUser(ctx, userID)
	if err != nil {
		return err
	}
	if user == nil {
		return errors.New("user not found")
	}

	now := time.Now().In(time.FixedZone("CST", 8*3600)).Format("2006-01-02 15:04:05")
	txID := ctx.GetStub().GetTxID()
	record := BalanceRecord{
		ID:           fmt.Sprintf("bl_%s_%s", userID, now),
		UserID:       userID,
		Amount:       amount,
		BalanceAfter: balanceAfter,
		Type:         recordType,
		Description:  description,
		RelatedTxID:  txID,
		Time:         now,
	}
	user.BalanceRecords = append(user.BalanceRecords, record)

	userJSON, err := json.Marshal(user)
	if err != nil {
		return err
	}
	return ctx.GetStub().PutState(userID, userJSON)
}

// GetBalanceRecords 获取用户余额变动流水
func (s *SmartContract) GetBalanceRecords(ctx contractapi.TransactionContextInterface, userID string) ([]BalanceRecord, error) {
	user, err := s.ReadUser(ctx, userID)
	if err != nil {
		return nil, err
	}
	if user == nil {
		return nil, errors.New("user not found")
	}
	return user.BalanceRecords, nil
}
