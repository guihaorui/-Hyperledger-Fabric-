package contract

import (
	"encoding/json"
	"errors"
	"fmt"
	"math"
	"strconv"
	"time"

	"github.com/hyperledger/fabric-contract-api-go/contractapi"
)

// 价格算法常量
const (
	K_up   = 0.01  // 质量因子上升系数 (1%) - 调整为1%左右
	K_down = 0.01  // 质量因子下降系数 (1%) - 调整为1%左右，幅度不能大
	S      = 0.2   // 灵敏度系数 - 降低灵敏度，防止剧烈波动
	Lambda = 0.02  // 市场热度系数 - 调整到合理范围
	C      = 0     // 基础存储和维护成本 - 确保价格不为零（设为0以符合评分逻辑）
	RatingThreshold = 5.0  // 评分阈值（五分） - 小于此值价格减少，超过此值价格上升
	MaxChangeRate = 0.06   // 最大变化率 (6%) - 允许零分减少6%
	IncreaseRatePerPoint = 0.006  // 每分增加率（0.6%） - 六分增加0.6%，十分增加3%
	DecreaseRatePerPoint = 0.012  // 每分减少率（1.2%） - 下跌时双倍，四分减少1.2%，零分减少6%
)

// PriceConstants 价格算法常量配置
type PriceConstants struct {
	K_up   float64 `json:"k_up"`
	K_down float64 `json:"k_down"`
	S      float64 `json:"s"`
	Lambda float64 `json:"lambda"`
	C      int     `json:"c"`
	RatingThreshold float64 `json:"rating_threshold"`
	MaxChangeRate   float64 `json:"max_change_rate"`
	IncreaseRatePerPoint float64 `json:"increase_rate_per_point"`
	DecreaseRatePerPoint float64 `json:"decrease_rate_per_point"`
}

// 信誉分算法常量
const (
	Alpha                 = 0.9   // 历史权重因子 α，0.8-0.95之间
	DecayLambda           = 0.04  // 衰减常数 λ，控制时间衰减速度
	StabilityThreshold    = 7.5   // 门陷因子，控制奖励区间
	ConsistencyReward     = 0.5   // 奖励系数，当分数高于门陷时给予奖励
	VolatilityPenalty     = 1.0   // 惩罚系数，当分数低于门陷时给予惩罚
)

// GetPriceConstants 获取价格算法常量配置
func (s *SmartContract) GetPriceConstants(ctx contractapi.TransactionContextInterface) (*PriceConstants, error) {
	constantsJSON, err := ctx.GetStub().GetState("price_constants")
	if err != nil {
		return nil, err
	}
	var constants PriceConstants
	if constantsJSON == nil {
		// 如果不存在，返回默认值
		constants = PriceConstants{
			K_up:   K_up,
			K_down: K_down,
			S:      S,
			Lambda: Lambda,
			C:      C,
			RatingThreshold: RatingThreshold,
			MaxChangeRate:   MaxChangeRate,
			IncreaseRatePerPoint: IncreaseRatePerPoint,
			DecreaseRatePerPoint: DecreaseRatePerPoint,
		}
	} else {
		err = json.Unmarshal(constantsJSON, &constants)
		if err != nil {
			return nil, err
		}
	}
	return &constants, nil
}

// UpdatePriceConstants 更新价格算法常量配置
func (s *SmartContract) UpdatePriceConstants(ctx contractapi.TransactionContextInterface, k_up, k_down, s_val, lambda, c, rating_threshold, max_change_rate, increase_rate_per_point, decrease_rate_per_point string) error {
	// 将字符串参数转换为适当类型
	k_up_f, err := strconv.ParseFloat(k_up, 64)
	if err != nil {
		return err
	}
	k_down_f, err := strconv.ParseFloat(k_down, 64)
	if err != nil {
		return err
	}
	s_f, err := strconv.ParseFloat(s_val, 64)
	if err != nil {
		return err
	}
	lambda_f, err := strconv.ParseFloat(lambda, 64)
	if err != nil {
		return err
	}
	c_i, err := strconv.Atoi(c)
	if err != nil {
		return err
	}
	rating_threshold_f, err := strconv.ParseFloat(rating_threshold, 64)
	if err != nil {
		return err
	}
	max_change_rate_f, err := strconv.ParseFloat(max_change_rate, 64)
	if err != nil {
		return err
	}
	increase_rate_per_point_f, err := strconv.ParseFloat(increase_rate_per_point, 64)
	if err != nil {
		return err
	}
	decrease_rate_per_point_f, err := strconv.ParseFloat(decrease_rate_per_point, 64)
	if err != nil {
		return err
	}
	constants := PriceConstants{
		K_up:   k_up_f,
		K_down: k_down_f,
		S:      s_f,
		Lambda: lambda_f,
		C:      c_i,
		RatingThreshold: rating_threshold_f,
		MaxChangeRate:   max_change_rate_f,
		IncreaseRatePerPoint: increase_rate_per_point_f,
		DecreaseRatePerPoint: decrease_rate_per_point_f,
	}
	constantsJSON, err := json.Marshal(constants)
	if err != nil {
		return err
	}
	return ctx.GetStub().PutState("price_constants", constantsJSON)
}

// UpdatePrice 更新资产价格，根据质量评分变化和市场热度
// 触发条件：1) 新评分产生；2) 24小时时间窗口到
func (s *SmartContract) UpdatePrice(ctx contractapi.TransactionContextInterface, assetID string) error {
	// 读取资产
	asset, err := s.ReadAsset(ctx, assetID)
	if err != nil {
		return err
	}
	if asset == nil {
		return errors.New("asset not found")
	}

	// 检查是否满足更新条件（至少24小时过去）
	// 如果不满足，也可以更新（例如评分触发），但这里我们不做限制，由调用方控制
	// 更新资产价格
	return s.UpdatePriceForAsset(ctx, asset)
}

// UpdatePriceForAsset 更新给定资产的价格（导出函数，假设资产已更新评分）
func (s *SmartContract) UpdatePriceForAsset(ctx contractapi.TransactionContextInterface, asset *Asset) error {
	// 计算新价格
	oldPrice := asset.Price
	newPrice, err := s.calculateNewPrice(ctx, asset)
	if err != nil {
		return err
	}
	fmt.Printf("[DEBUG UpdatePriceForAsset] assetID=%s, oldPrice=%d, newPrice=%d, AvgRating=%.2f", asset.ID, oldPrice, newPrice, asset.AvgRating)

	// 保存旧价格
	asset.PreviousPrice = oldPrice
	// 更新资产价格
	asset.Price = newPrice
	// 更新PreviousQualityScore为当前AvgRating
	asset.PreviousQualityScore = asset.AvgRating
	// 更新最后价格更新时间
	updateTime := time.Now().In(time.FixedZone("CST", 8*3600)).Format("2006-01-02 15:04:05")
	asset.LastPriceUpdateTime = updateTime

	// 追加价格历史记录
	asset.PriceHistoryList = append(asset.PriceHistoryList, PriceHistory{
		Time:      updateTime,
		OldPrice:  oldPrice,
		NewPrice:  newPrice,
		AvgRating: asset.AvgRating,
		TxID:      ctx.GetStub().GetTxID(),
	})

	// 保存资产
	assetJSON, err := json.Marshal(asset)
	if err != nil {
		return err
	}
	return ctx.GetStub().PutState(asset.ID, assetJSON)
}

// calculateNewPrice 计算新价格 P_new = P_old * (1 + ΔQ) * (1 + V_trend) + C
func (s *SmartContract) calculateNewPrice(ctx contractapi.TransactionContextInterface, asset *Asset) (int, error) {
	// 获取价格常量配置
	constants, err := s.GetPriceConstants(ctx)
	if err != nil {
		return 0, err
	}

	P_old := float64(asset.Price)
	fmt.Printf("[DEBUG calculateNewPrice] P_old=%.2f", P_old)

	// 计算ΔQ
	deltaQ, err := s.calculateDeltaQ(asset, constants)
	if err != nil {
		return 0, err
	}
	fmt.Printf("[DEBUG calculateNewPrice] deltaQ=%.4f", deltaQ)

	// 计算V_trend
	vTrend, err := s.calculateVTrend(ctx, asset, constants)
	if err != nil {
		return 0, err
	}
	fmt.Printf("[DEBUG calculateNewPrice] vTrend=%.4f, C=%d", vTrend, constants.C)

	// 计算新价格
	P_new := P_old * (1 + deltaQ) * (1 + vTrend) + float64(constants.C)
	fmt.Printf("[DEBUG calculateNewPrice] P_new before clamp=%.2f", P_new)
	// 确保价格不为负，并取整
	if P_new < 0 {
		P_new = 0
	}
	// 确保价格不为零（至少为1）
	if P_new < 1 {
		P_new = 1
	}
	fmt.Printf("[DEBUG calculateNewPrice] final P_new=%.2f, rounded=%d", P_new, int(math.Round(P_new)))
	return int(math.Round(P_new)), nil
}

// calculateDeltaQ 计算质量因子变化
// 新算法：基于当前评分与5分阈值的比较
// 如果当前评分 > 5分：价格上升，每分增加0.6%（六分增加0.6%，十分增加3%）
// 如果当前评分 < 5分：价格减少，每分减少1.2%（下跌双倍，四分减少1.2%，零分减少6%）
// 五分不变
func (s *SmartContract) calculateDeltaQ(asset *Asset, constants *PriceConstants) (float64, error) {
	Q_current := asset.AvgRating
	// Q_previous := asset.PreviousQualityScore // 不再使用，已注释掉趋势调整逻辑

	// 调试日志
	fmt.Printf("[DEBUG calculateDeltaQ] Q_current=%.2f, RatingThreshold=%.2f", Q_current, constants.RatingThreshold)

	// 计算当前评分与5分阈值的差异
	diff_from_threshold := Q_current - constants.RatingThreshold

	// 如果差异为0（即正好5分），价格不变
	if math.Abs(diff_from_threshold) < 1e-10 {
		return 0.0, nil
	}

	// 根据差异方向使用不同的每分变化率
	var ratePerPoint float64
	if diff_from_threshold > 0 {
		ratePerPoint = constants.IncreaseRatePerPoint  // 每分增加0.6%
	} else {
		ratePerPoint = constants.DecreaseRatePerPoint  // 每分减少1.2%
	}

	// 计算基础变化率：差异 * 每分变化率
	base_change := diff_from_threshold * ratePerPoint
	fmt.Printf("[DEBUG calculateDeltaQ] diff=%.2f, ratePerPoint=%.4f, base_change=%.4f", diff_from_threshold, ratePerPoint, base_change)

	// 可选：考虑评分变化趋势（当前评分与之前评分的差异）
	// 如果评分有显著变化，适当调整变化率
// 	rating_change := Q_current - Q_previous
// 	if math.Abs(rating_change) > 0.5 {
		// 评分变化显著，轻微调整变化率
		// 但幅度控制在小范围内（±0.2%内）
// 		trend_adjustment := 0.002 * math.Tanh(rating_change * constants.S)
// 		base_change += trend_adjustment
// 	}

	// 应用最大变化率限制
	if base_change > constants.MaxChangeRate {
		base_change = constants.MaxChangeRate
	} else if base_change < -constants.MaxChangeRate {
		base_change = -constants.MaxChangeRate
	}

	fmt.Printf("[DEBUG calculateDeltaQ] final base_change=%.4f", base_change)
	return base_change, nil
}

// calculateVTrend 计算市场热度因子 V_trend = λ * log(1 + Sales_volume_30d) * (1 - R)
func (s *SmartContract) calculateVTrend(ctx contractapi.TransactionContextInterface, asset *Asset, constants *PriceConstants) (float64, error) {
	// 计算近30天销量
	sales30d, err := s.calculateSalesVolume30d(asset)
	if err != nil {
		return 0, err
	}

	// 计算数据冗余度R（同类资产比例）
	redundancy, err := s.calculateRedundancyRatio(ctx, asset)
	if err != nil {
		return 0, err
	}

	// 计算V_trend
	vTrend := constants.Lambda * math.Log(1+float64(sales30d)) * (1 - redundancy)
	// 确保非负
	if vTrend < 0 {
		vTrend = 0
	}
	return vTrend, nil
}

// calculateSalesVolume30d 计算近30天销量（从交易历史ExList中统计）
func (s *SmartContract) calculateSalesVolume30d(asset *Asset) (int, error) {
	now := time.Now()
	count := 0
	for _, ex := range asset.ExList {
		// 解析交易时间
		t, err := time.Parse("2006-01-02 15:04:05", ex.Time)
		if err != nil {
			// 如果解析失败，跳过该记录
			continue
		}
		// 检查是否在最近30天内
		if now.Sub(t) <= 30*24*time.Hour {
			count++
		}
	}
	return count, nil
}

// calculateRedundancyRatio 计算数据冗余度R（同类资产比例）
// R = 同类资产数量 / 总资产数量
func (s *SmartContract) calculateRedundancyRatio(ctx contractapi.TransactionContextInterface, asset *Asset) (float64, error) {
	// 获取所有资产
	allAssets, err := s.GetAllAssets(ctx)
	if err != nil {
		return 0, err
	}

	total := len(allAssets)
	if total == 0 {
		return 0, nil
	}

	// 统计同类资产数量（相同AssetType）
	sameTypeCount := 0
	for _, a := range allAssets {
		if a.AssetType == asset.AssetType {
			sameTypeCount++
		}
	}

	// 计算比例
	ratio := float64(sameTypeCount) / float64(total)
	return ratio, nil
}

// GetAssetPriceHistory 获取资产价格历史记录
func (s *SmartContract) GetAssetPriceHistory(ctx contractapi.TransactionContextInterface, assetID string) ([]PriceHistory, error) {
	asset, err := s.ReadAsset(ctx, assetID)
	if err != nil {
		return nil, err
	}
	if asset == nil {
		return nil, errors.New("asset not found")
	}
	if asset.PriceHistoryList == nil {
		return []PriceHistory{}, nil
	}
	return asset.PriceHistoryList, nil
}

// UpdatePriceForAllAssets 为所有资产更新价格（供定时任务调用）
func (s *SmartContract) UpdatePriceForAllAssets(ctx contractapi.TransactionContextInterface) error {
	allAssets, err := s.GetAllAssets(ctx)
	if err != nil {
		return err
	}

	for _, asset := range allAssets {
		// 检查是否达到24小时更新窗口
		lastUpdate, err := time.Parse("2006-01-02 15:04:05", asset.LastPriceUpdateTime)
		if err != nil {
			// 如果解析失败，强制更新
			err = s.UpdatePrice(ctx, asset.ID)
			if err != nil {
				// 记录错误但继续处理其他资产
				fmt.Printf("Failed to update price for asset %s: %v\n", asset.ID, err)
			}
			continue
		}

		// 如果距离上次更新超过24小时，则更新价格
		if time.Now().Sub(lastUpdate) >= 24*time.Hour {
			err = s.UpdatePrice(ctx, asset.ID)
			if err != nil {
				fmt.Printf("Failed to update price for asset %s: %v\n", asset.ID, err)
			}
		}
	}
	return nil
}