// 资产增删改查
package contract

import (
	"encoding/json"
	"errors"
	"fmt"
	"sort"
	"time"

	"github.com/hyperledger/fabric-contract-api-go/contractapi"
)

// 创建资产
// 1. 创建资产结构体
// 2. 序列化资产结构体
// 3. 资产添加到用户资产列表
// 4. 资产写入账本
// 传入参数：ID、名称、资产类型、组织、详细信息、作者、SHA256、IPFS哈希、价格、是否出售、授权价格、是否授权
func (s *SmartContract) CreateAsset(ctx contractapi.TransactionContextInterface, id string, name string, asset_type string, org string, detail string, author string, sha256 string, ipfs_hash string, price int, for_sell bool, auth_price int, for_auth bool) error {
	val, err := ctx.GetStub().GetState(id)
	if err != nil {
		return err
	} else if val != nil {
		return errors.New("asset exists")
	}

	// 检查作者质押状态
	staked, err := s.CheckStakeStatus(ctx, author)
	if err != nil {
		return fmt.Errorf("failed to check stake status: %v", err)
	}
	if staked != "true" {
		return errors.New("author must stake tokens before creating assets")
	}

	// 获取作者信誉分用于计算优先级
	authorReputation, err := s.GetReputation(ctx, author)
	if err != nil {
		// 如果获取失败，使用默认值5.0
		authorReputation = 5.0
	}
	// 计算优先级：基于作者信誉分（0-10），信誉分越高优先级越高
	priority := authorReputation  // 0-10范围

	createTime := time.Now().In(time.FixedZone("CST", 8*3600)).Format("2006-01-02 15:04:05")
	asset := Asset{
		ID:           id,
		Name:         name,
		AssetType:    asset_type,
		Org:          org,
		Detail:       detail,
		Author:       author,
		Sha256:       sha256,
		IPFSHash:     ipfs_hash,
		CurrentOwner: author,
		Price:        price,
		ForSell:      for_sell,
		AuthPrice:    auth_price,
		ForAuth:      for_auth,
		CreateTime:   createTime,
		ExList:       []ExHistory{},
		AvgRating:    0.0,
		RatingCount:  0,
		Ratings:      []RatingRecord{},
		AuditStatus:  "pending",
		AuditorID:    "",
		AuditTime:    "",
		AuditReward:  0,
		PreviousQualityScore: 0.0,
		PreviousPrice:        price,
		LastPriceUpdateTime:  createTime,
		Priority:             priority,
		PriceHistoryList: []PriceHistory{
			{
				Time:      createTime,
				OldPrice:  0,
				NewPrice:  price,
				AvgRating: 0,
				TxID:      "init",
			},
		},
	}
	assetJSON, err := json.Marshal(asset)
	if err != nil {
		return err
	}

	err = s.AssetAddtoUser(ctx, author, id)
	if err != nil {
		return err
	}

	return ctx.GetStub().PutState(id, assetJSON)
}

// 查询资产
// 传入参数：ID
func (s *SmartContract) ReadAsset(ctx contractapi.TransactionContextInterface, id string) (*Asset, error) {
	assetJSON, err := ctx.GetStub().GetState(id)
	if err != nil {
		return nil, err
	}
	if assetJSON == nil {
		return nil, nil
	}
	var asset Asset
	err = json.Unmarshal(assetJSON, &asset)
	if err != nil {
		return nil, err
	}
	// 确保Ratings字段不是nil
	if asset.Ratings == nil {
		asset.Ratings = []RatingRecord{}
	}
	// 确保RatingCount与Ratings长度一致
	asset.RatingCount = len(asset.Ratings)
	// 如果RatingCount为0且AvgRating为0，保持0；否则重新计算
	if asset.RatingCount > 0 && asset.AvgRating == 0 {
		total := 0
		for _, r := range asset.Ratings {
			total += r.Rating
		}
		asset.AvgRating = float64(total) / float64(asset.RatingCount)
	}
	return &asset, nil
}

// 获取用户资产列表
func (s *SmartContract) GetUserAssets(ctx contractapi.TransactionContextInterface, user_id string) ([]*Asset, error) {
	user, err := s.ReadUser(ctx, user_id)
	if err != nil {
		return nil, err
	}
	if user == nil {
		return nil, errors.New("user not found")
	}
	assets := []*Asset{}
	for _, asset_id := range user.AssetList {
		asset, err := s.ReadAsset(ctx, asset_id)
		if err != nil {
			return nil, err
		}
		if asset == nil {
			continue
		}
		assets = append(assets, asset)
	}
	return assets, nil
}

// 更新资产
// 传入参数：ID、名称、资产类型、组织、详细信息、作者、当前拥有者、SHA256、IPFS哈希、价格、是否出售、授权价格、是否授权
// 因为资产的拥有者是作者，所以在更新资产时，不能修改当前拥有者
func (s *SmartContract) UpdateAsset(ctx contractapi.TransactionContextInterface, id string, name string, asset_type string, org string, detail string, author string, current_owner string, sha256 string, ipfs_hash string, price int, for_sell bool, auth_price int, for_auth bool) error {
	asset, err := s.ReadAsset(ctx, id)
	if err != nil {
		return err
	}
	if asset == nil {
		return err
	}
	asset.Name = name
	asset.AssetType = asset_type
	asset.Detail = detail
	asset.Author = author
	asset.CurrentOwner = current_owner
	asset.Sha256 = sha256
	asset.IPFSHash = ipfs_hash
	asset.Price = price
	asset.ForSell = for_sell
	asset.AuthPrice = auth_price
	asset.ForAuth = for_auth
	assetJSON, err := json.Marshal(asset)
	if err != nil {
		return err
	}
	return ctx.GetStub().PutState(id, assetJSON)
}

func (s *SmartContract) DeleteAsset(ctx contractapi.TransactionContextInterface, id string) error {
	// 查询所有用户资产列表并删除
	return ctx.GetStub().DelState(id)
}

// 加入用户资产列表
// 传入参数：用户ID、资产ID
func (s *SmartContract) AssetAddtoUser(ctx contractapi.TransactionContextInterface, user_id string, asset_id string) error {
	user, err := s.ReadUser(ctx, user_id)
	if err != nil {
		return err
	}
	if user == nil {
		return err
	} else {
		user.AssetList = append(user.AssetList, asset_id)
		userJSON, err := json.Marshal(user)
		if err != nil {
			return err
		}
		err = ctx.GetStub().PutState(user_id, userJSON)
		if err != nil {
			return err
		}
	}
	return nil
}

// 从用户资产列表删除资产
// 传入参数：用户ID、资产ID
func (s *SmartContract) AssetDelfromUser(ctx contractapi.TransactionContextInterface, user_id string, asset_id string) error {

	user, err := s.ReadUser(ctx, user_id)
	if err != nil {
		return err
	}

	newList := []string{}
	for _, v := range user.AssetList {
		if v != asset_id {
			newList = append(newList, v)
		}
	}
	user.AssetList = newList

	userJSON, err := json.Marshal(user)
	if err != nil {
		return err
	}
	err = ctx.GetStub().PutState(user_id, userJSON)
	if err != nil {
		return err
	}
	return nil
}

// 查询所有资产
func (s *SmartContract) GetAllAssets(ctx contractapi.TransactionContextInterface) ([]*Asset, error) {
	resultsIterator, err := ctx.GetStub().GetStateByRange("", "")
	if err != nil {
		return nil, fmt.Errorf("failed to get state by range: %v", err)
	}
	defer resultsIterator.Close()

	var assets []*Asset

	for resultsIterator.HasNext() {
		queryResponse, err := resultsIterator.Next()
		if err != nil {
			return nil, fmt.Errorf("failed to iterate results: %v", err)
		}

		// 先检查是否是有效的 JSON
		if !json.Valid(queryResponse.Value) {
			continue // 跳过无效 JSON
		}

		var asset Asset
		err = json.Unmarshal(queryResponse.Value, &asset)
		if err != nil || asset.AssetType == "" { // 仅保留有效的 Asset
			continue
		}
		// 确保Ratings字段不是nil
		if asset.Ratings == nil {
			asset.Ratings = []RatingRecord{}
		}
		// 确保RatingCount与Ratings长度一致
		asset.RatingCount = len(asset.Ratings)
		// 如果RatingCount为0且AvgRating为0，保持0；否则重新计算
		if asset.RatingCount > 0 && asset.AvgRating == 0 {
			total := 0
			for _, r := range asset.Ratings {
				total += r.Rating
			}
			asset.AvgRating = float64(total) / float64(asset.RatingCount)
		}

		assets = append(assets, &asset)
	}

	return assets, nil
}

// 审核资产
// 传入参数：资产ID、审核者ID、审核动作（approve/reject）
func (s *SmartContract) AuditAsset(ctx contractapi.TransactionContextInterface, assetID string, auditorID string, action string) error {
	// 读取资产
	asset, err := s.ReadAsset(ctx, assetID)
	if err != nil {
		return err
	}
	if asset == nil {
		return errors.New("asset not found")
	}

	// 检查资产是否已经审核过
	if asset.AuditStatus != "pending" {
		return errors.New("asset already audited")
	}

	// 检查审核者是否是监督审查者角色
	auditorType, err := s.GetUserType(ctx, auditorID)
	if err != nil {
		return fmt.Errorf("failed to get auditor type: %v", err)
	}
	if auditorType != "监督审查者" {
		return errors.New("only supervisor auditor can audit assets")
	}

	// 获取审核时间
	auditTime := time.Now().In(time.FixedZone("CST", 8*3600)).Format("2006-01-02 15:04:05")

	if action == "approve" {
		// 计算审核激励：资产价格的1%
		reward := s.calculateAuditReward(asset.Price)

		// 更新资产审核状态
		asset.AuditStatus = "approved"
		asset.AuditorID = auditorID
		asset.AuditTime = auditTime
		asset.AuditReward = reward

		// 给予审核者激励
		auditor, err := s.ReadUser(ctx, auditorID)
		if err != nil {
			return err
		}
		if auditor == nil {
			return errors.New("auditor not found")
		}
		auditor.Balance += reward

		// 保存审核者
		auditorJSON, err := json.Marshal(auditor)
		if err != nil {
			return err
		}
		err = ctx.GetStub().PutState(auditorID, auditorJSON)
		if err != nil {
			return err
		}

		// 保存资产
		assetJSON, err := json.Marshal(asset)
		if err != nil {
			return err
		}
		return ctx.GetStub().PutState(assetID, assetJSON)

	} else if action == "reject" {
		// 拒绝资产
		asset.AuditStatus = "rejected"
		asset.AuditorID = auditorID
		asset.AuditTime = auditTime
		asset.AuditReward = 0

		// 保存资产
		assetJSON, err := json.Marshal(asset)
		if err != nil {
			return err
		}
		return ctx.GetStub().PutState(assetID, assetJSON)

	} else {
		return errors.New("invalid action, must be 'approve' or 'reject'")
	}
}

// 计算审核激励金额
// 资产价格的1%
func (s *SmartContract) calculateAuditReward(price int) int {
	// 计算价格的1%，使用整数除法，至少为1
	reward := price / 100
	if reward < 1 {
		reward = 1  // 最小激励1个代币
	}
	return reward
}

// 获取待审核的资产列表（按优先级排序）
func (s *SmartContract) GetPendingAssets(ctx contractapi.TransactionContextInterface) ([]*Asset, error) {
	// 获取所有资产
	allAssets, err := s.GetAllAssets(ctx)
	if err != nil {
		return nil, err
	}

	// 筛选待审核资产
	var pendingAssets []*Asset
	for _, asset := range allAssets {
		if asset.AuditStatus == "pending" {
			pendingAssets = append(pendingAssets, asset)
		}
	}

	// 按优先级降序排序（优先级高的在前）
	sortPendingAssetsByPriority(pendingAssets)

	return pendingAssets, nil
}

// 按优先级排序（降序）
func sortPendingAssetsByPriority(assets []*Asset) {
	sort.Slice(assets, func(i, j int) bool {
		return assets[i].Priority > assets[j].Priority
	})
}

// 更新资产优先级（例如评分变化后）
func (s *SmartContract) UpdateAssetPriority(ctx contractapi.TransactionContextInterface, assetID string, newPriority float64) error {
	asset, err := s.ReadAsset(ctx, assetID)
	if err != nil {
		return err
	}
	if asset == nil {
		return errors.New("asset not found")
	}

	asset.Priority = newPriority
	assetJSON, err := json.Marshal(asset)
	if err != nil {
		return err
	}
	return ctx.GetStub().PutState(assetID, assetJSON)
}
