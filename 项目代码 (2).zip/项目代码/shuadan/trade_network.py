# 第一课：创建交易网络数据集
print("=== 创建交易网络数据集 ===")

import networkx as nx
import community as community_louvain
import matplotlib.pyplot as plt
import random
import pandas as pd
from collections import defaultdict
import numpy as np

print("✅ 库导入成功")

# 设置随机种子，让每次生成的数据一样
random.seed(42)
np.random.seed(42)

# 1. 创建买家和卖家
print("👥 创建买家和卖家...")

buyers = [f"买家_{i}" for i in range(1, 21)]  # 20个买家
sellers = [f"卖家_{i}" for i in range(1, 16)]  # 15个卖家

print(f"   创建了 {len(buyers)} 个买家")
print(f"   创建了 {len(sellers)} 个卖家")

# 2. 生成交易数据
print("\n💰 生成交易记录...")

transactions = []
products = ["电子产品", "服装", "食品", "书籍", "家居用品"]

# 为每个卖家设置主营产品和价格范围
seller_specialties = {}
for seller in sellers:
    specialty = random.choice(products)
    base_price = random.randint(50, 500)
    seller_specialties[seller] = {
        'specialty': specialty,
        'base_price': base_price,
        'price_range': (base_price * 0.7, base_price * 1.3)
    }

# 生成交易记录
for i in range(100):  # 生成100笔交易
    buyer = random.choice(buyers)
    seller = random.choice(sellers)
    
    # 根据卖家专业领域确定价格
    specialty_info = seller_specialties[seller]
    price = random.randint(int(specialty_info['price_range'][0]), 
                          int(specialty_info['price_range'][1]))
    
    product = specialty_info['specialty']
    
    transactions.append({
        'transaction_id': i + 1,
        'buyer': buyer,
        'seller': seller,
        'product': product,
        'price': price,
        'quantity': random.randint(1, 5)
    })

print(f"   生成了 {len(transactions)} 笔交易记录")

# 3. 显示前10笔交易样本
print("\n📋 交易记录样本 (前10笔):")
print("=" * 60)
print(f"{'交易ID':<8} {'买家':<8} {'卖家':<8} {'产品':<8} {'价格':<6} {'数量':<4}")
print("-" * 60)
for t in transactions[:10]:
    print(f"{t['transaction_id']:<8} {t['buyer']:<8} {t['seller']:<8} "
          f"{t['product']:<8} {t['price']:<6} {t['quantity']:<4}")

# 4. 创建交易网络
print("\n🔗 构建交易网络...")

# 创建有向图，方向：买家 -> 卖家（资金流向）
G = nx.DiGraph()

# 添加节点
G.add_nodes_from(buyers, node_type='buyer')
G.add_nodes_from(sellers, node_type='seller')

print(f"   网络节点: {G.number_of_nodes()} 个")
print(f"   买家: {len(buyers)} 个")
print(f"   卖家: {len(sellers)} 个")

# 5. 添加带权重的边（交易关系）
transaction_weights = defaultdict(float)

for transaction in transactions:
    buyer = transaction['buyer']
    seller = transaction['seller']
    trade_volume = transaction['price'] * transaction['quantity']
    
    # 累加交易额作为权重
    key = (buyer, seller)
    transaction_weights[key] += trade_volume

# 添加边到网络
for (buyer, seller), weight in transaction_weights.items():
    G.add_edge(buyer, seller, weight=weight, transactions=1)

print(f"   交易边: {G.number_of_edges()} 条")
print(f"   总交易额: {sum(transaction_weights.values()):.2f}")

# 6. 显示网络基本信息
print(f"\n📊 交易网络基本信息：")
print("=" * 50)

# 计算每个买家的总消费
buyer_expenditure = defaultdict(float)
for (buyer, seller), weight in transaction_weights.items():
    buyer_expenditure[buyer] += weight

# 计算每个卖家的总收入
seller_income = defaultdict(float)
for (buyer, seller), weight in transaction_weights.items():
    seller_income[seller] += weight

print(f"\n💰 买家消费排行 (前5):")
sorted_buyers = sorted(buyer_expenditure.items(), key=lambda x: x[1], reverse=True)
for buyer, expenditure in sorted_buyers[:5]:
    print(f"   {buyer}: ￥{expenditure:.2f}")

print(f"\n🏪 卖家收入排行 (前5):")
sorted_sellers = sorted(seller_income.items(), key=lambda x: x[1], reverse=True)
for seller, income in sorted_sellers[:5]:
    print(f"   {seller}: ￥{income:.2f}")

print(f"\n📈 网络统计:")
print(f"   平均交易额: {np.mean(list(transaction_weights.values())):.2f}")
print(f"   最大单边交易额: {max(transaction_weights.values()):.2f}")
print(f"   网络密度: {nx.density(G):.3f}")

print("\n✅ 交易数据集创建完成！")