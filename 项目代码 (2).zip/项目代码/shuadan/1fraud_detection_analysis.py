# 增强版刷单检测分析系统（10分制评分 + 多维度异常参数）
print("=== 增强版刷单检测分析系统 ===")

import networkx as nx
import community as community_louvain
import random
import numpy as np
from collections import defaultdict
from datetime import datetime

print("✅ 库导入成功")

# 设置随机种子
random.seed(1000)
np.random.seed(1000)

# 1. 创建更真实的交易数据集（包含正常交易和刷单模式）
print("🔄 创建包含刷单模式的交易数据集...")

# 创建真实买家（正常消费者）
real_buyers = [f"真实买家_{i}" for i in range(100, 310)]
# 创建刷单小号（特征：交易频繁、评分固定、交易对象集中）
fraud_buyers = [f"刷单小号_{i}" for i in range(100, 160)]

# 创建卖家（部分参与刷单）
honest_sellers = [f"诚信卖家_{i}" for i in range(10, 110)]
fraud_sellers = [f"刷单卖家_{i}" for i in range(10, 60)]

all_buyers = real_buyers + fraud_buyers
all_sellers = honest_sellers + fraud_sellers

print(f"👥 参与者统计:")
print(f"   • 真实买家: {len(real_buyers)} 个")
print(f"   • 刷单小号: {len(fraud_buyers)} 个") 
print(f"   • 诚信卖家: {len(honest_sellers)} 个")
print(f"   • 刷单卖家: {len(fraud_sellers)} 个")

# 2. 生成交易数据（10分制评分）
transactions = []
products = ["电子产品", "服装", "食品", "书籍", "家居用品"]

# 设置产品基础价格
product_prices = {
    "电子产品": (300, 2000),
    "服装": (50, 500),
    "食品": (10, 100), 
    "书籍": (20, 200),
    "家居用品": (100, 800)
}

def generate_normal_transaction():
    """生成正常交易 - 10分制评分"""
    buyer = random.choice(real_buyers)
    seller = random.choice(all_sellers)
    product = random.choice(products)
    price_range = product_prices[product]
    price = random.randint(price_range[0], price_range[1])
    quantity = random.randint(1, 3)
    
    # 正常交易评分分布（10分制）- 更真实的分布
    rating = random.choices([4, 5, 6, 7, 8, 9, 10], weights=[0.05, 0.1, 0.15, 0.3, 0.2, 0.15, 0.05])[0]
    
    return {
        'buyer': buyer,
        'seller': seller, 
        'product': product,
        'price': price,
        'quantity': quantity,
        'amount': price * quantity,
        'rating': rating,  # 10分制评分
        'type': 'normal'
    }

def generate_fraud_transaction():
    """生成刷单交易 - 10分制评分"""
    # 刷单小号主要与刷单卖家交易
    buyer = random.choice(fraud_buyers)
    seller = random.choices([random.choice(fraud_sellers), random.choice(honest_sellers)], 
                           weights=[0.8, 0.2])[0]
    product = random.choice(products)
    price_range = product_prices[product]
    
    # 刷单特征：价格相对固定，数量多为1，评分几乎都是满分
    price = random.randint(price_range[0], price_range[0] + 50)  # 价格范围窄
    quantity = 1  # 刷单通常只买1件
    
    # 刷单评分特征：几乎都是9-10分
    rating = random.choices([9, 10], weights=[0.2, 0.8])[0]
    
    return {
        'buyer': buyer,
        'seller': seller,
        'product': product,
        'price': price, 
        'quantity': quantity,
        'amount': price * quantity,
        'rating': rating,  # 10分制评分
        'type': 'fraud'
    }

# 生成交易记录（混合正常交易和刷单）
print("\n💰 生成交易记录...")
for i in range(200):  # 总共200笔交易
    # 70%正常交易，30%刷单交易
    if random.random() < 0.7:
        transactions.append(generate_normal_transaction())
    else:
        transactions.append(generate_fraud_transaction())

print(f"   生成 {len(transactions)} 笔交易记录")
print(f"   • 正常交易: {len([t for t in transactions if t['type'] == 'normal'])} 笔")
print(f"   • 刷单交易: {len([t for t in transactions if t['type'] == 'fraud'])} 笔")

# 3. 构建多维度权重的交易网络
print("\n🔗 构建多维度权重交易网络...")

G = nx.Graph()

# 添加节点并标记类型
for buyer in real_buyers:
    G.add_node(buyer, node_type='real_buyer', label=buyer)
for buyer in fraud_buyers:
    G.add_node(buyer, node_type='fraud_buyer', label=buyer)  
for seller in honest_sellers:
    G.add_node(seller, node_type='honest_seller', label=seller)
for seller in fraud_sellers:
    G.add_node(seller, node_type='fraud_seller', label=seller)

# 计算综合权重（交易金额 + 评分权重 - 10分制调整）
edge_weights = defaultdict(lambda: {'amount': 0, 'rating_sum': 0, 'count': 0})

for transaction in transactions:
    buyer = transaction['buyer']
    seller = transaction['seller']
    key = (buyer, seller)
    
    edge_weights[key]['amount'] += transaction['amount']
    edge_weights[key]['rating_sum'] += transaction['rating']
    edge_weights[key]['count'] += 1

# 计算综合权重：交易金额(50%) + 评分因素(30%) + 交易频次(20%) - 调整为10分制
composite_weights = {}
for edge, metrics in edge_weights.items():
    avg_rating = metrics['rating_sum'] / metrics['count']
    
    # 归一化各项指标（调整为10分制）
    amount_weight = metrics['amount'] / 5000  # 假设最大交易额5000
    rating_weight = (avg_rating - 1) / 9      # 评分1-10归一化到0-1（10分制）
    count_weight = metrics['count'] / 10      # 假设最大交易次数10
    
    # 综合权重
    composite_weight = (0.5 * amount_weight + 0.3 * rating_weight + 0.2 * count_weight) * 100
    
    composite_weights[edge] = composite_weight
    G.add_edge(edge[0], edge[1], 
               weight=composite_weight,
               amount=metrics['amount'],
               rating_avg=avg_rating,
               count=metrics['count'])

print(f"✅ 网络构建完成: {G.number_of_nodes()} 节点, {G.number_of_edges()} 边")

# 4. 运行社区发现算法
print("\n🔍 运行社区发现算法检测刷单群体...")
partition = community_louvain.best_partition(G, weight='weight')
modularity = community_louvain.modularity(partition, G, weight='weight')

communities = set(partition.values())
print(f"   发现 {len(communities)} 个交易社区")
print(f"   模块度: {modularity:.3f}")

# 5. 分析每个社区的刷单嫌疑度（新增多维度参数）
print("\n📊 刷单嫌疑社区分析")
print("=" * 80)

community_analysis = defaultdict(lambda: {
    'real_buyers': [], 'fraud_buyers': [], 
    'honest_sellers': [], 'fraud_sellers': [],
    'total_transactions': 0, 'fraud_transactions': 0,
    'avg_rating': 0.0, 'suspicion_score': 0.0,
    # 新增参数
    'rating_anomaly': 0.0,      # 评分异常度
    'transaction_pattern_anomaly': 0.0,  # 交易模式异常度
    'buyer_outbound_degree': 0.0,  # 买家外向度
    'seller_concentration': 0.0,   # 卖家集中度
    'price_consistency': 0.0,      # 价格一致性
    'quantity_anomaly': 0.0        # 数量异常度
})

# 统计社区成员 - 修复版
for node, comm_id in partition.items():
    # 获取节点的类型属性
    node_type = G.nodes[node].get('node_type', 'unknown')
    
    if node_type == 'real_buyer':
        community_analysis[comm_id]['real_buyers'].append(node)
    elif node_type == 'fraud_buyer':
        community_analysis[comm_id]['fraud_buyers'].append(node)
    elif node_type == 'honest_seller':
        community_analysis[comm_id]['honest_sellers'].append(node)
    elif node_type == 'fraud_seller':
        community_analysis[comm_id]['fraud_sellers'].append(node)
    else:
        # 如果节点类型未知，根据名称判断（备用方案）
        if '真实买家' in node:
            community_analysis[comm_id]['real_buyers'].append(node)
        elif '刷单小号' in node:
            community_analysis[comm_id]['fraud_buyers'].append(node)
        elif '诚信卖家' in node:
            community_analysis[comm_id]['honest_sellers'].append(node)
        elif '刷单卖家' in node:
            community_analysis[comm_id]['fraud_sellers'].append(node)

# 为每个社区收集交易记录
community_transactions = defaultdict(list)
for transaction in transactions:
    buyer = transaction['buyer']
    seller = transaction['seller']
    buyer_comm = partition.get(buyer)
    seller_comm = partition.get(seller)
    
    if buyer_comm == seller_comm and buyer_comm is not None:
        community_transactions[buyer_comm].append(transaction)
        community_analysis[buyer_comm]['total_transactions'] += 1
        community_analysis[buyer_comm]['avg_rating'] += transaction['rating']
        if transaction['type'] == 'fraud':
            community_analysis[buyer_comm]['fraud_transactions'] += 1

# 计算平均评分和新增参数
for comm_id in communities:
    analysis = community_analysis[comm_id]
    transactions_in_comm = community_transactions.get(comm_id, [])
    
    if analysis['total_transactions'] > 0:
        analysis['avg_rating'] /= analysis['total_transactions']
        analysis['fraud_ratio'] = analysis['fraud_transactions'] / analysis['total_transactions']
        
        # 计算新增参数
        if transactions_in_comm:
            ratings = [t['rating'] for t in transactions_in_comm]
            prices = [t['price'] for t in transactions_in_comm]
            quantities = [t['quantity'] for t in transactions_in_comm]
            
            # 1. 评分异常度 - 评分接近满分的程度（10分制）
            analysis['rating_anomaly'] = (np.mean(ratings) - 7) / 3  # 7分作为基准，10分制
            
            # 2. 交易模式异常度 - 基于数量和价格的一致性
            quantity_std = np.std(quantities)
            price_std = np.std(prices)
            analysis['transaction_pattern_anomaly'] = (1 / (quantity_std + 0.1) + 1 / (price_std + 0.1)) / 2
            
            # 3. 买家外向度 - 买家与社区外卖家的交易比例
            buyer_outbound_count = 0
            for buyer in analysis['real_buyers'] + analysis['fraud_buyers']:
                buyer_transactions = [t for t in transactions if t['buyer'] == buyer]
                outbound_transactions = [t for t in buyer_transactions if partition.get(t['seller']) != comm_id]
                buyer_outbound_count += len(outbound_transactions)
            total_buyer_transactions = sum(len([t for t in transactions if t['buyer'] == buyer]) 
                                         for buyer in analysis['real_buyers'] + analysis['fraud_buyers'])
            analysis['buyer_outbound_degree'] = buyer_outbound_count / total_buyer_transactions if total_buyer_transactions > 0 else 0
            
            # 4. 卖家集中度 - 少数卖家占据大部分交易的程度
            seller_transaction_count = defaultdict(int)
            for trans in transactions_in_comm:
                seller_transaction_count[trans['seller']] += 1
            if seller_transaction_count:
                top_seller_ratio = max(seller_transaction_count.values()) / len(transactions_in_comm)
                analysis['seller_concentration'] = top_seller_ratio
            
            # 5. 价格一致性 - 价格变化的倒数（价格越固定，值越高）
            analysis['price_consistency'] = 1 / (price_std + 0.1)
            
            # 6. 数量异常度 - 数量为1的交易比例（刷单特征）
            single_quantity_count = len([t for t in transactions_in_comm if t['quantity'] == 1])
            analysis['quantity_anomaly'] = single_quantity_count / len(transactions_in_comm)
            
    else:
        analysis['fraud_ratio'] = 0.0
        analysis['avg_rating'] = 0.0
        # 新增参数默认为0
        analysis['rating_anomaly'] = 0.0
        analysis['transaction_pattern_anomaly'] = 0.0
        analysis['buyer_outbound_degree'] = 0.0
        analysis['seller_concentration'] = 0.0
        analysis['price_consistency'] = 0.0
        analysis['quantity_anomaly'] = 0.0
    
    # 计算嫌疑度评分（包含新参数）
    total_buyers = len(analysis['real_buyers']) + len(analysis['fraud_buyers'])
    total_sellers = len(analysis['honest_sellers']) + len(analysis['fraud_sellers'])
    
    fraud_buyer_ratio = len(analysis['fraud_buyers']) / total_buyers if total_buyers > 0 else 0
    fraud_seller_ratio = len(analysis['fraud_sellers']) / total_sellers if total_sellers > 0 else 0
    
    # 新参数权重
    analysis['suspicion_score'] = (
        fraud_buyer_ratio * 0.25 + 
        fraud_seller_ratio * 0.20 + 
        analysis['fraud_ratio'] * 0.15 +
        analysis['rating_anomaly'] * 0.10 +
        analysis['transaction_pattern_anomaly'] * 0.10 +
        (1 - analysis['buyer_outbound_degree']) * 0.08 +  # 外向度越低越可疑
        analysis['seller_concentration'] * 0.07 +
        analysis['price_consistency'] * 0.03 +
        analysis['quantity_anomaly'] * 0.02
    ) * 100
    
    # 确保嫌疑度在0-100之间
    analysis['suspicion_score'] = max(0, min(100, analysis['suspicion_score']))

# 6. 生成刷单检测报告（包含新参数）
def generate_enhanced_fraud_detection_report():
    """生成增强版刷单检测报告"""
    
    report = []
    report.append("=" * 120)
    report.append("                         增强版刷单检测分析报告（10分制评分 + 多维度参数）")
    report.append("=" * 120)
    report.append(f"生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    report.append(f"分析范围: {len(transactions)} 笔交易, {G.number_of_nodes()} 个参与者")
    report.append("评分体系: 10分制 | 检测维度: 9项参数综合评估")
    report.append("")
    
    # 执行摘要
    report.append("一、执行摘要")
    report.append("-" * 60)
    total_fraud_transactions = len([t for t in transactions if t['type'] == 'fraud'])

    # 计算有效社区数量
    valid_communities = [
        c for c in communities 
        if (len(community_analysis[c]['real_buyers']) + len(community_analysis[c]['fraud_buyers']) + 
            len(community_analysis[c]['honest_sellers']) + len(community_analysis[c]['fraud_sellers'])) > 0
    ]

    report.append(f"📈 总体统计:")
    report.append(f"   • 总交易量: {len(transactions)} 笔")
    report.append(f"   • 疑似刷单交易: {total_fraud_transactions} 笔 ({total_fraud_transactions/len(transactions)*100:.1f}%)")
    report.append(f"   • 刷单小号数量: {len(fraud_buyers)} 个")
    report.append(f"   • 参与刷单卖家: {len(fraud_sellers)} 个")
    report.append(f"   • 发现有效社区: {len(valid_communities)} 个")
    
    # 风险分布
    high_risk = len([c for c in valid_communities if community_analysis[c]['suspicion_score'] > 70])
    medium_risk = len([c for c in valid_communities if 40 <= community_analysis[c]['suspicion_score'] <= 70])
    low_risk = len(valid_communities) - high_risk - medium_risk
    
    report.append(f"🎯 风险分布:")
    report.append(f"   • 高风险社区: {high_risk} 个 (嫌疑度 > 70)")
    report.append(f"   • 中风险社区: {medium_risk} 个 (40 ≤ 嫌疑度 ≤ 70)")
    report.append(f"   • 低风险社区: {low_risk} 个")
    report.append("")
    
    # 刷单社区详细分析
    report.append("二、刷单嫌疑社区详细分析")
    report.append("-" * 60)

    # 首先，为每个社区收集交易记录
    community_transactions = defaultdict(list)
    for transaction in transactions:
        buyer = transaction['buyer']
        seller = transaction['seller']
        buyer_comm = partition.get(buyer)
        seller_comm = partition.get(seller)
        
        if buyer_comm == seller_comm and buyer_comm is not None:
            community_transactions[buyer_comm].append(transaction)

    suspicious_communities = sorted([(comm_id, analysis) for comm_id, analysis in community_analysis.items()], 
                                   key=lambda x: x[1]['suspicion_score'], reverse=True)

    for i, (comm_id, analysis) in enumerate(suspicious_communities, 1):
        total_members = (len(analysis['real_buyers']) + len(analysis['fraud_buyers']) + 
                        len(analysis['honest_sellers']) + len(analysis['fraud_sellers']))
        
        # 跳过空社区
        if total_members == 0:
            continue
            
        transactions_in_comm = community_transactions.get(comm_id, [])
        
        # 只显示嫌疑度较高的社区
        if analysis['suspicion_score'] < 30:
            continue
            
        risk_level = "🚨 高风险" if analysis['suspicion_score'] > 70 else "🟡 中风险" if analysis['suspicion_score'] > 40 else "🟢 低风险"
        
        report.append(f"{i}. {risk_level} 社区 {comm_id}")
        report.append(f"   📊 核心指标:")
        report.append(f"      • 综合嫌疑度: {analysis['suspicion_score']:.1f}分")
        report.append(f"      • 成员构成: {len(analysis['real_buyers'])}真实买家 + {len(analysis['fraud_buyers'])}刷单小号 + "
                     f"{len(analysis['honest_sellers'])}诚信卖家 + {len(analysis['fraud_sellers'])}刷单卖家")
        report.append(f"      • 交易统计: {len(transactions_in_comm)}笔交易, 刷单比例: {analysis['fraud_ratio']*100:.1f}%")
        report.append(f"      • 平均评分: {analysis['avg_rating']:.1f}/10分")
        
        report.append(f"   🔍 多维度异常参数:")
        report.append(f"      • 评分异常度: {analysis['rating_anomaly']:.3f} (越高表示评分越异常)")
        report.append(f"      • 交易模式异常度: {analysis['transaction_pattern_anomaly']:.3f} (越高表示模式越固定)")
        report.append(f"      • 买家外向度: {analysis['buyer_outbound_degree']:.3f} (越低表示越封闭)")
        report.append(f"      • 卖家集中度: {analysis['seller_concentration']:.3f} (越高表示卖家越集中)")
        report.append(f"      • 价格一致性: {analysis['price_consistency']:.3f} (越高表示价格越固定)")
        report.append(f"      • 数量异常度: {analysis['quantity_anomaly']:.3f} (越高表示单件购买越多)")
        
        # 显示刷单成员
        if analysis['fraud_buyers']:
            report.append(f"   🔴 刷单小号列表: {', '.join(analysis['fraud_buyers'])}")
        if analysis['fraud_sellers']:
            report.append(f"   🔴 刷单卖家列表: {', '.join(analysis['fraud_sellers'])}")
        
        # 显示交易记录
        if transactions_in_comm and analysis['suspicion_score'] > 50:  # 只对高嫌疑社区显示详细交易
            report.append(f"   📋 交易记录 (共{len(transactions_in_comm)}笔):")
            report.append("      " + "-" * 85)
            report.append("      | 买家 | 卖家 | 产品 | 价格 | 数量 | 总额 | 评分 | 类型 |")
            report.append("      " + "-" * 85)
            
            for trans in transactions_in_comm:
                buyer_display = trans['buyer'].replace('真实买家_', 'B').replace('刷单小号_', 'F')
                seller_display = trans['seller'].replace('诚信卖家_', 'HS').replace('刷单卖家_', 'FS')
                trans_type = "🔴刷单" if trans['type'] == 'fraud' else "🟢正常"
                report.append(f"      | {buyer_display:<4} | {seller_display:<4} | {trans['product']:<4} | "
                             f"￥{trans['price']:<4} | {trans['quantity']:<2} | ￥{trans['amount']:<4} | "
                             f"{trans['rating']}/10 | {trans_type:<4} |")
            
            report.append("      " + "-" * 85)
        
        report.append("")
    
    # 全局特征分析
    report.append("三、全局刷单特征分析")
    report.append("-" * 60)
    
    fraud_transactions = [t for t in transactions if t['type'] == 'fraud']
    normal_transactions = [t for t in transactions if t['type'] == 'normal']
    
    if fraud_transactions and normal_transactions:
        report.append("📈 10分制评分特征对比:")
        report.append(f"   • 平均评分: 刷单{np.mean([t['rating'] for t in fraud_transactions]):.2f}/10 vs 正常{np.mean([t['rating'] for t in normal_transactions]):.2f}/10")
        report.append(f"   • 评分标准差: 刷单{np.std([t['rating'] for t in fraud_transactions]):.2f} vs 正常{np.std([t['rating'] for t in normal_transactions]):.2f}")
        report.append(f"   • 满分比例: 刷单{len([t for t in fraud_transactions if t['rating'] == 10])/len(fraud_transactions)*100:.1f}% vs 正常{len([t for t in normal_transactions if t['rating'] == 10])/len(normal_transactions)*100:.1f}%")
        report.append("")
        
        report.append("💰 交易特征对比:")
        report.append(f"   • 平均数量: 刷单{np.mean([t['quantity'] for t in fraud_transactions]):.1f} vs 正常{np.mean([t['quantity'] for t in normal_transactions]):.1f}")
        report.append(f"   • 平均金额: 刷单￥{np.mean([t['amount'] for t in fraud_transactions]):.0f} vs 正常￥{np.mean([t['amount'] for t in normal_transactions]):.0f}")
        report.append(f"   • 价格离散度: 刷单{np.std([t['price'] for t in fraud_transactions]):.1f} vs 正常{np.std([t['price'] for t in normal_transactions]):.1f}")
    
    report.append("")
    report.append("🎯 检测算法说明:")
    report.append("   本系统采用9维度检测方法:")
    report.append("   1. 成员构成分析 (刷单小号/卖家比例)")
    report.append("   2. 交易模式分析 (刷单交易比例)") 
    report.append("   3. 评分异常度 (10分制评分分布)")
    report.append("   4. 交易模式异常度 (数量/价格一致性)")
    report.append("   5. 买家外向度 (跨社区交易比例)")
    report.append("   6. 卖家集中度 (交易集中程度)")
    report.append("   7. 价格一致性 (价格变化程度)")
    report.append("   8. 数量异常度 (单件购买比例)")
    report.append("   9. 社区发现算法 (网络结构分析)")
    report.append("")
    
    report.append("💡 处理建议:")
    report.append("   1. 对高风险社区立即进行全面审查")
    report.append("   2. 重点关注评分异常度高和交易模式固定的社区")
    report.append("   3. 监控外向度低、集中度高的封闭社区")
    report.append("   4. 建立多维度实时检测预警机制")
    report.append("")
    
    report.append("=" * 120)
    report.append("                          报告结束")
    report.append("=" * 120)
    
    return report

# 7. 生成并显示报告
print("\n📋 生成增强版刷单检测报告...")
report = generate_enhanced_fraud_detection_report()

# 打印报告
for line in report:
    print(line)

# 保存报告
report_filename = f"enhanced_fraud_detection_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
with open(report_filename, 'w', encoding='utf-8') as f:
    for line in report:
        f.write(line + '\n')

print(f"\n✅ 增强版刷单检测报告已保存至: {report_filename}")
print("🎯 新增特色功能:")
print("   • 10分制评分体系")
print("   • 6个新增异常检测参数")
print("   • 9维度综合嫌疑度评分")
print("   • 多维度特征对比分析")