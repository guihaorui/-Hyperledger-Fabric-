# 专业交易网络分析报告
print("=== 交易网络分析报告生成 ===")

import networkx as nx
import community as community_louvain
import random
import numpy as np
from collections import defaultdict
from datetime import datetime

print("✅ 库导入成功")

# 设置随机种子
random.seed(42)
np.random.seed(42)

# 1. 创建交易网络
print("🔄 创建交易网络数据...")

buyers = [f"买家_{i}" for i in range(1, 21)]
sellers = [f"卖家_{i}" for i in range(1, 16)]

transactions = []
products = ["电子产品", "服装", "食品", "书籍", "家居用品"]
product_categories = {
    "电子产品": "高价值",
    "服装": "中价值", 
    "食品": "快消品",
    "书籍": "低价值",
    "家居用品": "中价值"
}

seller_specialties = {}
for seller in sellers:
    specialty = random.choice(products)
    base_price = random.randint(50, 500)
    seller_specialties[seller] = {
        'specialty': specialty,
        'base_price': base_price,
        'price_range': (base_price * 0.7, base_price * 1.3),
        'category': product_categories[specialty]
    }

for i in range(100):
    buyer = random.choice(buyers)
    seller = random.choice(sellers)
    specialty_info = seller_specialties[seller]
    price = random.randint(int(specialty_info['price_range'][0]), 
                          int(specialty_info['price_range'][1]))
    
    transactions.append({
        'transaction_id': i + 1,
        'buyer': buyer,
        'seller': seller,
        'product': specialty_info['specialty'],
        'category': specialty_info['category'],
        'price': price,
        'quantity': random.randint(1, 5),
        'amount': price * random.randint(1, 5)
    })

# 构建网络
G = nx.Graph()
G.add_nodes_from(buyers, node_type='buyer')
G.add_nodes_from(sellers, node_type='seller')

transaction_weights = defaultdict(float)
transaction_counts = defaultdict(int)

for transaction in transactions:
    buyer = transaction['buyer']
    seller = transaction['seller']
    trade_volume = transaction['amount']
    
    key = (buyer, seller)
    transaction_weights[key] += trade_volume
    transaction_counts[key] += 1

for (buyer, seller), weight in transaction_weights.items():
    G.add_edge(buyer, seller, weight=weight, transactions=transaction_counts[(buyer, seller)])

# 运行社区发现
partition = community_louvain.best_partition(G, weight='weight')
modularity = community_louvain.modularity(partition, G, weight='weight')

print("✅ 数据分析完成，生成报告中...")

# 2. 生成专业分析报告
def generate_trade_analysis_report():
    """生成交易网络分析报告"""
    
    # 基本统计
    total_transactions = len(transactions)
    total_volume = sum(transaction['amount'] for transaction in transactions)
    avg_transaction_value = total_volume / total_transactions
    
    # 社区分析
    communities = set(partition.values())
    community_members = defaultdict(list)
    community_buyers = defaultdict(list)
    community_sellers = defaultdict(list)
    community_volume = defaultdict(float)
    
    for node, comm_id in partition.items():
        community_members[comm_id].append(node)
        if '买家' in node:
            community_buyers[comm_id].append(node)
        else:
            community_sellers[comm_id].append(node)
    
    # 计算社区内交易额
    for transaction in transactions:
        buyer = transaction['buyer']
        seller = transaction['seller']
        if partition[buyer] == partition[seller]:
            community_volume[partition[buyer]] += transaction['amount']
    
    # 买家分析
    buyer_expenditure = defaultdict(float)
    for transaction in transactions:
        buyer_expenditure[transaction['buyer']] += transaction['amount']
    
    # 卖家分析  
    seller_income = defaultdict(float)
    for transaction in transactions:
        seller_income[transaction['seller']] += transaction['amount']
    
    # 产品分析
    product_sales = defaultdict(float)
    category_sales = defaultdict(float)
    for transaction in transactions:
        product_sales[transaction['product']] += transaction['amount']
        category_sales[transaction['category']] += transaction['amount']
    
    # 网络指标
    node_trade_power = {}
    for node in G.nodes():
        trade_power = sum(G[node][neighbor]['weight'] for neighbor in G.neighbors(node))
        node_trade_power[node] = trade_power
    
    # 生成报告
    report = []
    report.append("=" * 80)
    report.append("                   交易网络分析报告")
    report.append("=" * 80)
    report.append(f"生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    report.append(f"数据范围: {len(transactions)} 笔交易记录")
    report.append("")
    
    # 执行摘要
    report.append("一、执行摘要")
    report.append("-" * 40)
    report.append(f"• 交易总额: ￥{total_volume:,.2f}")
    report.append(f"• 平均单笔交易: ￥{avg_transaction_value:,.2f}")
    report.append(f"• 网络规模: {G.number_of_nodes()} 个节点 ({len(buyers)} 买家 + {len(sellers)} 卖家)")
    report.append(f"• 交易关系: {G.number_of_edges()} 条")
    report.append(f"• 发现社区: {len(communities)} 个")
    report.append(f"• 网络模块度: {modularity:.3f}")
    report.append("")
    
    # 社区分析
    report.append("二、社区结构分析")
    report.append("-" * 40)
    for comm_id in sorted(communities):
        buyers_count = len(community_buyers[comm_id])
        sellers_count = len(community_sellers[comm_id])
        volume = community_volume[comm_id]
        share = (volume / total_volume) * 100
        
        report.append(f"社区 {comm_id}:")
        report.append(f"  • 规模: {buyers_count + sellers_count} 成员 ({buyers_count} 买家 + {sellers_count} 卖家)")
        report.append(f"  • 交易额: ￥{volume:,.2f} ({share:.1f}%)")
        report.append(f"  • 买家: {', '.join(community_buyers[comm_id][:3])}{'...' if len(community_buyers[comm_id]) > 3 else ''}")
        report.append(f"  • 卖家: {', '.join(community_sellers[comm_id][:3])}{'...' if len(community_sellers[comm_id]) > 3 else ''}")
        report.append("")
    
    # 关键参与者
    report.append("三、关键参与者分析")
    report.append("-" * 40)
    
    report.append("TOP 5 买家 (按消费额):")
    top_buyers = sorted(buyer_expenditure.items(), key=lambda x: x[1], reverse=True)[:5]
    for i, (buyer, amount) in enumerate(top_buyers, 1):
        report.append(f"  {i}. {buyer}: ￥{amount:,.2f} (社区{partition[buyer]})")
    
    report.append("")
    report.append("TOP 5 卖家 (按销售额):")
    top_sellers = sorted(seller_income.items(), key=lambda x: x[1], reverse=True)[:5]
    for i, (seller, amount) in enumerate(top_sellers, 1):
        report.append(f"  {i}. {seller}: ￥{amount:,.2f} (社区{partition[seller]})")
    
    report.append("")
    
    # 产品分析
    report.append("四、产品类别分析")
    report.append("-" * 40)
    
    report.append("按产品类型:")
    for product, sales in sorted(product_sales.items(), key=lambda x: x[1], reverse=True):
        share = (sales / total_volume) * 100
        report.append(f"  • {product}: ￥{sales:,.2f} ({share:.1f}%)")
    
    report.append("")
    report.append("按价值类别:")
    for category, sales in sorted(category_sales.items(), key=lambda x: x[1], reverse=True):
        share = (sales / total_volume) * 100
        report.append(f"  • {category}: ￥{sales:,.2f} ({share:.1f}%)")
    
    report.append("")
    
    # 网络特征
    report.append("五、网络特征分析")
    report.append("-" * 40)
    
    # 度中心性
    degree_centrality = nx.degree_centrality(G)
    top_central_nodes = sorted(degree_centrality.items(), key=lambda x: x[1], reverse=True)[:3]
    
    report.append("网络中心性 (连接重要性):")
    for node, centrality in top_central_nodes:
        node_type = "买家" if "买家" in node else "卖家"
        report.append(f"  • {node} ({node_type}): {centrality:.3f}")
    
    # 聚类系数
    avg_clustering = nx.average_clustering(G)
    report.append(f"平均聚类系数: {avg_clustering:.3f}")
    
    # 社区内聚性
    report.append("社区内聚性分析:")
    for comm_id in sorted(communities):
        subgraph = G.subgraph(community_members[comm_id])
        internal_edges = subgraph.number_of_edges()
        possible_edges = len(community_members[comm_id]) * (len(community_members[comm_id]) - 1) / 2
        cohesion = internal_edges / possible_edges if possible_edges > 0 else 0
        
        report.append(f"  社区 {comm_id}: 内聚性 {cohesion:.3f} ({internal_edges}/{int(possible_edges)} 边)")
    
    report.append("")
    
    # 商业洞察
    report.append("六、商业洞察与建议")
    report.append("-" * 40)
    
    # 找到跨社区交易
    cross_community_trade = 0
    for transaction in transactions:
        if partition[transaction['buyer']] != partition[transaction['seller']]:
            cross_community_trade += transaction['amount']
    
    cross_community_ratio = (cross_community_trade / total_volume) * 100
    
    report.append(f"1. 市场细分: 发现 {len(communities)} 个自然形成的交易社区")
    report.append(f"2. 社区独立性: {100-cross_community_ratio:.1f}% 的交易发生在社区内部")
    report.append(f"3. 核心客户: 前5大买家贡献 {sum([amt for _, amt in top_buyers])/total_volume*100:.1f}% 的交易额")
    report.append(f"4. 核心供应商: 前5大卖家贡献 {sum([amt for _, amt in top_sellers])/total_volume*100:.1f}% 的交易额")
    report.append("")
    report.append("战略建议:")
    report.append("• 针对每个社区制定差异化营销策略")
    report.append("• 重点关注高价值客户和供应商的关系维护")
    report.append("• 利用社区结构优化供应链布局")
    report.append("• 监测跨社区交易机会以拓展市场")
    
    report.append("")
    report.append("=" * 80)
    report.append("                      报告结束")
    report.append("=" * 80)
    
    return report

# 3. 生成并保存报告
report = generate_trade_analysis_report()

# 打印报告到控制台
for line in report:
    print(line)

# 保存报告到文件
report_filename = f"trade_analysis_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
with open(report_filename, 'w', encoding='utf-8') as f:
    for line in report:
        f.write(line + '\n')

print(f"\n✅ 分析报告已保存至: {report_filename}")
print("📊 报告包含:")
print("   • 执行摘要")
print("   • 社区结构分析") 
print("   • 关键参与者排名")
print("   • 产品类别分析")
print("   • 网络特征分析")
print("   • 商业洞察与建议")