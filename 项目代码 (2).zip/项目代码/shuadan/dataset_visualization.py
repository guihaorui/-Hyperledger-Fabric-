# 第二课：可视化数据集结果
print("=== 可视化空手道俱乐部社区结构 ===")

import networkx as nx
import community as community_louvain
import matplotlib.pyplot as plt
from collections import Counter

print("✅ 库导入成功")

# 1. 加载数据集并运行算法
G = nx.karate_club_graph()
partition = community_louvain.best_partition(G)
modularity = community_louvain.modularity(partition, G)

# 统计社区信息
communities = set(partition.values())
community_sizes = Counter(partition.values())

print(f"📊 准备可视化:")
print(f"   • 节点数: {G.number_of_nodes()}")
print(f"   • 社区数: {len(communities)}")
print(f"   • 模块度: {modularity:.3f}")

# 2. 创建图形窗口
plt.figure(figsize=(14, 10))

# 3. 计算节点布局 - 让图形看起来更整齐
print("🔄 计算节点布局...")
pos = nx.spring_layout(G, seed=42, k=1, iterations=50)

# 4. 准备颜色 - 为每个社区分配不同颜色
# 使用鲜艳的颜色让社区更明显
colors = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7', '#DDA0DD', '#98D8C8', '#F7DC6F']
node_colors = [colors[partition[node] % len(colors)] for node in G.nodes()]

# 5. 绘制节点（人物）
print("🎨 绘制节点...")
nx.draw_networkx_nodes(G, pos,
                      node_color=node_colors,
                      node_size=400,
                      alpha=0.9,
                      edgecolors='black',
                      linewidths=0.5)

# 6. 绘制边（关系）
print("📏 绘制连接关系...")
nx.draw_networkx_edges(G, pos,
                      alpha=0.4,
                      width=1.0,
                      edge_color='gray')

# 7. 绘制节点标签（人物编号）
print("🏷️  添加人物标签...")
nx.draw_networkx_labels(G, pos,
                       font_size=8,
                       font_weight='bold')

# 8. 添加标题和装饰
plt.title("空手道俱乐部社交网络 - 社区发现结果\n"
          f"Louvain算法发现 {len(communities)} 个社区 | 模块度: {modularity:.3f}", 
          fontsize=14, pad=20, fontweight='bold')

plt.axis('off')  # 隐藏坐标轴

# 9. 添加图例说明
legend_elements = []
for comm_id in sorted(communities):
    color = colors[comm_id % len(colors)]
    size = community_sizes[comm_id]
    legend_elements.append(plt.Line2D([0], [0], 
                          marker='o', 
                          color='w', 
                          markerfacecolor=color, 
                          markersize=10, 
                          label=f'社区 {comm_id} ({size}人)'))

plt.legend(handles=legend_elements, 
           loc='upper left',
           bbox_to_anchor=(0, 1),
           frameon=True,
           fancybox=True,
           shadow=True)

# 10. 添加数据来源说明
plt.figtext(0.5, 0.01, 
           "数据来源: Zachary's Karate Club (1977) - 真实社会学研究", 
           ha="center", fontsize=9, style='italic')

plt.tight_layout()

print("✅ 可视化准备完成！正在显示图形...")
plt.show()

print("\n🎉 可视化成功！")
print("💡 观察要点:")
print("   • 相同颜色的人物属于同一个社区")
print("   • 连接密集的区域表示关系紧密的群体")
print("   • 社区间的稀疏连接是不同群体的桥梁")