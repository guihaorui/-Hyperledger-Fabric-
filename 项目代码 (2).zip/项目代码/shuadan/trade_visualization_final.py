# 最终课：可视化交易网络
print("=== 可视化交易网络社区 ===")

import networkx as nx
import community as community_louvain
import matplotlib.pyplot as plt
import random
import numpy as np
from collections import defaultdict

print("✅ 库导入成功")

# 设置随机种子
random.seed(42)
np.random.seed(42)

# 1. 创建交易网络（完整代码）
print("🔄 创建交易网络...")

buyers = [f"买家_{i}" for i in range(1, 21)]
sellers = [f"卖家_{i}" for i in range(1, 16)]

transactions = []
products = ["电子产品", "服装", "食品", "书籍", "家居用品"]

seller_specialties = {}
for seller in sellers:
    specialty = random.choice(products)
    base_price = random.randint(50, 500)
    seller_specialties[seller] = {
        'specialty': specialty,
        'base_price': base_price,
        'price_range': (base_price * 0.7, base_price * 1.3)
    }

for i in range(100):
    buyer = random.choice(buyers)
    seller = random.choice(sellers)
    specialty_info = seller_specialties[seller]
    price = random.randint(int(specialty_info['price_range'][0]), 
                          int(specialty_info['price_range'][1]))
    product = specialty_info['specialty']
    
    transactions.append({
        'buyer': buyer,
        'seller': seller,
        'product': product,
        'price': price,
        'quantity': random.randint(1, 5)
    })

# 构建无向图
G = nx.Graph()
G.add_nodes_from(buyers, node_type='buyer')
G.add_nodes_from(sellers, node_type='seller')

transaction_weights = defaultdict(float)
for transaction in transactions:
    buyer = transaction['buyer']
    seller = transaction['seller']
    trade_volume = transaction['price'] * transaction['quantity']
    key = (buyer, seller)
    transaction_weights[key] += trade_volume

for (buyer, seller), weight in transaction_weights.items():
    G.add_edge(buyer, seller, weight=weight)

# 运行社区发现
partition = community_louvain.best_partition(G, weight='weight')
modularity = community_louvain.modularity(partition, G, weight='weight')

print(f"✅ 网络构建完成: {G.number_of_nodes()}节点, {G.number_of_edges()}边")
print(f"   发现 {len(set(partition.values()))} 个交易社区")

# 2. 创建可视化
print("\n🎨 创建交易网络可视化...")

plt.figure(figsize=(16, 12))

# 使用spring布局，但让买家和卖家稍微分开
pos = nx.spring_layout(G, seed=42, k=2, iterations=100)

# 3. 准备可视化数据
community_members = defaultdict(list)
for node, comm_id in partition.items():
    community_members[comm_id].append(node)

# 颜色方案
community_colors = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7', '#DDA0DD', '#98D8C8']

# 4. 绘制节点 - 区分买家和卖家
node_colors = []
node_sizes = []
node_shapes = []

for node in G.nodes():
    comm_id = partition[node]
    color = community_colors[comm_id % len(community_colors)]
    node_colors.append(color)
    
    # 节点大小基于交易额
    trade_power = sum(G[node][neighbor]['weight'] for neighbor in G.neighbors(node))
    node_sizes.append(300 + trade_power * 0.1)
    
    # 节点形状区分买家和卖家
    if '买家' in node:
        node_shapes.append('o')  # 圆形表示买家
    else:
        node_shapes.append('s')  # 方形表示卖家

# 5. 分别绘制买家和卖家
buyers_list = [node for node in G.nodes() if '买家' in node]
sellers_list = [node for node in G.nodes() if '卖家' in node]

# 绘制买家节点（圆形）
nx.draw_networkx_nodes(G, pos, 
                      nodelist=buyers_list,
                      node_color=[node_colors[list(G.nodes()).index(node)] for node in buyers_list],
                      node_size=[node_sizes[list(G.nodes()).index(node)] for node in buyers_list],
                      alpha=0.9,
                      edgecolors='black',
                      linewidths=1,
                      node_shape='o')

# 绘制卖家节点（方形）
nx.draw_networkx_nodes(G, pos, 
                      nodelist=sellers_list,
                      node_color=[node_colors[list(G.nodes()).index(node)] for node in sellers_list],
                      node_size=[node_sizes[list(G.nodes()).index(node)] for node in sellers_list],
                      alpha=0.9,
                      edgecolors='black',
                      linewidths=1,
                      node_shape='s')

# 6. 绘制边 - 根据权重调整粗细
edges = G.edges()
weights = [G[u][v]['weight'] for u, v in edges]

# 归一化权重用于线宽
max_weight = max(weights)
min_weight = min(weights)
if max_weight > min_weight:
    edge_widths = [1 + 3 * (w - min_weight) / (max_weight - min_weight) for w in weights]
else:
    edge_widths = [2] * len(weights)

nx.draw_networkx_edges(G, pos,
                      width=edge_widths,
                      alpha=0.6,
                      edge_color='gray')

# 7. 绘制标签 - 只显示重要的节点
important_nodes = []
node_trade_power = {}

for node in G.nodes():
    trade_power = sum(G[node][neighbor]['weight'] for neighbor in G.neighbors(node))
    node_trade_power[node] = trade_power

# 只显示交易额前40%的节点标签
threshold = np.percentile(list(node_trade_power.values()), 60)
labels = {node: node for node in G.nodes() if node_trade_power[node] >= threshold}

nx.draw_networkx_labels(G, pos,
                       labels=labels,
                       font_size=8,
                       font_weight='bold')

# 8. 添加标题和图例
plt.title("交易网络社区发现分析\n"
          f"Louvain算法发现 {len(set(partition.values()))} 个交易社区 | 模块度: {modularity:.3f}\n"
          "○: 买家  □: 卖家 | 连线粗细表示交易额", 
          fontsize=14, pad=20, fontweight='bold')

plt.axis('off')

# 9. 添加详细图例
legend_elements = []

# 社区图例
for comm_id in sorted(community_members.keys()):
    color = community_colors[comm_id % len(community_colors)]
    buyers_in_comm = len([n for n in community_members[comm_id] if '买家' in n])
    sellers_in_comm = len([n for n in community_members[comm_id] if '卖家' in n])
    
    legend_elements.append(plt.Line2D([0], [0], 
                          marker='o', 
                          color='w', 
                          markerfacecolor=color, 
                          markersize=10, 
                          label=f'社区 {comm_id}: {buyers_in_comm}买家 + {sellers_in_comm}卖家'))

# 节点类型图例
legend_elements.append(plt.Line2D([0], [0], 
                      marker='o', 
                      color='w', 
                      markerfacecolor='gray', 
                      markersize=10, 
                      label='○: 买家'))

legend_elements.append(plt.Line2D([0], [0], 
                      marker='s', 
                      color='w', 
                      markerfacecolor='gray', 
                      markersize=10, 
                      label='□: 卖家'))

plt.legend(handles=legend_elements, 
           loc='center left',
           bbox_to_anchor=(1, 0.5),
           frameon=True,
           fancybox=True,
           shadow=True,
           fontsize=10)

# 10. 添加统计信息框
stats_text = f"""网络统计:
• 总节点: {G.number_of_nodes()}个
• 买家: {len(buyers)}个
• 卖家: {len(sellers)}个  
• 交易边: {G.number_of_edges()}条
• 总交易额: ￥{sum(transaction_weights.values()):.2f}
• 模块度: {modularity:.3f}

交易额排行:
买家: {max([(k,v) for k,v in node_trade_power.items() if '买家' in k], key=lambda x: x[1])[0]}
卖家: {max([(k,v) for k,v in node_trade_power.items() if '卖家' in k], key=lambda x: x[1])[0]}"""

plt.figtext(0.02, 0.02, stats_text, fontsize=9, 
           bbox=dict(boxstyle="round,pad=0.5", facecolor="lightgray", alpha=0.8))

plt.tight_layout()

print("✅ 可视化准备完成！正在显示图形...")
plt.show()

print("\n🎉 交易网络分析完整流程完成！")
print("💡 从数据中我们发现了:")
print("   • 自然的交易社区形成")
print("   • 买家和卖家的聚集模式")
print("   • 关键的交易中心人物")
print("   • 社区间的交易桥梁")