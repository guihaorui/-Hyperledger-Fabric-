"""
自定义Louvain算法实现，用于刷单检测。
基于用户描述的两个阶段：模块度优化和社区聚合。
"""

import random
import networkx as nx
from collections import defaultdict

def compute_modularity(graph, partition, weight='weight'):
    """
    计算模块度Q
    Q = (1/2m) * Σ_ij [Aij - (ki*kj / 2m)] * δ(ci, cj)
    其中Aij是边权重，ki是节点i的度，m是总权重，δ是社区指示函数（同一社区为1）
    """
    if graph.number_of_edges() == 0:
        return 0.0

    # 计算总权重m
    m = sum(d.get(weight, 1) for _, _, d in graph.edges(data=True))
    if m == 0:
        return 0.0

    # 计算每个节点的度
    degrees = {}
    for node in graph.nodes():
        degrees[node] = sum(d.get(weight, 1) for _, _, d in graph.edges(node, data=True))

    # 计算模块度
    q = 0.0
    for u, v, data in graph.edges(data=True):
        w = data.get(weight, 1)
        # 确保节点在partition中
        if u not in partition or v not in partition:
            continue
        if partition[u] == partition[v]:
            q += w - (degrees[u] * degrees[v]) / (2 * m)

    return q / (2 * m)

def phase_one_modularity_optimization(graph, weight='weight', random_seed=None):
    """
    阶段一：模块度优化
    将每个节点视为独立社区，然后尝试移动节点以提升模块度
    返回节点到社区的映射
    """
    if random_seed is not None:
        random.seed(random_seed)

    # 初始化：每个节点一个社区
    partition = {node: i for i, node in enumerate(graph.nodes())}

    # 计算总权重m
    m = sum(d.get(weight, 1) for _, _, d in graph.edges(data=True))
    if m == 0:
        return partition

    # 计算每个节点的度
    degrees = {}
    for node in graph.nodes():
        degrees[node] = sum(d.get(weight, 1) for _, _, d in graph.edges(node, data=True))

    # 构建邻接表和社区成员
    adj_list = defaultdict(dict)
    for u, v, data in graph.edges(data=True):
        w = data.get(weight, 1)
        adj_list[u][v] = w
        adj_list[v][u] = w

    # 社区内节点集合
    community_nodes = defaultdict(set)
    for node, comm in partition.items():
        community_nodes[comm].add(node)

    # 计算每个社区的总度Σtot（社区内所有节点的度之和）
    community_total_degree = defaultdict(float)
    for node, comm in partition.items():
        community_total_degree[comm] += degrees[node]

    # 计算每个节点与每个社区的内部连接权重
    # node_community_weights[node][comm] = 节点node与社区comm内节点的连接权重之和
    node_community_weights = defaultdict(lambda: defaultdict(float))
    for u, v, data in graph.edges(data=True):
        w = data.get(weight, 1)
        comm_u = partition[u]
        comm_v = partition[v]
        if comm_u == comm_v:
            # 内部连接，对两个节点都增加
            node_community_weights[u][comm_u] += w
            node_community_weights[v][comm_v] += w

    improved = True
    iteration = 0
    max_iterations = 100

    while improved and iteration < max_iterations:
        improved = False
        nodes = list(graph.nodes())
        random.shuffle(nodes)  # 随机顺序遍历

        for node in nodes:
            best_comm = partition[node]
            best_delta = 0.0

            # 当前社区
            current_comm = partition[node]

            # 计算从当前社区移除node的ΔQ
            # 公式：ΔQ_remove = - [Ai,in/2m - Σtot*ki/(2m)^2]
            Ai_in_current = node_community_weights[node][current_comm]
            sigma_tot_current = community_total_degree[current_comm]
            ki = degrees[node]

            delta_remove = - (Ai_in_current / (2 * m) - sigma_tot_current * ki / ((2 * m) ** 2))

            # 检查所有相邻社区（包括当前社区）
            neighbor_comms = set()
            # 添加当前社区
            neighbor_comms.add(current_comm)
            # 添加邻居节点所在社区
            for neighbor in adj_list[node].keys():
                neighbor_comms.add(partition[neighbor])

            for comm in neighbor_comms:
                if comm == current_comm:
                    continue

                # 计算将node移动到社区comm的ΔQ
                # 公式：ΔQ = Ai,in/2m - Σtot*ki/(2m)^2
                Ai_in = 0.0
                for neighbor, w in adj_list[node].items():
                    if partition[neighbor] == comm:
                        Ai_in += w

                sigma_tot = community_total_degree[comm]
                delta = (Ai_in / (2 * m) - sigma_tot * ki / ((2 * m) ** 2)) - delta_remove

                if delta > best_delta:
                    best_delta = delta
                    best_comm = comm

            # 如果找到正增益，移动节点
            if best_comm != current_comm and best_delta > 1e-10:
                # 执行移动
                # 1. 更新节点社区
                partition[node] = best_comm

                # 2. 更新社区总度
                community_total_degree[current_comm] -= ki
                community_total_degree[best_comm] += ki

                # 3. 更新节点与社区的内部连接权重
                # 对于当前社区的邻居，需要减少权重
                for neighbor, w in adj_list[node].items():
                    neighbor_comm = partition[neighbor]
                    if neighbor_comm == current_comm:
                        node_community_weights[node][current_comm] -= w
                        node_community_weights[neighbor][current_comm] -= w
                    elif neighbor_comm == best_comm:
                        node_community_weights[node][best_comm] += w
                        node_community_weights[neighbor][best_comm] += w

                # 4. 更新社区节点集合
                community_nodes[current_comm].remove(node)
                community_nodes[best_comm].add(node)

                improved = True

        iteration += 1

    return partition

def phase_two_community_aggregation(graph, partition, weight='weight'):
    """
    阶段二：社区聚合
    将每个社区压缩为超级节点，构建新图
    返回新图和社区到超级节点的映射
    """
    # 社区到超级节点的映射
    communities = set(partition.values())
    comm_to_supernode = {comm: f"super_{comm}" for comm in communities}
    supernode_to_comm = {f"super_{comm}": comm for comm in communities}

    # 创建新图
    new_graph = nx.Graph()

    # 添加超级节点
    for supernode in supernode_to_comm.keys():
        new_graph.add_node(supernode)

    # 计算社区间的边权重
    inter_community_weights = defaultdict(float)

    for u, v, data in graph.edges(data=True):
        w = data.get(weight, 1)
        comm_u = partition[u]
        comm_v = partition[v]

        if comm_u == comm_v:
            # 社区内部边，作为自环权重
            supernode = comm_to_supernode[comm_u]
            if new_graph.has_edge(supernode, supernode):
                new_graph[supernode][supernode]['weight'] += w
            else:
                new_graph.add_edge(supernode, supernode, weight=w)
        else:
            # 社区间边
            key = (min(comm_u, comm_v), max(comm_u, comm_v))
            inter_community_weights[key] += w

    # 添加社区间边
    for (comm1, comm2), w in inter_community_weights.items():
        super1 = comm_to_supernode[comm1]
        super2 = comm_to_supernode[comm2]
        new_graph.add_edge(super1, super2, weight=w)

    return new_graph, comm_to_supernode, supernode_to_comm

def custom_louvain(graph, weight='weight', random_seed=None, max_iterations=100):
    """
    自定义Louvain算法主函数
    返回节点到最终社区的映射
    """
    # 初始化：每个节点一个社区
    partition = {node: i for i, node in enumerate(graph.nodes())}

    # 计算初始模块度
    current_modularity = compute_modularity(graph, partition, weight)

    iteration = 0
    while iteration < max_iterations:
        # 阶段一：模块度优化
        partition = phase_one_modularity_optimization(graph, weight, random_seed)

        # 阶段二：社区聚合
        new_graph, comm_to_supernode, supernode_to_comm = phase_two_community_aggregation(graph, partition, weight)

        # 如果新图只有一个节点，停止
        if new_graph.number_of_nodes() <= 1:
            break

        # 在新图上递归调用
        super_partition = custom_louvain(new_graph, weight, random_seed, max_iterations)

        # 将超级节点的社区映射回原始节点
        new_partition = {}
        for node, old_comm in partition.items():
            supernode = comm_to_supernode[old_comm]
            new_comm = super_partition[supernode]
            # 映射回原始社区ID
            new_partition[node] = new_comm

        # 计算新模块度
        new_modularity = compute_modularity(graph, new_partition, weight)

        # 如果模块度提升不明显，停止
        if new_modularity - current_modularity < 1e-10:
            break

        partition = new_partition
        current_modularity = new_modularity
        graph = new_graph
        iteration += 1

    # 确保所有节点都在partition中
    missing_nodes = set(graph.nodes()) - set(partition.keys())
    for node in missing_nodes:
        partition[node] = 0  # 分配到默认社区

    # 重新标记社区ID为连续整数
    unique_comms = sorted(set(partition.values()))
    comm_mapping = {old: new for new, old in enumerate(unique_comms)}
    final_partition = {node: comm_mapping[comm] for node, comm in partition.items()}

    return final_partition

def detect_fraud_communities(graph, partition, weight='weight', threshold=0.8):
    """
    检测可疑的刷单社区
    基于社区内聚性（内部边权重占比）和评分异常
    返回可疑社区列表
    """
    suspicious = []

    # 计算每个社区的内部连接强度占比
    for comm in set(partition.values()):
        nodes_in_comm = [node for node, c in partition.items() if c == comm]
        if len(nodes_in_comm) < 2:
            continue

        # 创建子图
        subgraph = graph.subgraph(nodes_in_comm)

        # 计算社区内部总权重
        internal_weight = sum(d.get(weight, 1) for _, _, d in subgraph.edges(data=True))

        # 计算社区节点与外部连接的总权重
        external_weight = 0
        for node in nodes_in_comm:
            for neighbor in graph.neighbors(node):
                if partition[neighbor] != comm:
                    external_weight += graph[node][neighbor].get(weight, 1)

        total_weight = internal_weight + external_weight
        if total_weight == 0:
            continue

        internal_ratio = internal_weight / total_weight

        # 如果内部连接占比过高，可能是刷单社区
        if internal_ratio > threshold:
            suspicious.append({
                'community': comm,
                'nodes': nodes_in_comm,
                'internal_ratio': internal_ratio,
                'internal_weight': internal_weight,
                'external_weight': external_weight,
                'size': len(nodes_in_comm)
            })

    # 按内部连接占比排序
    suspicious.sort(key=lambda x: x['internal_ratio'], reverse=True)
    return suspicious

if __name__ == "__main__":
    # 测试代码
    import random

    # 创建测试图
    G = nx.Graph()
    nodes = list(range(10))
    G.add_nodes_from(nodes)

    # 添加一些边
    for i in range(10):
        for j in range(i+1, 10):
            if random.random() < 0.3:
                weight = random.randint(1, 10)
                G.add_edge(i, j, weight=weight)

    print("测试自定义Louvain算法")
    print(f"图节点数: {G.number_of_nodes()}, 边数: {G.number_of_edges()}")

    partition = custom_louvain(G, weight='weight', random_seed=42)
    print(f"发现社区数: {len(set(partition.values()))}")

    modularity = compute_modularity(G, partition, weight='weight')
    print(f"模块度: {modularity:.4f}")

    # 检测可疑社区
    suspicious = detect_fraud_communities(G, partition, weight='weight', threshold=0.7)
    print(f"可疑社区数: {len(suspicious)}")
    for comm in suspicious:
        print(f"  社区 {comm['community']}: 内聚比 {comm['internal_ratio']:.3f}, 节点数 {comm['size']}")