"""
多元合谋检测 —— 跨规模验证测试
验证从 2人到 15人团伙的检测能力
"""

import sys
import os
import random
from collections import defaultdict

sys.path.insert(0, os.path.dirname(__file__))

import networkx as nx
import community as community_louvain

from shuadan_detection_system import (
    TradeGraphBuilder,
    FraudDetector,
    FraudScorer,
    MultiWayCollusionDetector,
    ReportGenerator,
)


def print_header(title):
    print("\n" + "=" * 70)
    print(f"  {title}")
    print("=" * 70)


def create_test_graph(gang_buyers, gang_sellers, gang_name,
                      normal_buyers=30, normal_sellers=20,
                      normal_tx=150, gang_tx_per_pair=3):
    """创建包含正常交易和一个指定规模刷单团伙的测试图"""
    transactions = []

    # 正常交易
    for _ in range(normal_tx):
        transactions.append({
            'buyer': f"N_B{random.randint(1, normal_buyers):03d}",
            'seller': f"N_S{random.randint(1, normal_sellers):03d}",
            'amount': random.randint(10, 1000),
            'rating': random.randint(3, 5)
        })

    # 刷单团伙: 买家-卖家全连接（或高密度连接）
    for buyer in gang_buyers:
        for seller in gang_sellers:
            for _ in range(gang_tx_per_pair):
                transactions.append({
                    'buyer': buyer,
                    'seller': seller,
                    'amount': random.randint(500, 1500),
                    'rating': 5
                })

    random.shuffle(transactions)

    builder = TradeGraphBuilder(
        transaction_count_weight=1.0,
        transaction_amount_weight=0.01,
        rating_weight=2.0
    )
    graph = builder.build_graph_from_transactions(transactions)
    return graph, transactions


def evaluate_detection(graph, gang_buyers, gang_sellers, gang_name):
    """评估多元检测和社区发现两种方法对指定团伙的检测效果"""
    all_gang_nodes = set(gang_buyers) | set(gang_sellers)

    # ---- 方法1: 社区发现（Louvain） ----
    detector = FraudDetector(fraud_threshold=0.5)
    result = detector.detect(graph, enable_multiway=True)

    # 社区发现结果
    communities = result['fraud_detection']['all_communities']
    best_comm_recall = 0.0
    best_comm_info = None
    for comm in communities:
        comm_nodes = set(comm['nodes'])
        overlap = len(comm_nodes & all_gang_nodes)
        recall = overlap / len(all_gang_nodes) if all_gang_nodes else 0
        if recall > best_comm_recall:
            best_comm_recall = recall
            best_comm_info = comm

    # ---- 方法2: 多元合谋检测 ----
    mw = result['multiway_detection']
    collusion_groups = mw.get('collusion_groups', [])

    best_mw_recall = 0.0
    best_mw_info = None
    for group in collusion_groups:
        group_nodes = set(group.get('nodes', []))
        overlap = len(group_nodes & all_gang_nodes)
        recall = overlap / len(all_gang_nodes) if all_gang_nodes else 0
        if recall > best_mw_recall:
            best_mw_recall = recall
            best_mw_info = group

    # 综合评估
    gang_size = len(all_gang_nodes)
    detected_community = best_comm_recall >= 0.7
    detected_multiway = best_mw_recall >= 0.7

    return {
        'gang_name': gang_name,
        'gang_size': gang_size,
        'n_buyers': len(gang_buyers),
        'n_sellers': len(gang_sellers),
        'gang_nodes': all_gang_nodes,

        # 社区发现
        'comm_recall': round(best_comm_recall, 3),
        'comm_detected': detected_community,
        'comm_score': round(best_comm_info['total_score'], 3) if best_comm_info else None,
        'comm_risk': best_comm_info['risk_level'] if best_comm_info else None,

        # 多元检测
        'mw_recall': round(best_mw_recall, 3),
        'mw_detected': detected_multiway,
        'mw_score': round(best_mw_info['total_score'], 3) if best_mw_info else None,
        'mw_risk': best_mw_info['risk_level'] if best_mw_info else None,
        'mw_method': best_mw_info.get('detection_method', 'N/A') if best_mw_info else None,
        'mw_scale_label': best_mw_info.get('gang_scale', 'N/A') if best_mw_info else None,
        'mw_completeness': best_mw_info.get('completeness', 0) if best_mw_info else 0,
    }


def run_all_tests():
    print_header("多元合谋检测 - 跨规模验证 (2人 ~ 15人)")

    random.seed(42)

    # 定义测试场景: (买家数, 卖家数, 场景名)
    test_configs = [
        # (buyers, sellers, name)
        (2, 1, "3人微型团伙 (2B+1S)"),
        (2, 2, "4人小型团伙 (2B+2S)"),
        (3, 2, "5人小型团伙 (3B+2S)"),
        (4, 2, "6人中小团伙 (4B+2S)"),
        (4, 3, "7人中型团伙 (4B+3S)"),
        (5, 3, "8人中型团伙 (5B+3S)"),
        (6, 3, "9人中型团伙 (6B+3S)"),
        (7, 3, "10人大型团伙 (7B+3S)"),     # 关键: 10人必须检测到
        (9, 4, "13人大型团伙 (9B+4S)"),
        (10, 5, "15人大型团伙 (10B+5S)"),
    ]

    results = []
    total_gangs = len(test_configs)

    for buyers_n, sellers_n, name in test_configs:
        gang_buyers = [f"G_{name[:3]}_B{i:02d}" for i in range(1, buyers_n + 1)]
        gang_sellers = [f"G_{name[:3]}_S{i:02d}" for i in range(1, sellers_n + 1)]
        gang_size = buyers_n + sellers_n

        graph, txs = create_test_graph(gang_buyers, gang_sellers, name)

        eval_result = evaluate_detection(graph, gang_buyers, gang_sellers, name)
        results.append(eval_result)

        # 打印单条结果
        status_comm = "V" if eval_result['comm_detected'] else "X"
        status_mw = "V" if eval_result['mw_detected'] else "X"
        print(f"\n  [{gang_size:2d}人] {name}:")
        print(f"    社区发现 [{status_comm}]: "
              f"召回={eval_result['comm_recall']:.0%}, "
              f"得分={eval_result['comm_score']}, "
              f"风险={eval_result['comm_risk']}")
        print(f"    多元检测 [{status_mw}]: "
              f"召回={eval_result['mw_recall']:.0%}, "
              f"得分={eval_result['mw_score']}, "
              f"风险={eval_result['mw_risk']}, "
              f"规模标签={eval_result['mw_scale_label']}, "
              f"方法={eval_result['mw_method']}")

    # ================================================================
    # 汇总报告
    # ================================================================
    print_header("汇总报告")

    comm_detected = sum(1 for r in results if r['comm_detected'])
    mw_detected = sum(1 for r in results if r['mw_detected'])
    both_detected = sum(1 for r in results if r['comm_detected'] and r['mw_detected'])
    either_detected = sum(1 for r in results if r['comm_detected'] or r['mw_detected'])

    print(f"\n  总测试场景: {total_gangs} (2人 ~ 15人)")
    print(f"  Louvain社区发现 检出: {comm_detected}/{total_gangs} ({comm_detected/total_gangs:.0%})")
    print(f"  多元合谋检测 检出:   {mw_detected}/{total_gangs} ({mw_detected/total_gangs:.0%})")
    print(f"  两者皆检出:           {both_detected}/{total_gangs} ({both_detected/total_gangs:.0%})")
    print(f"  至少一种检出:         {either_detected}/{total_gangs} ({either_detected/total_gangs:.0%})")

    # 按规模分析
    header = f"\n  {'规模':<15} {'团伙':<25} {'社区召回':>8} {'多元召回':>8} {'多元方法':>12} {'风险':>6}"
    print(header)
    sep = f"  {'-'*15} {'-'*25} {'-'*8} {'-'*8} {'-'*12} {'-'*6}"
    print(sep)
    for r in results:
        gs = str(r["gang_size"]) + "人"
        line = (f"  {gs:<15} {r['gang_name']:<25} "
                f"{r['comm_recall']:>7.0%} {r['mw_recall']:>7.0%} "
                f"{str(r['mw_method']):>12} {str(r.get('mw_risk', 'N/A')):>6}")
        print(line)

    # 关键验证
    print(f"\n  关键验证:")
    large_gangs = [r for r in results if r['gang_size'] >= 10]
    for r in large_gangs:
        status = "PASS" if r['mw_detected'] else "FAIL"
        print(f"    [{status}] {r['gang_size']}人团伙 ({r['gang_name']}): "
              f"多元检测{'成功' if r['mw_detected'] else '失败'} "
              f"(得分={r['mw_score']}, 方法={r['mw_method']})")

    # 方法统计
    methods_used = defaultdict(int)
    for r in results:
        methods_used[r['mw_method']] += 1
    print(f"\n  检测方法使用分布: {dict(methods_used)}")

    return results


def test_standalone_multiway():
    """单独测试 MultiWayCollusionDetector 在极端场景下的表现"""
    print_header("MultiWayCollusionDetector 单独测试")

    # 场景: 只有刷单团伙，没有正常交易（最纯的场景）
    gang_buyers = [f"FB{i:02d}" for i in range(1, 8)]   # 7 买家
    gang_sellers = [f"FS{i:02d}" for i in range(1, 4)]  # 3 卖家

    transactions = []
    for b in gang_buyers:
        for s in gang_sellers:
            for _ in range(4):
                transactions.append({
                    'buyer': b, 'seller': s,
                    'amount': 1000, 'rating': 5
                })

    builder = TradeGraphBuilder()
    graph = builder.build_graph_from_transactions(transactions)

    mw = MultiWayCollusionDetector(
        biclique_min_buyers=2,
        biclique_min_sellers=2,
        biclique_completeness=0.7
    )
    result = mw.detect_all(graph)

    print(f"\n  图规模: {graph.number_of_nodes()} 节点, {graph.number_of_edges()} 边")
    print(f"  K-Core层数: {len(result['k_cores'])}")
    for kc in result['k_cores'][:3]:
        print(f"    k={kc['k_level']}: {kc['size']}节点, "
              f"密度={kc['core_density']:.3f}")

    print(f"\n  二分团数量: {len(result['bicliques'])}")
    for bc in result['bicliques'][:3]:
        print(f"    {bc['total_size']}人 (B={bc['n_buyers']}/S={bc['n_sellers']}), "
              f"完备率={bc['completeness']:.3f}, "
              f"金额CV={bc.get('amount_cv', 'N/A')}")

    print(f"\n  N-Clique数量: {len(result['near_cliques'])}")

    print(f"\n  合谋团伙 (去重评分后): {result['summary']['total_groups']} 个")
    for g in result['collusion_groups'][:5]:
        print(f"    [{g['risk_label']}] {g['gang_scale']}: "
              f"{g['size']}人 得分={g['total_score']:.3f} "
              f"方法={g['detection_method']}")

    # 验证: 10人团伙应该被检测为高风险
    top = result['collusion_groups'][0] if result['collusion_groups'] else None
    if top and top['size'] == 10 and top['risk_level'] == 'high':
        print(f"\n  [PASS] 10人团伙检测成功，得分={top['total_score']:.3f}，高风险")
        return True
    else:
        print(f"\n  [WARN] 10人团伙检测需要检查: "
              f"size={top['size'] if top else 'N/A'}, "
              f"risk={top.get('risk_level', 'N/A') if top else 'N/A'}")
        return False


if __name__ == "__main__":
    random.seed(42)

    # 测试1: 单独测试
    standalone_ok = test_standalone_multiway()

    # 测试2: 跨规模测试
    results = run_all_tests()

    print("\n" + "=" * 70)
    print("  全部测试完成")
    print("=" * 70)
