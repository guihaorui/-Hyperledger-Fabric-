# 第三课：深入分析社区结构
print("=== 深入分析社区结构 ===")

import networkx as nx
import community as community_louvain
import matplotlib.pyplot as plt
from collections import defaultdict
import numpy as np

print("✅ 库导入成功")

# 1. 加载数据集
G = nx.karate_club_graph()
partition = community_louvain.best_partition(G)
modularity = community_louvain.modularity(partition, G)

print("🔍 正在深入分析社区特征...")

# 2. 组织社区成员信息
community_members = defaultdict(list)
for node, comm_id in partition.items():
    community_members[comm_id].append(node)

print(f"\n📋 各社区详细信息：")
print("=" * 50)

# 3. 分析每个社区的内部结构
community_stats = {}

for comm_id, members in sorted(community_members.items()):
    # 创建社区子图
    subgraph = G.subgraph(members)
    
    # 计算各种指标
    internal_edges = subgraph.number_of_edges()
    density = nx.density(subgraph)
    
    # 找到社区内连接最多的人（中心人物）
    degrees_in_community = {node: G.degree(node) for node in members}
    center_person = max(degrees_in_community, key=degrees_in_community.get)
    
    community_stats[comm_id] = {
        'size': len(members),
        'internal_edges': internal_edges,
        'density': density,
        'center_person': center_person,
        'center_degree': degrees_in_community[center_person],
        'members': members
    }
    
    print(f"\n🏘️  社区 {comm_id}:")
    print(f"   • 成员数量: {len(members)} 人")
    print(f"   • 内部连接数: {internal_edges} 条")
    print(f"   • 网络密度: {density:.3f} (1.0表示完全连接)")
    print(f"   • 中心人物: 成员 {center_person} (有 {degrees_in_community[center_person]} 个连接)")
    print(f"   • 成员列表: {sorted(members)}")

# 4. 分析社区间的连接（桥梁关系）
print(f"\n🔗 社区间的连接桥梁：")
print("=" * 50)

# 统计社区间的连接
between_community_edges = defaultdict(int)
bridge_edges = []

for edge in G.edges():
    node1, node2 = edge
    comm1, comm2 = partition[node1], partition[node2]
    
    if comm1 != comm2:  # 社区间的连接
        between_community_edges[(min(comm1, comm2), max(comm1, comm2))] += 1
        bridge_edges.append((node1, node2))

print("   社区间的桥梁连接统计：")
for (comm1, comm2), count in sorted(between_community_edges.items()):
    print(f"   社区 {comm1} ↔ 社区 {comm2}: {count} 条桥梁边")

# 5. 找到最重要的桥梁人物
print(f"\n🌉 关键桥梁人物分析：")
print("=" * 50)

bridge_people = defaultdict(int)
for node1, node2 in bridge_edges:
    bridge_people[node1] += 1
    bridge_people[node2] += 1

if bridge_people:
    top_bridge_person = max(bridge_people, key=bridge_people.get)
    print(f"   最重要的桥梁人物: 成员 {top_bridge_person}")
    print(f"   他连接了 {bridge_people[top_bridge_person]} 个不同社区的人")
    print(f"   他属于社区 {partition[top_bridge_person]}")

# 6. 计算整个网络的统计信息
print(f"\n📊 整体网络统计：")
print("=" * 50)

print(f"   总节点数: {G.number_of_nodes()}")
print(f"   总边数: {G.number_of_edges()}")
print(f"   平均度: {sum(dict(G.degree()).values()) / G.number_of_nodes():.2f}")
print(f"   网络直径: {nx.diameter(G)}")
print(f"   平均聚类系数: {nx.average_clustering(G):.3f}")
print(f"   模块度: {modularity:.3f}")

# 7. 可视化增强版 - 突出显示社区和桥梁
print(f"\n🎨 生成增强版可视化...")

plt.figure(figsize=(15, 10))
pos = nx.spring_layout(G, seed=42, k=1, iterations=50)

# 颜色设置
colors = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7']

# 绘制节点 - 按社区着色
node_colors = [colors[partition[node] % len(colors)] for node in G.nodes()]
node_sizes = [200 + G.degree(node) * 20 for node in G.nodes()]  # 节点大小反映连接数

nx.draw_networkx_nodes(G, pos,
                      node_color=node_colors,
                      node_size=node_sizes,
                      alpha=0.9,
                      edgecolors='black',
                      linewidths=1)

# 绘制边 - 区分内部连接和桥梁连接
internal_edges = [edge for edge in G.edges() if partition[edge[0]] == partition[edge[1]]]
bridge_edges = [edge for edge in G.edges() if partition[edge[0]] != partition[edge[1]]]

# 先画内部边（细线）
nx.draw_networkx_edges(G, pos,
                      edgelist=internal_edges,
                      alpha=0.3,
                      width=1.0,
                      edge_color='gray')

# 再画桥梁边（粗线、红色突出）
nx.draw_networkx_edges(G, pos,
                      edgelist=bridge_edges,
                      alpha=0.8,
                      width=2.5,
                      edge_color='red',
                      style='dashed')

# 绘制标签
nx.draw_networkx_labels(G, pos,
                       font_size=8,
                       font_weight='bold')

# 突出显示中心人物和桥梁人物
if bridge_people:
    bridge_nodes = list(bridge_people.keys())
    nx.draw_networkx_nodes(G, pos,
                          nodelist=[top_bridge_person],
                          node_color='yellow',
                          node_size=600,
                          edgecolors='red',
                          linewidths=3)

# 添加标题和图例
plt.title("空手道俱乐部 - 社区结构深度分析\n"
          "红色虚线: 社区间桥梁 | 黄色节点: 关键桥梁人物", 
          fontsize=14, pad=20, fontweight='bold')

plt.axis('off')

# 添加详细图例
legend_elements = []
for comm_id in sorted(community_stats.keys()):
    color = colors[comm_id % len(colors)]
    stats = community_stats[comm_id]
    legend_elements.append(plt.Line2D([0], [0], 
                          marker='o', 
                          color='w', 
                          markerfacecolor=color, 
                          markersize=10, 
                          label=f'社区 {comm_id}: {stats["size"]}人 (中心:{stats["center_person"]})'))

# 添加桥梁图例
legend_elements.append(plt.Line2D([0], [0], 
                      color='red', 
                      linewidth=2, 
                      linestyle='--',
                      label='社区间桥梁'))

legend_elements.append(plt.Line2D([0], [0], 
                      marker='o', 
                      color='w', 
                      markerfacecolor='yellow', 
                      markersize=10, 
                      markeredgecolor='red',
                      markeredgewidth=2,
                      label='关键桥梁人物'))

plt.legend(handles=legend_elements, 
           loc='center left',
           bbox_to_anchor=(1, 0.5),
           frameon=True,
           fancybox=True,
           shadow=True)

plt.tight_layout()

print("✅ 增强版可视化准备完成！正在显示图形...")
plt.show()

print("\n🎉 深度分析完成！")
print("💡 关键发现:")
print("   • 了解了每个社区的内部结构")
print("   • 找到了社区间的桥梁连接") 
print("   • 识别了关键桥梁人物")
print("   • 获得了网络的整体统计信息")