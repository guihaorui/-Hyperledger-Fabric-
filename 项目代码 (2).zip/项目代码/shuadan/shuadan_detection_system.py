"""
刷单检测系统
整合自定义Louvain算法，检测交易网络中的刷单行为
只有监督审查者才能查看检测报告
"""

import json
import random
import math
import itertools
from datetime import datetime, timedelta
from collections import defaultdict
import networkx as nx

# 使用python-louvain库进行社区检测
import community as community_louvain

class MultiWayCollusionDetector:
    """多元合谋检测器

    不依赖社区发现，直接在图中搜索任意规模（2人~10+人）的合谋团伙。
    核心思路：刷单团伙的本质是「一群买家与一群卖家之间高密度交易」，
    这在图论中对应「极大二分团（maximal biclique）」。

    三种互补检测方法:
    1. K-Core 分解: 找到图中最紧密的核心层，剥离外围噪声
    2. 极大二分团挖掘: 搜索买家-卖家全连接子图（刷单的核心图论特征）
    3. N-Clique/近完全子图检测: 检测高密度子图

    所有方法均「不依赖社区发现先验」，可与 Louvain 并行使用。
    """

    def __init__(self,
                 biclique_min_buyers=2,
                 biclique_min_sellers=2,
                 biclique_completeness=0.65,
                 density_threshold=0.6,
                 k_core_min=2):
        """
        :param biclique_min_buyers: 二分团最少买家数（>=2 即至少2元）
        :param biclique_min_sellers: 二分团最少卖家数
        :param biclique_completeness: 二分团完备率阈值（实际边/最大可能边）
        :param density_threshold: 近完全子图密度阈值
        :param k_core_min: K-Core 最小度数
        """
        self.biclique_min_buyers = biclique_min_buyers
        self.biclique_min_sellers = biclique_min_sellers
        self.biclique_completeness = biclique_completeness
        self.density_threshold = density_threshold
        self.k_core_min = k_core_min

    # ================================================================
    # 方法1: K-Core 分解
    # ================================================================
    def detect_k_cores(self, graph):
        """K-Core 分解: 逐层剥离低度节点，找到最紧密的核心

        K-Core 定义: 子图中每个节点的度数 >= k
        高 k-core 中的节点可能形成合谋核心——它们之间交易密集，不易被剥离。

        :return: list of dict, 每个包含 core 层级和节点列表
        """
        if graph.number_of_nodes() == 0:
            return []

        cores = []
        max_core = 0

        # 计算每个节点的 core number
        try:
            core_numbers = nx.core_number(graph)
            if core_numbers:
                max_core = max(core_numbers.values())
        except Exception:
            core_numbers = {n: 0 for n in graph.nodes()}

        # 从最高 k 开始，依次提取各层 core
        for k in range(max_core, self.k_core_min - 1, -1):
            nodes_in_core = [n for n, c in core_numbers.items() if c >= k]
            if len(nodes_in_core) < 3:
                continue

            subgraph = graph.subgraph(nodes_in_core)
            if subgraph.number_of_edges() == 0:
                continue

            # 区分买家/卖家
            buyers = [n for n in nodes_in_core
                      if graph.nodes[n].get('node_type') == 'buyer']
            sellers = [n for n in nodes_in_core
                       if graph.nodes[n].get('node_type') == 'seller']
            # 回退：名称判断
            if not buyers and not sellers:
                for n in nodes_in_core:
                    if str(n).startswith(('S', '卖', 'Shop', 'FS', 'FakeS')):
                        sellers.append(n)
                    else:
                        buyers.append(n)

            # 计算核心内部连接密度
            internal_edges = subgraph.number_of_edges()
            max_edges = len(buyers) * len(sellers) if buyers and sellers else len(nodes_in_core) * (len(nodes_in_core) - 1) / 2
            core_density = internal_edges / max_edges if max_edges > 0 else 0

            # 提取该 core 内的连边权重信息
            weights = [d.get('weight', 1) for _, _, d in subgraph.edges(data=True)]
            ratings = [d.get('avg_rating', 0) for _, _, d in subgraph.edges(data=True)
                       if d.get('avg_rating') is not None]

            cores.append({
                'k_level': k,
                'size': len(nodes_in_core),
                'nodes': nodes_in_core,
                'n_buyers': len(buyers),
                'n_sellers': len(sellers),
                'internal_edges': internal_edges,
                'max_possible_edges': int(max_edges),
                'core_density': round(core_density, 4),
                'avg_edge_weight': round(sum(weights) / len(weights), 2) if weights else 0,
                'avg_rating': round(sum(ratings) / len(ratings), 2) if ratings else None,
            })

        return cores

    # ================================================================
    # 方法2: 极大二分团挖掘（核心方法）
    # ================================================================
    def _get_node_type(self, graph, node):
        """判断节点是买家还是卖家"""
        ntype = graph.nodes[node].get('node_type', '')
        if ntype in ('buyer', 'seller'):
            return ntype
        name = str(node)
        if name.startswith(('S', '卖', 'Shop', 'FS', 'FakeS')):
            return 'seller'
        return 'buyer'

    def _build_buyer_seller_map(self, graph):
        """构建 买家->卖家集合 和 卖家->买家集合"""
        buyer_to_sellers = defaultdict(set)
        seller_to_buyers = defaultdict(set)
        all_buyers = set()
        all_sellers = set()

        for u, v in graph.edges():
            ut = self._get_node_type(graph, u)
            vt = self._get_node_type(graph, v)

            if ut == 'buyer' and vt == 'seller':
                buyer_to_sellers[u].add(v)
                seller_to_buyers[v].add(u)
                all_buyers.add(u)
                all_sellers.add(v)
            elif ut == 'seller' and vt == 'buyer':
                buyer_to_sellers[v].add(u)
                seller_to_buyers[u].add(v)
                all_buyers.add(v)
                all_sellers.add(u)

        return buyer_to_sellers, seller_to_buyers, all_buyers, all_sellers

    def mine_maximal_bicliques(self, graph):
        """挖掘极大二分团 (maximal biclique)

        算法: 基于卖家组合 + 共同买家扩展
        1. 对每对卖家，找出它们的共同买家 → 候选二分团 (common_buyers, {s1, s2})
        2. 贪心扩展: 尝试添加更多卖家，要求新卖家也连接所有当前买家
        3. 去重: 用 frozenset 去重

        复杂度: O(|S|^2 * |B|) 其中 S=sellers, B=buyers
        对于数百节点的图可高效运行。

        :return: list of dict, 每个包含一个二分团信息
        """
        buyer_to_sellers, seller_to_buyers, all_buyers, all_sellers = \
            self._build_buyer_seller_map(graph)

        if len(all_sellers) < self.biclique_min_sellers:
            return []

        sellers_list = list(all_sellers)
        seen_groups = set()
        bicliques = []

        # 从每个卖家开始
        for seller in sellers_list:
            sbuyers = seller_to_buyers.get(seller, set())
            if len(sbuyers) < self.biclique_min_buyers:
                continue

            # 初始化: 1个卖家 + 它的所有买家
            current_sellers = {seller}
            current_buyers = set(sbuyers)

            # 贪心扩展: 尝试添加更多卖家
            # 按共同买家数量对候选卖家排序
            candidate_sellers = []
            for other_seller in sellers_list:
                if other_seller in current_sellers:
                    continue
                obuyers = seller_to_buyers.get(other_seller, set())
                common = current_buyers & obuyers
                if len(common) >= self.biclique_min_buyers:
                    candidate_sellers.append((other_seller, len(common)))

            candidate_sellers.sort(key=lambda x: x[1], reverse=True)

            for other_seller, _ in candidate_sellers:
                obuyers = seller_to_buyers.get(other_seller, set())
                new_buyers = current_buyers & obuyers
                if len(new_buyers) >= self.biclique_min_buyers:
                    current_sellers.add(other_seller)
                    current_buyers = new_buyers

            # 检查条件
            if len(current_buyers) >= self.biclique_min_buyers and \
               len(current_sellers) >= self.biclique_min_sellers:

                # 去重
                group_key = (frozenset(current_buyers), frozenset(current_sellers))
                if group_key in seen_groups:
                    continue
                seen_groups.add(group_key)

                # 计算二分团指标
                max_edges = len(current_buyers) * len(current_sellers)
                actual_edges = 0
                for b in current_buyers:
                    bsellers = buyer_to_sellers.get(b, set())
                    actual_edges += len(bsellers & current_sellers)

                completeness = actual_edges / max_edges if max_edges > 0 else 0
                if completeness < self.biclique_completeness:
                    continue

                # 收集边信息
                sub_nodes = list(current_buyers) + list(current_sellers)
                subgraph = graph.subgraph(sub_nodes)
                ratings = []
                amounts = []
                for _, _, d in subgraph.edges(data=True):
                    r = d.get('avg_rating')
                    if r is not None:
                        ratings.append(r)
                    al = d.get('amount_list', [])
                    if al:
                        amounts.extend(al)

                avg_rating = sum(ratings) / len(ratings) if ratings else None
                total_amount = sum(amounts)
                amount_cv = 0.0
                if len(amounts) >= 2:
                    mean_amt = total_amount / len(amounts)
                    if mean_amt > 0:
                        var = sum((a - mean_amt) ** 2 for a in amounts) / len(amounts)
                        amount_cv = math.sqrt(var) / mean_amt

                bicliques.append({
                    'buyers': list(current_buyers),
                    'sellers': list(current_sellers),
                    'total_size': len(current_buyers) + len(current_sellers),
                    'n_buyers': len(current_buyers),
                    'n_sellers': len(current_sellers),
                    'actual_edges': actual_edges,
                    'max_possible_edges': max_edges,
                    'completeness': round(completeness, 4),
                    'avg_rating': round(avg_rating, 2) if avg_rating else None,
                    'total_amount': round(total_amount, 2),
                    'amount_cv': round(amount_cv, 4),
                })

        # 按总分排序: 综合考虑大小 + 完备率
        bicliques.sort(
            key=lambda x: (x['total_size'] * 0.4 + x['completeness'] * 0.6),
            reverse=True
        )
        return bicliques

    # ================================================================
    # 方法3: N-Clique / 近完全子图检测
    # ================================================================
    def find_near_cliques(self, graph):
        """检测高密度子图（N-Clique / Near-Clique）

        使用 networkx 的 k-clique 枚举（最大 k 受限于图规模）。
        对于中等规模图可直接枚举所有 clique；大规模图限制 k。
        同时检测「近完全子图」——不要求 100% 完备，但密度 > threshold。

        :return: list of dict, 每个包含一个近完全子图
        """
        if graph.number_of_nodes() == 0:
            return []

        results = []
        n = graph.number_of_nodes()

        # 限制最大 k 值：节点数 > 200 时限制到 k=6，否则最大枚举到 k=min(n, 10)
        if n <= 200:
            max_k = min(n, 10)
        elif n <= 500:
            max_k = min(n, 8)
        else:
            max_k = min(n, 5)

        # 使用 networkx 枚举 clique
        try:
            all_cliques = list(nx.enumerate_all_cliques(graph))
        except Exception:
            all_cliques = []

        seen = set()
        for clique in all_cliques:
            if len(clique) < 3:
                continue
            if len(clique) > max_k:
                continue

            key = frozenset(clique)
            if key in seen:
                continue
            seen.add(key)

            subgraph = graph.subgraph(clique)
            edges = subgraph.number_of_edges()
            max_edges = len(clique) * (len(clique) - 1) / 2
            density = edges / max_edges if max_edges > 0 else 0

            # 区分买家卖家
            buyers = [n for n in clique
                      if self._get_node_type(graph, n) == 'buyer']
            sellers = [n for n in clique
                       if self._get_node_type(graph, n) == 'seller']

            ratings = [d.get('avg_rating') for _, _, d in subgraph.edges(data=True)
                       if d.get('avg_rating') is not None]

            results.append({
                'type': 'clique',
                'nodes': clique,
                'size': len(clique),
                'n_buyers': len(buyers),
                'n_sellers': len(sellers),
                'edges': edges,
                'density': round(density, 4),
                'avg_rating': round(sum(ratings) / len(ratings), 2) if ratings else None,
            })

        results.sort(key=lambda x: (x['size'], x['density']), reverse=True)
        return results

    # ================================================================
    # 合谋团伙评分
    # ================================================================
    def score_collusion_group(self, graph, group_info):
        """对检测到的合谋团伙进行多维评分

        评分维度:
        - size_score: 规模得分（3-5人中等分，6+人加速加分）
        - completeness: 二分团完备率 / 子图密度
        - rating_anomaly: 评分异常度
        - amount_consistency: 金额一致性
        - isolation: 团伙与外部隔离度

        :return: dict with scores and risk_level
        """
        scores = {}

        # 获取节点和子图
        nodes = group_info.get('nodes',
                              group_info.get('buyers', []) + group_info.get('sellers', []))
        if len(nodes) < 3:
            sub_nodes = set(group_info.get('buyers', [])) | set(group_info.get('sellers', []))
            nodes = list(sub_nodes)
        subgraph = graph.subgraph(nodes)

        # ---- 1. 规模得分 ----
        size = len(nodes)
        if size <= 2:
            size_score = 0.0
        elif size <= 4:
            size_score = 0.3  # 至少3元才值得关注
        elif size <= 6:
            size_score = 0.55
        elif size <= 10:
            size_score = 0.75
        elif size <= 15:
            size_score = 0.90
        else:
            size_score = 1.0  # 10+ 人大团伙，满分
        scores['size_score'] = round(size_score, 4)

        # ---- 2. 完备率/密度 ----
        completeness = group_info.get('completeness', group_info.get('density', 0))
        if completeness >= 0.9:
            complete_score = 1.0
        elif completeness >= 0.75:
            complete_score = 0.8
        elif completeness >= 0.6:
            complete_score = 0.55
        elif completeness >= 0.5:
            complete_score = 0.3
        else:
            complete_score = 0.1
        scores['completeness_score'] = round(complete_score, 4)

        # ---- 3. 评分异常度 ----
        ratings = []
        for _, _, d in subgraph.edges(data=True):
            r = d.get('avg_rating')
            if r is not None:
                ratings.append(r)
        if ratings:
            avg_r = sum(ratings) / len(ratings)
            if avg_r > 4.8:
                rating_score = 1.0
            elif avg_r > 4.5:
                rating_score = 0.8
            elif avg_r > 4.0:
                rating_score = 0.5
            elif avg_r > 3.5:
                rating_score = 0.2
            else:
                rating_score = 0.0
            scores['avg_rating'] = round(avg_r, 2)
        else:
            rating_score = 0.0
            scores['avg_rating'] = None
        scores['rating_score'] = round(rating_score, 4)

        # ---- 4. 金额一致性 ----
        amount_cv = group_info.get('amount_cv', None)
        if amount_cv is not None and amount_cv >= 0:
            if amount_cv < 0.1:
                cv_score = 1.0    # 高度一致，非常可疑
            elif amount_cv < 0.2:
                cv_score = 0.7
            elif amount_cv < 0.3:
                cv_score = 0.4
            elif amount_cv < 0.5:
                cv_score = 0.2
            else:
                cv_score = 0.0
        else:
            # 尝试从子图计算
            amounts = []
            for _, _, d in subgraph.edges(data=True):
                al = d.get('amount_list', [])
                if al:
                    amounts.extend(al)
            if len(amounts) >= 2:
                mean_amt = sum(amounts) / len(amounts)
                if mean_amt > 0:
                    var = sum((a - mean_amt) ** 2 for a in amounts) / len(amounts)
                    cv = math.sqrt(var) / mean_amt
                    if cv < 0.1:
                        cv_score = 1.0
                    elif cv < 0.2:
                        cv_score = 0.7
                    elif cv < 0.3:
                        cv_score = 0.4
                    elif cv < 0.5:
                        cv_score = 0.2
                    else:
                        cv_score = 0.0
                    amount_cv = cv
                else:
                    cv_score = 0.0
            else:
                cv_score = 0.0
        scores['amount_cv'] = round(amount_cv, 4) if amount_cv is not None else None
        scores['amount_consistency_score'] = round(cv_score, 4)

        # ---- 5. 隔离度: 团伙成员与外部连接的情况 ----
        internal_weight = sum(d.get('weight', 1) for _, _, d in subgraph.edges(data=True))
        external_weight = 0
        for node in nodes:
            for nbr in graph.neighbors(node):
                if nbr not in nodes:
                    external_weight += graph[node][nbr].get('weight', 1)
        total_weight = internal_weight + external_weight
        isolation = internal_weight / total_weight if total_weight > 0 else 0
        scores['isolation'] = round(isolation, 4)

        if isolation > 0.85:
            isolation_score = 1.0
        elif isolation > 0.7:
            isolation_score = 0.7
        elif isolation > 0.5:
            isolation_score = 0.4
        elif isolation > 0.3:
            isolation_score = 0.2
        else:
            isolation_score = 0.0
        scores['isolation_score'] = round(isolation_score, 4)

        # ---- 综合得分 ----
        weights = {
            'size_score': 0.15,
            'completeness_score': 0.30,
            'rating_score': 0.25,
            'amount_consistency_score': 0.15,
            'isolation_score': 0.15,
        }
        total = sum(weights[k] * scores.get(k, 0) for k in weights)
        scores['total_score'] = round(total, 4)

        # ---- 风险等级 ----
        if total >= 0.70:
            scores['risk_level'] = 'high'
            scores['risk_label'] = '高风险'
        elif total >= 0.40:
            scores['risk_level'] = 'medium'
            scores['risk_label'] = '中风险'
        else:
            scores['risk_level'] = 'low'
            scores['risk_label'] = '低风险'

        # 团伙类型标记
        n_buyers = group_info.get('n_buyers', 0)
        n_sellers = group_info.get('n_sellers', 0)
        total_sz = n_buyers + n_sellers
        if total_sz >= 10:
            scores['gang_scale'] = '大型团伙'
        elif total_sz >= 6:
            scores['gang_scale'] = '中型团伙'
        elif total_sz >= 4:
            scores['gang_scale'] = '小型团伙'
        else:
            scores['gang_scale'] = '微型团伙'

        return scores

    # ================================================================
    # 统一检测入口
    # ================================================================
    def detect_all(self, graph):
        """执行所有多元检测方法，汇总结果

        :return: dict with keys:
            - k_cores: K-Core 分析结果
            - bicliques: 二分团挖掘结果
            - near_cliques: N-Clique 检测结果
            - collusion_groups: 所有检测到的合谋团伙（去重合并 + 评分）
            - summary: 汇总统计
        """
        results = {}

        # 1. K-Core 分解
        k_cores = self.detect_k_cores(graph)
        results['k_cores'] = k_cores

        # 2. 二分团挖掘
        bicliques = self.mine_maximal_bicliques(graph)
        results['bicliques'] = bicliques

        # 3. N-Clique 检测
        near_cliques = self.find_near_cliques(graph)
        results['near_cliques'] = near_cliques

        # 4. 合并去重 + 评分
        all_groups = []
        seen_node_sets = []

        def _is_duplicate(nodes_set, seen):
            """检查是否与已见过的集合高度重叠（>80%重叠即视为重复）"""
            for s in seen:
                if not nodes_set or not s:
                    continue
                overlap = len(nodes_set & s)
                union = len(nodes_set | s)
                if union > 0 and overlap / union > 0.8:
                    return True
            return False

        # 处理二分团
        for bc in bicliques:
            node_set = set(bc['buyers']) | set(bc['sellers'])
            if _is_duplicate(node_set, seen_node_sets):
                continue
            seen_node_sets.append(node_set)
            scores = self.score_collusion_group(graph, bc)
            all_groups.append({
                'detection_method': 'biclique',
                'nodes': sorted(node_set),
                'buyers': bc['buyers'],
                'sellers': bc['sellers'],
                'size': bc['total_size'],
                'n_buyers': bc['n_buyers'],
                'n_sellers': bc['n_sellers'],
                'completeness': bc['completeness'],
                'actual_edges': bc['actual_edges'],
                'max_possible_edges': bc['max_possible_edges'],
                'avg_rating': bc.get('avg_rating'),
                'amount_cv': bc.get('amount_cv'),
                **scores
            })

        # 处理 N-Clique
        for nc in near_cliques:
            node_set = set(nc['nodes'])
            if _is_duplicate(node_set, seen_node_sets):
                continue
            seen_node_sets.append(node_set)
            scores = self.score_collusion_group(graph, nc)
            all_groups.append({
                'detection_method': 'clique',
                'nodes': sorted(node_set),
                'buyers': [],
                'sellers': [],
                'size': len(node_set),
                'n_buyers': nc.get('n_buyers', 0),
                'n_sellers': nc.get('n_sellers', 0),
                'density': nc['density'],
                'completeness': nc['density'],
                'avg_rating': nc.get('avg_rating'),
                **scores
            })

        # 处理 K-Core
        for kc in k_cores:
            node_set = set(kc['nodes'])
            if _is_duplicate(node_set, seen_node_sets):
                continue
            seen_node_sets.append(node_set)
            scores = self.score_collusion_group(graph, kc)
            all_groups.append({
                'detection_method': 'k_core',
                'nodes': sorted(node_set),
                'buyers': [],
                'sellers': [],
                'size': kc['size'],
                'n_buyers': kc.get('n_buyers', 0),
                'n_sellers': kc.get('n_sellers', 0),
                'completeness': kc.get('core_density', 0),
                'density': kc.get('core_density', 0),
                'avg_rating': kc.get('avg_rating'),
                'k_level': kc['k_level'],
                **scores
            })

        # 按总分排序
        all_groups.sort(key=lambda x: x['total_score'], reverse=True)
        results['collusion_groups'] = all_groups

        # 汇总统计
        high = [g for g in all_groups if g['risk_level'] == 'high']
        medium = [g for g in all_groups if g['risk_level'] == 'medium']
        low = [g for g in all_groups if g['risk_level'] == 'low']

        # 按规模统计
        tiny = [g for g in all_groups if g['size'] <= 3]
        small = [g for g in all_groups if 4 <= g['size'] <= 6]
        medium_sz = [g for g in all_groups if 7 <= g['size'] <= 10]
        large = [g for g in all_groups if g['size'] > 10]

        results['summary'] = {
            'total_groups': len(all_groups),
            'high_risk': len(high),
            'medium_risk': len(medium),
            'low_risk': len(low),
            'by_scale': {
                '微型(≤3人)': len(tiny),
                '小型(4-6人)': len(small),
                '中型(7-10人)': len(medium_sz),
                '大型(>10人)': len(large),
            },
            'detection_methods': {
                'biclique': len([g for g in all_groups if g['detection_method'] == 'biclique']),
                'clique': len([g for g in all_groups if g['detection_method'] == 'clique']),
                'k_core': len([g for g in all_groups if g['detection_method'] == 'k_core']),
            },
            'top_groups': all_groups[:5],
        }

        return results


def custom_louvain(graph, weight='weight', **kwargs):
    """使用python-louvain库的Louvain算法"""
    return community_louvain.best_partition(graph, weight=weight)

def compute_modularity(graph, partition, weight='weight'):
    """计算模块度，空图返回 0"""
    if graph.number_of_edges() == 0 or graph.number_of_nodes() == 0:
        return 0.0
    try:
        return community_louvain.modularity(partition, graph, weight=weight)
    except (ValueError, ZeroDivisionError):
        return 0.0

def detect_fraud_communities(graph, partition, weight='weight', threshold=0.8):
    """检测可疑社区"""
    suspicious = []
    for comm in set(partition.values()):
        nodes_in_comm = [node for node, c in partition.items() if c == comm]
        if len(nodes_in_comm) < 2:
            continue

        subgraph = graph.subgraph(nodes_in_comm)
        internal_weight = sum(d.get(weight, 1) for _, _, d in subgraph.edges(data=True))

        external_weight = 0
        for node in nodes_in_comm:
            for neighbor in graph.neighbors(node):
                if partition[neighbor] != comm:
                    external_weight += graph[node][neighbor].get(weight, 1)

        total_weight = internal_weight + external_weight
        if total_weight == 0:
            continue

        internal_ratio = internal_weight / total_weight
        if internal_ratio > threshold:
            suspicious.append({
                'community': comm,
                'nodes': nodes_in_comm,
                'internal_ratio': internal_ratio,
                'internal_weight': internal_weight,
                'external_weight': external_weight,
                'size': len(nodes_in_comm)
            })

    suspicious.sort(key=lambda x: x['internal_ratio'], reverse=True)
    return suspicious


class FraudScorer:
    """多维刷单评分器
    从多个维度评估社区的可疑程度，每个维度 0~1 分，加权求和得综合分数。
    """

    def __init__(self, weights=None):
        """
        :param weights: 各维度权重字典，默认值如下
        权重设计原则：内部连接比和评分异常是刷单最核心的两大特征，
        结构和金额一致性是辅助特征。
        """
        self.weights = weights or {
            'internal_ratio': 0.35,       # 内部连接比（核心）
            'structure': 0.15,             # 图结构异常（辅助）
            'rating': 0.25,                # 评分异常（核心，刷单常伴随异常高评分）
            'amount_consistency': 0.10,    # 金额一致性（辅助）
            'density': 0.05,               # 社区密度（参考）
            'buyer_seller_ratio': 0.10,    # 买卖比失衡（辅助）
        }

    # 风险等级阈值
    RISK_HIGH_THRESHOLD = 0.70
    RISK_MEDIUM_THRESHOLD = 0.40

    @classmethod
    def classify_risk(cls, total_score):
        """根据综合分数划分风险等级

        :return: (risk_level, risk_label_cn)
        """
        if total_score >= cls.RISK_HIGH_THRESHOLD:
            return 'high', '高风险'
        elif total_score >= cls.RISK_MEDIUM_THRESHOLD:
            return 'medium', '中风险'
        else:
            return 'low', '低风险'

    @staticmethod
    def detect_structure(subgraph, nodes):
        """检测图结构类型并返回结构可疑度

        交易图为买家-卖家二分图，重点检测:
        - biclique: 二分团（完备二部子图），买家-卖家全连接，刷单核心特征
        - star: 星形，一个中心节点连大量叶子节点
        - ring: 环状，各节点度 ~2，边数 ≈ 节点数（资金回流）
        - clique: 团状（非二分图场景），密度 > 0.7
        """
        if len(nodes) < 3:
            return 'none', 0.0

        degrees = dict(subgraph.degree())
        deg_values = list(degrees.values())
        n = len(nodes)
        edges = subgraph.number_of_edges()

        if n <= 1:
            return 'none', 0.0

        max_deg = max(deg_values) if deg_values else 0
        min_deg = min(deg_values) if deg_values else 0

        # 识别买家/卖家数量（优先用 graph 的 node_type 属性）
        buyers = 0
        sellers = 0
        for node in nodes:
            ntype = subgraph.nodes[node].get('node_type', '')
            if ntype == 'buyer':
                buyers += 1
            elif ntype == 'seller':
                sellers += 1
            elif str(node).startswith(('B', '买', 'b')):
                buyers += 1
            elif str(node).startswith(('S', '卖', 'Shop', 's')):
                sellers += 1
            else:
                # 未知类型按度分布估算：买家通常度数较低
                pass
        # 兜底：把尚未分类的按度分布分配
        unclassified = n - buyers - sellers
        if unclassified > 0 and (buyers == 0 or sellers == 0):
            low_deg = sum(1 for d in deg_values if d <= 2)
            if buyers == 0:
                buyers = unclassified
            elif sellers == 0:
                sellers = unclassified

        scores = []
        max_possible_edges = buyers * sellers

        # --- 二分团检测（biclique） ---
        # 核心指标: 二分完备率 = 实际边 / (买家数 × 卖家数)
        # 这是交易二分图中检测刷单团伙最有效的结构指标
        # 例: 6买家+4卖家全互连 = 24边/24 = 完备率 100%
        if max_possible_edges > 0:
            biclique_ratio = edges / max_possible_edges
            if biclique_ratio >= 0.65:
                # 接近完备二部图，刷单团伙的典型结构
                biclique_score = min(1.0, biclique_ratio)
                scores.append(('biclique', biclique_score))
            elif n <= 6 and biclique_ratio >= 0.5:
                # 小团伙，即使不完备也值得关注
                biclique_score = biclique_ratio * 0.8
                scores.append(('biclique', biclique_score))

        # --- 星形检测 ---
        # 特征: 一个中心节点度极大，其他节点度为 1
        if max_deg >= (n - 1) * 0.4 and min_deg == 1:
            star_score = max_deg / (n - 1) if n > 1 else 0
            # 星形在二分图中也是可疑的（单一中心卖家/买家）
            if star_score > 0.5:
                scores.append(('star', star_score))

        # --- 环状检测 ---
        # 特征: 边数 ≈ 节点数，各节点度 ≈ 2（资金闭环）
        if n >= 4 and edges >= n:
            edge_ratio = edges / n
            if 0.8 <= edge_ratio <= 1.5:
                avg_deg = sum(deg_values) / n
                if 1.5 <= avg_deg <= 2.8:
                    ring_score = 1.0 - abs(edges - n) / n
                    if ring_score > 0.5:
                        scores.append(('ring', ring_score))

        # --- 传统团状检测（非二分图或高密度场景） ---
        density = nx.density(subgraph)
        if density > 0.7:
            clique_score = min(1.0, density)
            scores.append(('clique', clique_score))

        if not scores:
            return 'none', 0.0

        # 返回得分最高的结构类型
        best = max(scores, key=lambda x: x[1])
        return best[0], best[1]

    @staticmethod
    def classify_node_type(node_name, node_attr):
        """判断节点是买家还是卖家"""
        node_type = node_attr.get('node_type', '')
        if node_type:
            return node_type
        # 回退：根据名称判断
        name = str(node_name)
        if name.startswith(('S', '卖', 'Shop', 'FS')):
            return 'seller'
        return 'buyer'

    def score_community(self, graph, partition, comm_id):
        """对单个社区计算多维综合分数"""
        nodes = [n for n, c in partition.items() if c == comm_id]
        if len(nodes) < 2:
            return None

        subgraph = graph.subgraph(nodes)
        scores = {}

        # 1. 内部连接比
        internal_w = sum(d.get('weight', 1) for _, _, d in subgraph.edges(data=True))
        external_w = 0
        for node in nodes:
            for nbr in graph.neighbors(node):
                if partition.get(nbr) != comm_id:
                    external_w += graph[node][nbr].get('weight', 1)
        total_w = internal_w + external_w
        internal_ratio = internal_w / total_w if total_w > 0 else 0
        scores['internal_ratio'] = round(internal_ratio, 4)

        # 2. 图结构异常
        struct_type, struct_score = self.detect_structure(subgraph, nodes)
        scores['structure'] = round(struct_score, 4)
        scores['structure_type'] = struct_type

        # 3. 评分异常
        ratings = []
        for _, _, data in subgraph.edges(data=True):
            ar = data.get('avg_rating')
            if ar is not None:
                ratings.append(ar)
        if ratings:
            avg_rating = sum(ratings) / len(ratings)
            if avg_rating > 4.5:
                scores['rating'] = round(min(1.0, (avg_rating - 4.5) / 0.5), 4)
            else:
                scores['rating'] = 0.0
            scores['avg_rating'] = round(avg_rating, 2)
        else:
            scores['rating'] = 0.0
            scores['avg_rating'] = None

        # 4. 金额一致性（社区内所有边的金额变异系数）
        amounts = []
        for _, _, data in subgraph.edges(data=True):
            al = data.get('amount_list', [])
            if al:
                amounts.extend(al)
        if len(amounts) >= 3:
            mean_amt = sum(amounts) / len(amounts)
            if mean_amt > 0:
                variance = sum((a - mean_amt) ** 2 for a in amounts) / len(amounts)
                cv = variance ** 0.5 / mean_amt
                # CV 越低越可疑：正常交易 CV 通常 > 0.3，刷单 CV 常 < 0.1
                scores['amount_consistency'] = round(max(0.0, min(1.0, 1.0 - cv / 0.5)), 4)
                scores['amount_cv'] = round(cv, 4)
            else:
                scores['amount_consistency'] = 0.0
                scores['amount_cv'] = None
        else:
            scores['amount_consistency'] = 0.0
            scores['amount_cv'] = None

        # 5. 交易密度
        density = nx.density(subgraph)
        scores['density'] = round(density, 4)

        # 6. 买卖比失衡
        buyers = 0
        sellers = 0
        for node in nodes:
            ntype = graph.nodes[node].get('node_type', '')
            if ntype == 'buyer':
                buyers += 1
            elif ntype == 'seller':
                sellers += 1
            else:
                # 退化判断：根据节点名
                if str(node).startswith(('S', '卖', 'Shop', 'FS')):
                    sellers += 1
                else:
                    buyers += 1
        total_bs = buyers + sellers
        if total_bs > 0:
            ratio_diff = abs(buyers - sellers) / total_bs
        else:
            ratio_diff = 0
        scores['buyer_seller_ratio'] = round(ratio_diff, 4)
        scores['n_buyers'] = buyers
        scores['n_sellers'] = sellers

        # 综合得分
        total = sum(
            self.weights.get(k, 0) * scores.get(k, 0)
            for k in self.weights
        )
        scores['total'] = round(total, 4)

        return scores


def classify_risk(total_score):
    """根据综合分数划分风险等级"""
    return FraudScorer.classify_risk(total_score)


def detect_fraud_advanced(graph, partition, scorer=None, threshold=0.6, weight='weight'):
    """使用多维评分检测社区并分级

    对所有社区进行评分，并标记风险等级（高/中/低）。

    :param graph: 交易图
    :param partition: 社区划分结果
    :param scorer: FraudScorer 实例
    :param threshold: 高风险阈值（>=threshold 视为可疑，用于兼容旧接口）
    :param weight: 权重属性名
    :return: (suspicious_list, all_communities_list, all_scores_dict)
             suspicious_list: 超过高风险阈值的社区（兼容旧接口）
             all_communities_list: 所有社区，带 risk_level 标记
    """
    if scorer is None:
        scorer = FraudScorer()

    suspicious = []
    all_communities = []
    all_scores = {}

    for comm_id in set(partition.values()):
        nodes = [n for n, c in partition.items() if c == comm_id]
        if len(nodes) < 2:
            continue

        scores = scorer.score_community(graph, partition, comm_id)
        if scores is None:
            continue

        all_scores[comm_id] = scores
        total = scores['total']
        risk_level, risk_label = classify_risk(total)

        comm_entry = {
            'community': comm_id,
            'nodes': nodes,
            'size': len(nodes),
            'total_score': total,
            'risk_level': risk_level,
            'risk_label': risk_label,
            'dimension_scores': {k: v for k, v in scores.items()
                                 if k in ('internal_ratio', 'structure', 'rating',
                                          'amount_consistency', 'density',
                                          'buyer_seller_ratio')},
            'structure_type': scores.get('structure_type', 'none'),
            'avg_rating': scores.get('avg_rating'),
            'amount_cv': scores.get('amount_cv'),
            'n_buyers': scores.get('n_buyers', 0),
            'n_sellers': scores.get('n_sellers', 0),
        }
        all_communities.append(comm_entry)

        if total >= threshold:
            suspicious.append(comm_entry)

    suspicious.sort(key=lambda x: x['total_score'], reverse=True)
    all_communities.sort(key=lambda x: x['total_score'], reverse=True)

    return suspicious, all_communities, all_scores


class TradeGraphBuilder:
    """交易图构建器"""

    def __init__(self, transaction_count_weight=1.0, transaction_amount_weight=1.0, rating_weight=1.0):
        """
        初始化权重参数
        :param transaction_count_weight: 交易次数权重
        :param transaction_amount_weight: 交易金额权重
        :param rating_weight: 评分权重
        """
        self.transaction_count_weight = transaction_count_weight
        self.transaction_amount_weight = transaction_amount_weight
        self.rating_weight = rating_weight

    def build_graph_from_transactions(self, transactions):
        """
        从交易数据构建图
        :param transactions: 交易记录列表，每条记录包含:
            - buyer: 买家ID
            - seller: 卖家ID
            - amount: 交易金额
            - rating: 评分 (1-5)
            - timestamp: 时间戳 (可选)
        :return: networkx.Graph 对象
        """
        print("构建交易图...")

        # 初始化图
        G = nx.Graph()

        # 统计每对买家和卖家之间的交易
        edge_data = defaultdict(lambda: {
            'transaction_count': 0,
            'total_amount': 0.0,
            'total_rating': 0.0,
            'rating_count': 0,
            'amounts': [],       # 存储每笔交易的原始金额，用于金额一致性分析
            'tx_details': []     # 存储每笔交易的详细信息（含溯源码、时间戳）
        })

        # 处理交易记录
        for t in transactions:
            buyer = t['buyer']
            seller = t['seller']
            amount = t.get('amount', 0.0)
            rating = t.get('rating', None)
            timestamp = t.get('timestamp', None)
            tx_id = t.get('tx_id', t.get('trace_code', t.get('id', None)))

            # 添加节点
            G.add_node(buyer, node_type='buyer')
            G.add_node(seller, node_type='seller')

            # 更新边数据
            key = (buyer, seller)
            edge_data[key]['transaction_count'] += 1
            edge_data[key]['total_amount'] += amount
            edge_data[key]['amounts'].append(amount)
            edge_data[key]['tx_details'].append({
                'tx_id': tx_id,
                'amount': amount,
                'rating': rating,
                'timestamp': timestamp,
            })

            if rating is not None:
                edge_data[key]['total_rating'] += rating
                edge_data[key]['rating_count'] += 1

        # 添加带权重的边
        for (buyer, seller), data in edge_data.items():
            # 计算平均评分
            avg_rating = data['total_rating'] / data['rating_count'] if data['rating_count'] > 0 else 0

            # 计算综合权重
            # 权重 = 交易次数权重 * 交易次数 + 交易金额权重 * 总金额 + 评分权重 * 平均评分
            weight = (
                self.transaction_count_weight * data['transaction_count'] +
                self.transaction_amount_weight * data['total_amount'] +
                self.rating_weight * avg_rating
            )

            # 计算金额变异系数（CV），衡量金额一致性
            amounts = data['amounts']
            if len(amounts) >= 2:
                mean_amt = sum(amounts) / len(amounts)
                if mean_amt > 0:
                    variance = sum((a - mean_amt) ** 2 for a in amounts) / len(amounts)
                    amount_cv = variance ** 0.5 / mean_amt
                else:
                    amount_cv = 0
            else:
                amount_cv = 0

            # 添加边，存储原始数据用于分析
            G.add_edge(buyer, seller,
                      weight=weight,
                      transaction_count=data['transaction_count'],
                      total_amount=data['total_amount'],
                      avg_rating=avg_rating if data['rating_count'] > 0 else None,
                      amount_list=amounts,
                      amount_cv=amount_cv,
                      tx_details=data['tx_details'])

        print(f"图构建完成: {G.number_of_nodes()} 个节点, {G.number_of_edges()} 条边")
        return G

    def build_graph_from_csv(self, csv_file_path):
        """
        从CSV文件构建图 (简化示例)
        :param csv_file_path: CSV文件路径
        :return: networkx.Graph 对象
        """
        # 这里可以实现CSV解析逻辑
        # 由于时间关系，暂时返回空图
        print("CSV导入功能待实现")
        return nx.Graph()


class FraudDetector:
    """刷单检测器（增强版：多维加权评分）"""

    def __init__(self, fraud_threshold=0.55, scorer_weights=None):
        """
        初始化检测参数
        :param fraud_threshold: 综合可疑分数阈值 (0~1)，高于此值视为可疑
        :param scorer_weights: 自定义权重字典，传给 FraudScorer
        """
        self.fraud_threshold = fraud_threshold
        self.scorer = FraudScorer(weights=scorer_weights)

    def detect(self, graph, weight='weight', return_all_scores=False,
              enable_multiway=True, multiway_kwargs=None):
        """
        执行刷单检测（多维评分版 + 多元合谋检测）

        :param graph: 交易图
        :param weight: 边权重属性
        :param return_all_scores: 是否返回所有社区的评分（用于诊断）
        :param enable_multiway: 是否启用多元合谋检测（默认开启）
        :param multiway_kwargs: 传给 MultiWayCollusionDetector 的参数
        :return: 检测结果字典
        """
        print("开始刷单检测（多维评分版 + 多元合谋检测）...")

        # 空图保护
        if graph.number_of_nodes() == 0 or graph.number_of_edges() == 0:
            print("警告: 图为空或无边，返回空结果")
            return {
                'timestamp': datetime.now().isoformat(),
                'graph_stats': {
                    'nodes': 0, 'edges': 0,
                    'buyers': 0, 'sellers': 0
                },
                'community_stats': {
                    'total_communities': 0, 'modularity': 0.0
                },
                'fraud_detection': {
                    'suspicious_communities': 0,
                    'suspicious_communities_details': [],
                    'fraud_threshold': self.fraud_threshold,
                    'risk_summary': {'high_risk': 0, 'medium_risk': 0, 'low_risk': 0},
                    'all_communities': [],
                },
                'multiway_detection': {
                    'collusion_groups': [],
                    'summary': {},
                    'enabled': False,
                }
            }

        # 1. 运行社区发现算法（Louvain）
        print("运行Louvain社区发现算法...")
        partition = custom_louvain(graph, weight=weight, random_seed=42)

        # 2. 计算模块度
        modularity = compute_modularity(graph, partition, weight=weight)
        print(f"模块度: {modularity:.4f}")

        # 3. 使用多维评分检测所有社区并分级
        suspicious_communities, all_communities, all_scores = detect_fraud_advanced(
            graph, partition, scorer=self.scorer,
            threshold=self.fraud_threshold, weight=weight
        )

        # 按风险等级统计
        high_risk = [c for c in all_communities if c['risk_level'] == 'high']
        medium_risk = [c for c in all_communities if c['risk_level'] == 'medium']
        low_risk = [c for c in all_communities if c['risk_level'] == 'low']

        # 4. 多元合谋检测（独立于社区发现的第二条检测路径）
        multiway_result = {'collusion_groups': [], 'summary': {}, 'enabled': False}
        if enable_multiway:
            print("运行多元合谋检测（K-Core + 二分团挖掘 + N-Clique）...")
            mw_kwargs = multiway_kwargs or {}
            multiway_detector = MultiWayCollusionDetector(**mw_kwargs)
            multiway_result = multiway_detector.detect_all(graph)
            multiway_result['enabled'] = True

        # 5. 生成检测结果
        result = {
            'timestamp': datetime.now().isoformat(),
            'graph_stats': {
                'nodes': graph.number_of_nodes(),
                'edges': graph.number_of_edges(),
                'buyers': len([n for n, attr in graph.nodes(data=True) if attr.get('node_type') == 'buyer']),
                'sellers': len([n for n, attr in graph.nodes(data=True) if attr.get('node_type') == 'seller'])
            },
            'community_stats': {
                'total_communities': len(set(partition.values())),
                'modularity': modularity
            },
            'fraud_detection': {
                'suspicious_communities': len(suspicious_communities),
                'suspicious_communities_details': suspicious_communities,
                'fraud_threshold': self.fraud_threshold,
                'all_communities': all_communities,
                'risk_summary': {
                    'high_risk': len(high_risk),
                    'medium_risk': len(medium_risk),
                    'low_risk': len(low_risk),
                }
            },
            'multiway_detection': multiway_result,
        }

        if return_all_scores:
            result['all_community_scores'] = {}
            for cid, scores in all_scores.items():
                result['all_community_scores'][cid] = scores

        print(f"检测完成: "
              f"社区发现 → 高风险 {len(high_risk)} 个, "
              f"中风险 {len(medium_risk)} 个, "
              f"低风险 {len(low_risk)} 个 "
              f"(阈值={self.fraud_threshold})")
        if multiway_result['enabled']:
            mws = multiway_result.get('summary', {})
            print(f"多元检测 → 合谋团伙 {mws.get('total_groups', 0)} 个, "
                  f"其中高风险 {mws.get('high_risk', 0)} 个, "
                  f"中风险 {mws.get('medium_risk', 0)} 个")
        if suspicious_communities:
            print(f"  可疑社区综合分数: {[c['total_score'] for c in suspicious_communities]}")

        return result


class ReportGenerator:
    """报告生成器"""

    def __init__(self, access_role='user'):
        """
        初始化报告生成器
        :param access_role: 用户角色 ('user' 或 'supervisor')
        """
        self.access_role = access_role

    def generate_report(self, detection_result, output_file=None, graph=None):
        """
        生成检测报告
        :param detection_result: 检测结果字典
        :param output_file: 输出文件路径 (可选)
        :param graph: 交易图 (可选，用于提取可疑交易明细)
        :return: 报告文本
        """
        # 检查权限
        if self.access_role != 'supervisor':
            return "错误: 只有监督审查者才能查看刷单检测报告"

        print("生成刷单检测报告...")

        # 构建报告
        report_lines = []
        report_lines.append("=" * 80)
        report_lines.append("                   刷单检测报告")
        report_lines.append("=" * 80)
        report_lines.append(f"生成时间: {detection_result['timestamp']}")
        report_lines.append("")

        # 网络统计
        report_lines.append("一、网络统计")
        report_lines.append("-" * 40)
        stats = detection_result['graph_stats']
        report_lines.append(f"• 总节点数: {stats['nodes']} (买家: {stats['buyers']}, 卖家: {stats['sellers']})")
        report_lines.append(f"• 总边数: {stats['edges']}")
        report_lines.append("")

        # 社区统计
        report_lines.append("二、社区分析")
        report_lines.append("-" * 40)
        comm_stats = detection_result['community_stats']
        report_lines.append(f"• 发现社区数: {comm_stats['total_communities']}")
        report_lines.append(f"• 网络模块度: {comm_stats['modularity']:.4f}")
        report_lines.append("")

        # 刷单检测结果
        report_lines.append("三、刷单检测结果（风险分级）")
        report_lines.append("-" * 40)
        fraud = detection_result['fraud_detection']
        risk_summary = fraud.get('risk_summary', {})
        report_lines.append(f"• 风险概览: 高风险 {risk_summary.get('high_risk', 0)} 个, "
                           f"中风险 {risk_summary.get('medium_risk', 0)} 个, "
                           f"低风险 {risk_summary.get('low_risk', 0)} 个")
        report_lines.append(f"• 综合阈值: {fraud.get('fraud_threshold', 'N/A')}")
        report_lines.append("")

        # 获取所有社区（优先使用 all_communities，回退到 suspicious_communities_details）
        all_communities = fraud.get('all_communities', fraud.get('suspicious_communities_details', []))
        if not all_communities:
            report_lines.append("未发现任何有效社区。")
            report_lines.append("")
            all_communities = []

        # 按风险等级分组展示
        risk_icons = {'high': '🔴', 'medium': '🟡', 'low': '🟢'}
        risk_order = [('high', '高风险'), ('medium', '中风险'), ('low', '低风险')]

        for risk_level, risk_title in risk_order:
            comms = [c for c in all_communities if c.get('risk_level') == risk_level]
            if not comms:
                continue

            report_lines.append(f"{risk_icons.get(risk_level, '⚪')} {risk_title}社区 ({len(comms)} 个):")
            report_lines.append("")

            for i, comm in enumerate(comms, 1):
                score_val = comm['total_score'] * 100  # 转换为百分制
                # 置信度标签
                confidence = self._confidence_label(comm['total_score'])
                report_lines.append(f"  {i}. 社区 {comm['community']} "
                                   f"[得分: {score_val:.1f}/100 | 置信度: {confidence}]")
                report_lines.append(f"     • 节点数: {comm['size']} "
                                   f"(买家: {comm.get('n_buyers', '?')}, "
                                   f"卖家: {comm.get('n_sellers', '?')})")

                dims = comm.get('dimension_scores', {})
                if dims:
                    report_lines.append(f"     • 多维评分 (百分制):")
                    report_lines.append(f"       - 内部连接比: {dims.get('internal_ratio', 0)*100:.1f}")
                    report_lines.append(f"       - 图结构异常: {dims.get('structure', 0)*100:.1f}")
                    report_lines.append(f"       - 评分异常:   {dims.get('rating', 0)*100:.1f}")
                    report_lines.append(f"       - 金额一致性: {dims.get('amount_consistency', 0)*100:.1f}")
                    report_lines.append(f"       - 交易密度:   {dims.get('density', 0)*100:.1f}")
                    report_lines.append(f"       - 买卖比失衡: {dims.get('buyer_seller_ratio', 0)*100:.1f}")

                struct_type = comm.get('structure_type', 'none')
                if struct_type and struct_type != 'none':
                    type_names = {
                        'star': '星形结构', 'ring': '环状结构',
                        'clique': '团状结构', 'triangle': '三元循环结构',
                        'biclique': '二分团结构（买家-卖家全连接）'
                    }
                    report_lines.append(f"     • 检测结构: {type_names.get(struct_type, struct_type)} ⚠️")

                avg_rating = comm.get('avg_rating')
                if avg_rating is not None:
                    flag = ' ⚠️ 评分异常' if avg_rating > 4.8 else ''
                    report_lines.append(f"     • 平均评分: {avg_rating:.2f}{flag}")

                amount_cv = comm.get('amount_cv')
                if amount_cv is not None:
                    flag = ' ⚠️ 金额高度一致' if amount_cv < 0.2 else ''
                    report_lines.append(f"     • 金额变异系数: {amount_cv:.4f}{flag}")

                report_lines.append(f"     • 成员: {', '.join(str(n) for n in comm['nodes'][:8])}")
                if len(comm['nodes']) > 8:
                    report_lines.append(f"        ... 还有 {len(comm['nodes']) - 8} 个成员")
                report_lines.append("")

        # ================================================================
        # 多元合谋检测结果
        # ================================================================
        mw = detection_result.get('multiway_detection', {})
        if mw.get('enabled'):
            report_lines.append("四、多元合谋检测结果（N元检测 | 2人~10+人团伙）")
            report_lines.append("-" * 40)

            mw_summary = mw.get('summary', {})
            report_lines.append(f"• 检测方法: K-Core分解 + 极大二分团挖掘 + N-Clique检测")
            report_lines.append(f"• 合谋团伙总数: {mw_summary.get('total_groups', 0)} 个")

            # 按风险等级
            report_lines.append(f"  - 高风险: {mw_summary.get('high_risk', 0)} 个")
            report_lines.append(f"  - 中风险: {mw_summary.get('medium_risk', 0)} 个")
            report_lines.append(f"  - 低风险: {mw_summary.get('low_risk', 0)} 个")

            # 按规模
            by_scale = mw_summary.get('by_scale', {})
            if by_scale:
                report_lines.append(f"• 按规模分布:")
                for scale_label, count in by_scale.items():
                    report_lines.append(f"  - {scale_label}: {count} 个")
            report_lines.append("")

            # 详细展示各合谋团伙
            collusion_groups = mw.get('collusion_groups', [])
            risk_icons_mw = {'high': '(高危) [!!]', 'medium': '(中危) [!]', 'low': '(低危) [i]'}

            for i, group in enumerate(collusion_groups, 1):
                risk_level = group.get('risk_level', 'low')
                risk_icon = risk_icons_mw.get(risk_level, '')
                gang_scale = group.get('gang_scale', '')
                method = group.get('detection_method', 'unknown')

                report_lines.append(
                    f"  {i}. {risk_icon} [{gang_scale}] 检测方式={method} "
                    f"| 得分: {group['total_score']*100:.1f}/100"
                )
                report_lines.append(
                    f"     • 规模: {group['size']} 人 "
                    f"(买家: {group.get('n_buyers', '?')}, "
                    f"卖家: {group.get('n_sellers', '?')})"
                )
                report_lines.append(
                    f"     • 完备率: {group.get('completeness', group.get('density', 0))*100:.1f}% "
                    f"| 隔离度: {group.get('isolation', 0)*100:.1f}%"
                )

                if group.get('avg_rating'):
                    report_lines.append(f"     • 平均评分: {group['avg_rating']:.2f}")
                if group.get('amount_cv') is not None:
                    flag = ' (!)金额高度一致' if group['amount_cv'] < 0.2 else ''
                    report_lines.append(f"     • 金额变异系数: {group['amount_cv']:.4f}{flag}")

                # 维度得分 (百分制)
                report_lines.append(f"     • 维度得分 (百分制): "
                                   f"规模={group.get('size_score', 0)*100:.1f}, "
                                   f"完备率={group.get('completeness_score', 0)*100:.1f}, "
                                   f"评分异常={group.get('rating_score', 0)*100:.1f}, "
                                   f"金额一致性={group.get('amount_consistency_score', 0)*100:.1f}, "
                                   f"隔离度={group.get('isolation_score', 0)*100:.1f}")

                nodes = group.get('nodes', [])
                report_lines.append(f"     • 成员: {', '.join(str(n) for n in nodes[:12])}")
                if len(nodes) > 12:
                    report_lines.append(f"        ... 还有 {len(nodes) - 12} 个成员")
                report_lines.append("")

            if not collusion_groups:
                report_lines.append("  未检测到明显合谋团伙。")
                report_lines.append("")

        # 可疑交易明细（如果提供了图）
        suspicious_section_num = 0
        if graph is not None:
            suspicious_section_num = 1
            # 收集所有高风险和中风险社区的节点
            risk_nodes = set()
            risk_comm_ids = set()
            for c in all_communities:
                if c.get('risk_level') in ('high', 'medium'):
                    for n in c['nodes']:
                        risk_nodes.add(str(n))
                    risk_comm_ids.add(c['community'])

            # 同时收集多元合谋团伙的节点
            for g in collusion_groups:
                if g.get('risk_level') in ('high', 'medium'):
                    for n in g.get('nodes', []):
                        risk_nodes.add(str(n))

            if risk_nodes:
                report_lines.append("五、可疑交易明细 (含溯源信息)")
                report_lines.append("-" * 40)

                # 提取风险节点之间的交易
                suspicious_tx_list = []
                seen_keys = set()
                for u, v, data in graph.edges(data=True):
                    if str(u) in risk_nodes or str(v) in risk_nodes:
                        tx_details = data.get('tx_details', [])
                        for tx in tx_details:
                            tx_key = tx.get('tx_id', f"{u}-{v}-{tx.get('amount', 0)}")
                            if tx_key not in seen_keys:
                                seen_keys.add(tx_key)
                                # 计算单笔交易的风险评分
                                tx_rating = tx.get('rating')
                                tx_risk = 0.0
                                if tx_rating is not None:
                                    if tx_rating >= 5:
                                        tx_risk = 80.0
                                    elif tx_rating >= 4.5:
                                        tx_risk = 60.0
                                    elif tx_rating >= 4:
                                        tx_risk = 40.0
                                elif str(u) in risk_nodes and str(v) in risk_nodes:
                                    tx_risk = 70.0
                                else:
                                    tx_risk = 50.0

                                # 判断买卖家：u-v 中，node_type 为 buyer 的是买家
                                u_type = graph.nodes[u].get('node_type', '')
                                if u_type == 'buyer' or (u_type != 'seller' and str(u).startswith(('B', '买', 'Ring'))):
                                    buyer_node, seller_node = str(u), str(v)
                                else:
                                    buyer_node, seller_node = str(v), str(u)

                                suspicious_tx_list.append({
                                    'tx_id': tx_key,
                                    'buyer': buyer_node,
                                    'seller': seller_node,
                                    'amount': tx.get('amount', 0),
                                    'rating': tx_rating,
                                    'timestamp': tx.get('timestamp', 'N/A'),
                                    'risk_score': tx_risk,
                                })

                # 按风险评分排序
                suspicious_tx_list.sort(key=lambda x: x['risk_score'], reverse=True)

                report_lines.append(f"共 {len(suspicious_tx_list)} 笔可疑交易:\n")

                for i, tx in enumerate(suspicious_tx_list[:20]):
                    risk_level = '高' if tx['risk_score'] >= 70 else ('中' if tx['risk_score'] >= 40 else '低')
                    report_lines.append(f"  {i+1}. [{risk_level}风险] 评分: {tx['risk_score']:.1f}/100")
                    report_lines.append(f"     • 溯源码: {tx['tx_id']}")
                    report_lines.append(f"     • 卖家: {tx['seller']} → 买家: {tx['buyer']}")
                    report_lines.append(f"     • 金额: {tx['amount']}")
                    if tx['rating'] is not None:
                        report_lines.append(f"     • 评分: {tx['rating']}")
                    report_lines.append(f"     • 时间: {tx['timestamp']}")
                    report_lines.append("")

                if len(suspicious_tx_list) > 20:
                    report_lines.append(f"  ... 还有 {len(suspicious_tx_list) - 20} 笔可疑交易，完整列表请查看系统界面\n")
                report_lines.append("")

        # 建议
        section_num = "六" if suspicious_section_num else ("五" if mw.get('enabled') else "四")
        report_lines.append(f"{section_num}、建议")
        report_lines.append("-" * 40)
        high_count = risk_summary.get('high_risk', 0)
        medium_count = risk_summary.get('medium_risk', 0)
        low_count = risk_summary.get('low_risk', 0)

        # 合并多元检测的高风险
        mw_high = mw.get('summary', {}).get('high_risk', 0) if mw.get('enabled') else 0

        idx = 1
        if high_count > 0:
            report_lines.append(f"{idx}. 发现 {high_count} 个高风险社区，建议立即人工审核并冻结可疑账号")
            idx += 1
        if mw_high > 0:
            report_lines.append(f"{idx}. 多元检测发现 {mw_high} 个高危合谋团伙，"
                              f"建议优先核查这些直接通过结构发现的团伙")
            idx += 1
        if medium_count > 0:
            report_lines.append(f"{idx}. 发现 {medium_count} 个中风险社区，建议列入观察名单，持续监控交易变化")
            idx += 1
        if low_count > 0:
            report_lines.append(f"{idx}. 发现 {low_count} 个低风险社区，建议定期复查，关注评分趋势变化")
            idx += 1

        # 结构异常提醒
        abnormal_structs = [c for c in all_communities
                          if c.get('structure_type', 'none') != 'none']
        if abnormal_structs:
            report_lines.append(f"{idx}. 检测到 {len(abnormal_structs)} 个异常图结构社区，"
                              f"优先审查三元循环/星形/环状/团状结构且金额高度一致的社区")
            idx += 1

        if high_count == 0 and medium_count == 0 and low_count == 0 and mw_high == 0:
            report_lines.append("网络结构正常，未发现明显刷单行为。")
        else:
            high_thresh = FraudScorer.RISK_HIGH_THRESHOLD
            med_thresh = FraudScorer.RISK_MEDIUM_THRESHOLD
            report_lines.append(f"{idx}. 当前风险分级阈值: 高风险>={high_thresh}, "
                              f"中风险>={med_thresh}, 低风险<{med_thresh}。可根据业务情况调整")

        report_lines.append("")
        report_lines.append("=" * 80)
        report_lines.append("                      报告结束")
        report_lines.append("=" * 80)

        report_text = '\n'.join(report_lines)

        # 保存到文件
        if output_file:
            with open(output_file, 'w', encoding='utf-8') as f:
                f.write(report_text)
            print(f"报告已保存至: {output_file}")

        return report_text

    @staticmethod
    def _confidence_label(score):
        """根据综合分数返回置信度标签"""
        if score >= 0.85:
            return "极高"
        elif score >= 0.70:
            return "高"
        elif score >= 0.40:
            return "中"
        else:
            return "低"


class AccessControl:
    """简单的访问控制"""

    def __init__(self):
        self.users = {
            'admin': {'role': 'supervisor', 'password': 'admin123'},
            'user1': {'role': 'user', 'password': 'user123'},
            'supervisor1': {'role': 'supervisor', 'password': 'super123'}
        }
        self.current_user = None

    def login(self, username, password):
        """用户登录"""
        if username in self.users and self.users[username]['password'] == password:
            self.current_user = username
            return True, f"登录成功，角色: {self.users[username]['role']}"
        else:
            return False, "用户名或密码错误"

    def get_role(self):
        """获取当前用户角色"""
        if self.current_user:
            return self.users[self.current_user]['role']
        return None

    def require_supervisor(self):
        """检查是否为监督审查者"""
        return self.get_role() == 'supervisor'


def generate_sample_transactions(num_transactions=200):
    """生成示例交易数据（包含正常交易 + 多规模刷单团伙：3人、5人、10人）"""
    transactions = []

    # 正常买家和卖家
    buyers = [f"B{i:03d}" for i in range(1, 41)]   # 40个正常买家
    sellers = [f"S{i:03d}" for i in range(1, 31)]  # 30个正常卖家

    # 正常交易：随机配对
    normal_count = num_transactions - 180
    base_time = datetime.now()
    for i in range(normal_count):
        buyer = random.choice(buyers)
        seller = random.choice(sellers)
        transactions.append({
            'buyer': buyer, 'seller': seller,
            'amount': random.randint(10, 1000),
            'rating': random.randint(3, 5),
            'timestamp': (base_time + timedelta(minutes=-i*30)).isoformat(),
            'tx_id': f"TX_NORMAL_{i:05d}",
        })

    # ================================================================
    # 刷单团伙A: 三元小团伙 (2买家 + 1卖家) = 3人
    # ================================================================
    ringA_buyers = [f"RingA_B{i:02d}" for i in range(1, 3)]
    ringA_sellers = [f"RingA_S01"]
    for i in range(30):
        transactions.append({
            'buyer': random.choice(ringA_buyers),
            'seller': random.choice(ringA_sellers),
            'amount': random.randint(300, 800),
            'rating': 5,
            'timestamp': (base_time + timedelta(minutes=-(normal_count+i)*30)).isoformat(),
            'tx_id': f"TX_RINGA_{i:05d}",
        })

    # ================================================================
    # 刷单团伙B: 五元中等团伙 (3买家 + 2卖家) = 5人
    # ================================================================
    ringB_buyers = [f"RingB_B{i:02d}" for i in range(1, 4)]
    ringB_sellers = [f"RingB_S{i:02d}" for i in range(1, 3)]
    for i in range(50):
        transactions.append({
            'buyer': random.choice(ringB_buyers),
            'seller': random.choice(ringB_sellers),
            'amount': random.randint(500, 1500),
            'rating': 5,
            'timestamp': (base_time + timedelta(minutes=-(normal_count+30+i)*30)).isoformat(),
            'tx_id': f"TX_RINGB_{i:05d}",
        })

    # ================================================================
    # 刷单团伙C: 十人大团伙 (7买家 + 3卖家) = 10人
    # 密集互连，高评分，金额一致 —— 即使10人团伙也必须检测到
    # ================================================================
    ringC_buyers = [f"RingC_B{i:02d}" for i in range(1, 8)]
    ringC_sellers = [f"RingC_S{i:02d}" for i in range(1, 4)]
    for i in range(100):
        transactions.append({
            'buyer': random.choice(ringC_buyers),
            'seller': random.choice(ringC_sellers),
            'amount': random.randint(800, 1200),  # 金额高度集中
            'rating': 5,
            'timestamp': (base_time + timedelta(minutes=-(normal_count+80+i)*30)).isoformat(),
            'tx_id': f"TX_RINGC_{i:05d}",
        })

    random.shuffle(transactions)
    print(f"生成 {len(transactions)} 笔交易: "
          f"正常~{normal_count}笔 + "
          f"3人团伙(30笔) + 5人团伙(50笔) + 10人团伙(100笔)")
    return transactions


def main():
    """主函数：演示刷单检测系统（社区发现 + 多元合谋检测）"""
    print("=" * 60)
    print("刷单检测系统（多元合谋检测版）")
    print("=" * 60)

    # 1. 访问控制演示
    print("\n1. 访问控制")
    access = AccessControl()

    # 生成示例交易数据
    print("\n2. 生成示例交易数据...")
    transactions = generate_sample_transactions(300)
    print(f"   含3人/5人/10人三个刷单团伙")

    # 2. 构建交易图
    print("\n3. 构建交易图...")
    builder = TradeGraphBuilder(
        transaction_count_weight=1.0,
        transaction_amount_weight=0.01,
        rating_weight=2.0
    )
    graph = builder.build_graph_from_transactions(transactions)

    # 3. 刷单检测（含多元合谋检测）
    print("\n4. 执行刷单检测（Louvain社区发现 + 多元合谋检测）...")
    detector = FraudDetector(fraud_threshold=0.6)
    detection_result = detector.detect(graph, enable_multiway=True)

    # 4. 打印多元检测摘要
    mw = detection_result.get('multiway_detection', {})
    if mw.get('enabled'):
        print("\n5. 多元合谋检测摘要:")
        mw_sum = mw.get('summary', {})
        print(f"   检测方法: K-Core + 二分团挖掘 + N-Clique")
        print(f"   合谋团伙总数: {mw_sum.get('total_groups', 0)}")
        print(f"   风险分布: 高={mw_sum.get('high_risk', 0)}, "
              f"中={mw_sum.get('medium_risk', 0)}, "
              f"低={mw_sum.get('low_risk', 0)}")
        scale = mw_sum.get('by_scale', {})
        if scale:
            print(f"   规模分布: {scale}")

        # 展示TOP合谋团伙
        top_groups = mw_sum.get('top_groups', [])[:3]
        for g in top_groups:
            print(f"   [{g.get('risk_label', '?')}] {g.get('gang_scale', '?')}: "
                  f"{g['size']}人 (B={g.get('n_buyers',0)}/S={g.get('n_sellers',0)}) "
                  f"得分={g['total_score']:.3f} "
                  f"方法={g.get('detection_method', '?')}")

    # 5. 生成报告
    print("\n6. 生成检测报告...")
    access.login('supervisor1', 'super123')
    report_gen = ReportGenerator(access_role='supervisor')
    report = report_gen.generate_report(
        detection_result,
        output_file='fraud_detection_report.txt',
        graph=graph
    )

    # 打印报告摘要
    lines = report.split('\n')[:30]
    print('\n'.join(lines))
    print("... (完整报告已保存到 fraud_detection_report.txt)")

    print("\n" + "=" * 60)
    print("系统演示完成")
    print("=" * 60)


if __name__ == "__main__":
    # 检查必要的库
    try:
        import networkx as nx
        main()
    except ImportError as e:
        print(f"错误: 缺少必要的库 - {e}")
        print("请安装所需库: pip install networkx python-louvain")