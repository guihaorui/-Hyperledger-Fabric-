"""
刷单检测系统集成示例
展示如何将刷单检测功能集成到现有系统中
"""

import sys
import os

# 添加当前目录到路径
sys.path.insert(0, os.path.dirname(__file__))

from shuadan_detection_system import (
    TradeGraphBuilder,
    FraudDetector,
    ReportGenerator,
    AccessControl
)

def integrate_with_existing_system(existing_transactions, supervisor_username, supervisor_password):
    """
    将刷单检测集成到现有系统的示例函数

    参数:
        existing_transactions: 现有系统中的交易数据列表
        supervisor_username: 监督审查者用户名
        supervisor_password: 监督审查者密码

    返回:
        report_text: 报告文本（如果权限足够）
        or error_message: 错误消息
    """

    print("开始刷单检测集成...")

    # 1. 构建交易图
    print("步骤1: 构建交易图...")
    builder = TradeGraphBuilder(
        transaction_count_weight=1.0,
        transaction_amount_weight=0.01,
        rating_weight=2.0
    )
    graph = builder.build_graph_from_transactions(existing_transactions)

    # 2. 执行刷单检测
    print("步骤2: 执行刷单检测...")
    detector = FraudDetector(fraud_threshold=0.6)
    detection_result = detector.detect(graph)

    # 3. 访问控制
    print("步骤3: 验证用户权限...")
    access = AccessControl()
    success, message = access.login(supervisor_username, supervisor_password)

    if not success:
        return f"权限验证失败: {message}"

    # 4. 生成报告
    print("步骤4: 生成检测报告...")
    role = access.get_role()
    report_gen = ReportGenerator(access_role=role)

    report = report_gen.generate_report(detection_result)
    return report


def load_transactions_from_csv(csv_file_path):
    """
    从CSV文件加载交易数据（示例函数）
    实际使用时需要根据CSV格式进行调整
    """
    import csv

    transactions = []

    # 示例CSV格式:
    # buyer,seller,amount,rating,timestamp
    # B001,S001,100.0,5,2023-01-01

    try:
        with open(csv_file_path, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                transaction = {
                    'buyer': row.get('buyer', ''),
                    'seller': row.get('seller', ''),
                    'amount': float(row.get('amount', 0)),
                    'rating': int(row.get('rating', 3)) if row.get('rating') else None
                }
                transactions.append(transaction)
    except FileNotFoundError:
        print(f"文件未找到: {csv_file_path}")
        return []

    return transactions


def main():
    """集成示例主函数"""

    print("=" * 60)
    print("刷单检测系统集成示例")
    print("=" * 60)

    # 示例1: 使用现有系统中的交易数据
    print("\n示例1: 使用内存中的交易数据")

    # 模拟现有系统中的交易数据
    existing_transactions = [
        {'buyer': 'user1', 'seller': 'shop1', 'amount': 100.0, 'rating': 4},
        {'buyer': 'user2', 'seller': 'shop2', 'amount': 200.0, 'rating': 5},
        {'buyer': 'user1', 'seller': 'shop2', 'amount': 150.0, 'rating': 5},
        # ... 更多交易数据
    ]

    # 监督审查者凭据
    supervisor_username = 'supervisor1'
    supervisor_password = 'super123'

    # 执行集成
    result = integrate_with_existing_system(
        existing_transactions,
        supervisor_username,
        supervisor_password
    )

    # 显示结果摘要
    if "错误" in result or "失败" in result:
        print(f"结果: {result}")
    else:
        # 只显示报告开头部分
        lines = result.split('\n')[:15]
        print("生成的报告 (前15行):")
        print('\n'.join(lines))
        print("...")

        # 保存完整报告
        with open('integration_report.txt', 'w', encoding='utf-8') as f:
            f.write(result)
        print(f"完整报告已保存至: integration_report.txt")

    # 示例2: 从CSV文件加载数据
    print("\n示例2: 从CSV文件加载交易数据")

    # 假设有CSV文件
    csv_file = 'transactions.csv'  # 需要实际文件

    if os.path.exists(csv_file):
        transactions = load_transactions_from_csv(csv_file)
        if transactions:
            print(f"从 {csv_file} 加载了 {len(transactions)} 笔交易")

            # 执行检测
            result = integrate_with_existing_system(
                transactions,
                supervisor_username,
                supervisor_password
            )

            # 处理结果...
        else:
            print(f"无法从 {csv_file} 加载交易数据")
    else:
        print(f"CSV文件不存在: {csv_file}")
        print("创建示例CSV文件...")
        create_sample_csv('transactions.csv')
        print("示例CSV文件已创建")

    print("\n" + "=" * 60)
    print("集成示例完成")
    print("=" * 60)


def create_sample_csv(filename):
    """创建示例CSV文件"""
    import csv

    sample_data = [
        {'buyer': 'B001', 'seller': 'S001', 'amount': '100.0', 'rating': '5'},
        {'buyer': 'B002', 'seller': 'S002', 'amount': '200.0', 'rating': '4'},
        {'buyer': 'B001', 'seller': 'S002', 'amount': '150.0', 'rating': '5'},
        {'buyer': 'B003', 'seller': 'S001', 'amount': '300.0', 'rating': '3'},
        {'buyer': 'B002', 'seller': 'S003', 'amount': '250.0', 'rating': '5'},
    ]

    fieldnames = ['buyer', 'seller', 'amount', 'rating']

    with open(filename, 'w', encoding='utf-8', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(sample_data)


if __name__ == "__main__":
    # 检查必要库
    try:
        import networkx as nx
        import community as community_louvain
        main()
    except ImportError as e:
        print(f"错误: 缺少必要的库 - {e}")
        print("请安装所需库: pip install networkx python-louvain")