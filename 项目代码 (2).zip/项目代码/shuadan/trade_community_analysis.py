# 第二课：分析交易网络社区
print("=== 分析交易网络社区结构 ===")

import networkx as nx
import community as community_louvain
import matplotlib.pyplot as plt
import random
import numpy as np
from collections import defaultdict

print("✅ 库导入成功")

# 设置随机种子
random.seed(42)
np.random.seed(42)

# 1. 重新创建交易网络（复用之前的代码）
print("🔄 创建交易网络...")

buyers = [f"买家_{i}" for i in range(1, 21)]
sellers = [f"卖家_{i}" for i in range(1, 16)]

# 生成交易数据
transactions = []
products = ["电子产品", "服装", "食品", "书籍", "家居用品"]

seller_specialties = {}
for seller in sellers:
    specialty = random.choice(products)
    base_price = random.randint(50, 500)
    seller_specialties[seller] = {
        'specialty': specialty,
        'base_price': base_price,
        'price_range': (base_price * 0.7, base_price * 1.3)
    }

for i in range(100):
    buyer = random.choice(buyers)
    seller = random.choice(sellers)
    specialty_info = seller_specialties[seller]
    price = random.randint(int(specialty_info['price_range'][0]), 
                          int(specialty_info['price_range'][1]))
    product = specialty_info['specialty']
    
    transactions.append({
        'buyer': buyer,
        'seller': seller,
        'product': product,
        'price': price,
        'quantity': random.randint(1, 5)
    })

# 构建无向图用于社区发现（因为Louvain主要处理无向图）
G_undirected = nx.Graph()

# 添加节点
G_undirected.add_nodes_from(buyers, node_type='buyer')
G_undirected.add_nodes_from(sellers, node_type='seller')

# 添加带权重的边（交易额作为权重）
transaction_weights = defaultdict(float)
for transaction in transactions:
    buyer = transaction['buyer']
    seller = transaction['seller']
    trade_volume = transaction['price'] * transaction['quantity']
    key = (buyer, seller)
    transaction_weights[key] += trade_volume

for (buyer, seller), weight in transaction_weights.items():
    G_undirected.add_edge(buyer, seller, weight=weight)

print(f"✅ 网络构建完成: {G_undirected.number_of_nodes()} 节点, {G_undirected.number_of_edges()} 边")

# 2. 运行 Louvain 社区发现算法
print("\n🔍 运行社区发现算法...")
partition = community_louvain.best_partition(G_undirected, weight='weight')
modularity = community_louvain.modularity(partition, G_undirected, weight='weight')

print(f"✅ 发现 {len(set(partition.values()))} 个交易社区")
print(f"   模块度: {modularity:.3f}")

# 3. 分析社区结构
print(f"\n📊 交易社区深度分析")
print("=" * 60)

community_members = defaultdict(list)
community_buyers = defaultdict(list)
community_sellers = defaultdict(list)
community_trade_volume = defaultdict(float)

for node, comm_id in partition.items():
    community_members[comm_id].append(node)
    if '买家' in node:
        community_buyers[comm_id].append(node)
    else:
        community_sellers[comm_id].append(node)

# 计算每个社区的交易额
for (buyer, seller), weight in transaction_weights.items():
    buyer_comm = partition[buyer]
    seller_comm = partition[seller]
    # 如果买家和卖家在同一个社区，计入该社区交易额
    if buyer_comm == seller_comm:
        community_trade_volume[buyer_comm] += weight

print(f"\n🏘️  各交易社区详情:")
print("=" * 60)

for comm_id in sorted(community_members.keys()):
    members = community_members[comm_id]
    buyers_in_comm = community_buyers[comm_id]
    sellers_in_comm = community_sellers[comm_id]
    trade_vol = community_trade_volume[comm_id]
    
    print(f"\n💎 社区 {comm_id}:")
    print(f"   • 总成员: {len(members)} 个")
    print(f"   • 买家: {len(buyers_in_comm)} 个")
    print(f"   • 卖家: {len(sellers_in_comm)} 个")
    print(f"   • 社区内交易额: ￥{trade_vol:.2f}")
    print(f"   • 买家列表: {buyers_in_comm}")
    print(f"   • 卖家列表: {sellers_in_comm}")

# 4. 分析跨社区交易
print(f"\n🔗 跨社区交易分析:")
print("=" * 60)

cross_community_trade = defaultdict(float)
for (buyer, seller), weight in transaction_weights.items():
    buyer_comm = partition[buyer]
    seller_comm = partition[seller]
    if buyer_comm != seller_comm:
        cross_community_trade[(buyer_comm, seller_comm)] += weight

if cross_community_trade:
    print("   社区间交易桥梁:")
    for (comm1, comm2), trade_vol in sorted(cross_community_trade.items(), 
                                          key=lambda x: x[1], reverse=True):
        print(f"   社区 {comm1} → 社区 {comm2}: ￥{trade_vol:.2f}")
else:
    print("   无跨社区交易")

# 5. 找到关键交易人物
print(f"\n👑 关键交易人物分析:")
print("=" * 60)

# 计算每个人的交易影响力（加权度中心性）
node_trade_power = {}
for node in G_undirected.nodes():
    trade_power = sum(G_undirected[node][neighbor]['weight'] 
                     for neighbor in G_undirected.neighbors(node))
    node_trade_power[node] = trade_power

# 最重要的买家
buyer_power = {k: v for k, v in node_trade_power.items() if '买家' in k}
top_buyers = sorted(buyer_power.items(), key=lambda x: x[1], reverse=True)[:3]

print("   最重要买家:")
for buyer, power in top_buyers:
    comm_id = partition[buyer]
    print(f"   {buyer} (社区{comm_id}): ￥{power:.2f}")

# 最重要的卖家
seller_power = {k: v for k, v in node_trade_power.items() if '卖家' in k}
top_sellers = sorted(seller_power.items(), key=lambda x: x[1], reverse=True)[:3]

print("\n   最重要卖家:")
for seller, power in top_sellers:
    comm_id = partition[seller]
    print(f"   {seller} (社区{comm_id}): ￥{power:.2f}")

print("\n✅ 交易社区分析完成！")