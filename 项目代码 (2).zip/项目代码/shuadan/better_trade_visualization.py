# 改进版交易网络可视化 - 更清晰的布局
print("=== 改进版交易网络可视化 ===")

import networkx as nx
import community as community_louvain
import matplotlib.pyplot as plt
import random
import numpy as np
from collections import defaultdict

print("✅ 库导入成功")

# 设置随机种子
random.seed(42)
np.random.seed(42)

# 1. 创建交易网络
print("🔄 创建交易网络...")

buyers = [f"B{i}" for i in range(1, 21)]  # 简化标签
sellers = [f"S{i}" for i in range(1, 16)]  # 简化标签

transactions = []
products = ["电子", "服装", "食品", "书籍", "家居"]

seller_specialties = {}
for seller in sellers:
    specialty = random.choice(products)
    base_price = random.randint(50, 500)
    seller_specialties[seller] = {
        'specialty': specialty,
        'base_price': base_price,
        'price_range': (base_price * 0.7, base_price * 1.3)
    }

for i in range(80):  # 减少交易数量让图更清晰
    buyer = random.choice(buyers)
    seller = random.choice(sellers)
    specialty_info = seller_specialties[seller]
    price = random.randint(int(specialty_info['price_range'][0]), 
                          int(specialty_info['price_range'][1]))
    
    transactions.append({
        'buyer': buyer,
        'seller': seller,
        'price': price,
        'quantity': random.randint(1, 3)  # 减少数量范围
    })

# 构建网络
G = nx.Graph()
G.add_nodes_from(buyers, node_type='buyer')
G.add_nodes_from(sellers, node_type='seller')

transaction_weights = defaultdict(float)
for transaction in transactions:
    buyer = transaction['buyer']
    seller = transaction['seller']
    trade_volume = transaction['price'] * transaction['quantity']
    key = (buyer, seller)
    transaction_weights[key] += trade_volume

for (buyer, seller), weight in transaction_weights.items():
    G.add_edge(buyer, seller, weight=weight)

# 运行社区发现
partition = community_louvain.best_partition(G, weight='weight')
modularity = community_louvain.modularity(partition, G, weight='weight')

print(f"✅ 网络构建完成: {G.number_of_nodes()}节点, {G.number_of_edges()}边")

# 2. 创建改进的可视化
print("\n🎨 创建清晰的可视化...")

# 创建更大的图形
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(20, 10))

# ========== 左边：社区视图 ==========
print("📊 绘制社区视图...")

# 使用改进的布局 - 按社区分组
pos_communities = nx.spring_layout(G, seed=42, k=5, iterations=100)

# 为每个社区创建子图并分别布局
community_nodes = defaultdict(list)
for node, comm_id in partition.items():
    community_nodes[comm_id].append(node)

# 手动调整位置，让社区更分开
for comm_id, nodes in community_nodes.items():
    subgraph = G.subgraph(nodes)
    sub_pos = nx.spring_layout(subgraph, seed=42)
    
    # 将社区移动到不同区域
    center_x = (comm_id % 3) * 4 - 4  # 3列布局
    center_y = (comm_id // 3) * 4 - 4  # 3行布局
    
    for node, (x, y) in sub_pos.items():
        pos_communities[node] = [x + center_x, y + center_y]

# 颜色方案
community_colors = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7', '#DDA0DD']

# 绘制社区视图
node_colors = [community_colors[partition[node] % len(community_colors)] for node in G.nodes()]
node_sizes = [500 + sum(G[node][nbr]['weight'] for nbr in G.neighbors(node)) * 0.05 for node in G.nodes()]

# 绘制节点
buyers_pos = [pos_communities[node] for node in buyers if node in pos_communities]
sellers_pos = [pos_communities[node] for node in sellers if node in pos_communities]

ax1.scatter([pos[0] for pos in buyers_pos], [pos[1] for pos in buyers_pos], 
           c=[node_colors[list(G.nodes()).index(node)] for node in buyers if node in pos_communities],
           s=[node_sizes[list(G.nodes()).index(node)] for node in buyers if node in pos_communities],
           marker='o', alpha=0.8, edgecolors='black', linewidths=1, label='买家')

ax1.scatter([pos[0] for pos in sellers_pos], [pos[1] for pos in sellers_pos], 
           c=[node_colors[list(G.nodes()).index(node)] for node in sellers if node in pos_communities],
           s=[node_sizes[list(G.nodes()).index(node)] for node in sellers if node in pos_communities],
           marker='s', alpha=0.8, edgecolors='black', linewidths=1, label='卖家')

# 绘制边
for edge in G.edges():
    node1, node2 = edge
    weight = G[node1][node2]['weight']
    x1, y1 = pos_communities[node1]
    x2, y2 = pos_communities[node2]
    
    linewidth = 0.5 + (weight / max(transaction_weights.values())) * 3
    alpha = 0.3 + (weight / max(transaction_weights.values())) * 0.5
    
    ax1.plot([x1, x2], [y1, y2], 'gray', linewidth=linewidth, alpha=alpha)

# 添加重要节点标签
node_trade_power = {}
for node in G.nodes():
    trade_power = sum(G[node][neighbor]['weight'] for neighbor in G.neighbors(node))
    node_trade_power[node] = trade_power

# 只显示最重要的节点标签
top_nodes = sorted(node_trade_power.items(), key=lambda x: x[1], reverse=True)[:15]
for node, power in top_nodes:
    if node in pos_communities:
        x, y = pos_communities[node]
        ax1.annotate(node, (x, y), xytext=(5, 5), textcoords='offset points',
                    fontsize=8, fontweight='bold',
                    bbox=dict(boxstyle='round,pad=0.3', facecolor='white', alpha=0.7))

ax1.set_title('交易网络 - 社区视图\n(按社区分组布局)', fontsize=14, fontweight='bold')
ax1.legend()
ax1.axis('off')

# ========== 右边：二分图视图 ==========
print("📊 绘制二分图视图...")

# 创建二分图布局 - 买家在左，卖家在右
pos_bipartite = {}
buyer_x = -5
seller_x = 5

for i, buyer in enumerate(buyers):
    pos_bipartite[buyer] = [buyer_x, i - len(buyers)/2]

for i, seller in enumerate(sellers):
    pos_bipartite[seller] = [seller_x, i - len(sellers)/2]

# 绘制二分图视图
ax2.scatter([pos_bipartite[node][0] for node in buyers], 
           [pos_bipartite[node][1] for node in buyers],
           c=[community_colors[partition[node] % len(community_colors)] for node in buyers],
           s=200, marker='o', alpha=0.8, edgecolors='black', linewidths=1, label='买家')

ax2.scatter([pos_bipartite[node][0] for node in sellers], 
           [pos_bipartite[node][1] for node in sellers],
           c=[community_colors[partition[node] % len(community_colors)] for node in sellers],
           s=200, marker='s', alpha=0.8, edgecolors='black', linewidths=1, label='卖家')

# 绘制边 - 只显示重要的边
important_edges = sorted(transaction_weights.items(), key=lambda x: x[1], reverse=True)[:40]
for (buyer, seller), weight in important_edges:
    if buyer in pos_bipartite and seller in pos_bipartite:
        x1, y1 = pos_bipartite[buyer]
        x2, y2 = pos_bipartite[seller]
        
        linewidth = 0.5 + (weight / max(transaction_weights.values())) * 4
        alpha = 0.4 + (weight / max(transaction_weights.values())) * 0.4
        
        # 根据社区决定颜色
        if partition[buyer] == partition[seller]:
            color = community_colors[partition[buyer] % len(community_colors)]
        else:
            color = 'red'  # 跨社区交易用红色
            
        ax2.plot([x1, x2], [y1, y2], color=color, linewidth=linewidth, alpha=alpha)

# 添加节点标签
for node in list(buyers)[:10] + list(sellers)[:10]:  # 只显示部分标签
    if node in pos_bipartite:
        x, y = pos_bipartite[node]
        ax2.annotate(node, (x, y), xytext=(5, 0), textcoords='offset points',
                    fontsize=8, ha='left' if node in buyers else 'right')

ax2.set_title('交易网络 - 二分图视图\n(买家在左，卖家在右)', fontsize=14, fontweight='bold')
ax2.legend()
ax2.axis('off')

# 添加整体标题和统计信息
plt.suptitle(f'交易网络社区发现分析 | 发现 {len(set(partition.values()))} 个社区 | 模块度: {modularity:.3f}', 
             fontsize=16, fontweight='bold', y=0.95)

# 添加统计信息
stats_text = f"""网络统计:
• 总节点: {G.number_of_nodes()}个 (买家: {len(buyers)}, 卖家: {len(sellers)})
• 交易关系: {G.number_of_edges()}条
• 总交易额: ￥{sum(transaction_weights.values()):.2f}
• 平均交易额: ￥{np.mean(list(transaction_weights.values())):.2f}

交易额TOP3:
买家: {sorted([(k,v) for k,v in node_trade_power.items() if k in buyers], key=lambda x: x[1], reverse=True)[0][0]}
卖家: {sorted([(k,v) for k,v in node_trade_power.items() if k in sellers], key=lambda x: x[1], reverse=True)[0][0]}"""

plt.figtext(0.02, 0.02, stats_text, fontsize=10, 
           bbox=dict(boxstyle="round,pad=0.5", facecolor="lightblue", alpha=0.8))

plt.tight_layout()
plt.subplots_adjust(top=0.9, bottom=0.15)

print("✅ 改进版可视化准备完成！正在显示图形...")
plt.show()

print("\n🎉 改进版可视化完成！")
print("💡 这个版本提供了两个视图:")
print("   • 左图: 社区视图 - 按算法发现的社区分组")
print("   • 右图: 二分图视图 - 买家在左，卖家在右")
print("   • 连线粗细表示交易额大小")
print("   • 红色连线表示跨社区交易")