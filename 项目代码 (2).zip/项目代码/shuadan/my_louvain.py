# 1. 导入我们需要的工具包
import networkx as nx
import community as community_louvain
import matplotlib.pyplot as plt

print("开始创建图结构...")

# 2. 创建一个空的"图" - 就像准备一张空白的纸来画关系网
G = nx.Graph()
print("创建了一个空图")

# 3. 添加一些关系（边）- 就像在纸上画线连接各个点
# 假设我们有8个人，他们之间的关系如下：
relationships = [
    (0, 1), (0, 2), (0, 3),  # 0号与1、2、3号有联系
    (1, 2), (1, 3),           # 1号与2、3号有联系  
    (2, 3),                   # 2号与3号有联系
    (4, 5), (4, 6),           # 4号与5、6号有联系
    (5, 6),                   # 5号与6号有联系
    (7, 4),                   # 7号与4号有联系
    (3, 4)                    # 3号与4号有联系 - 这是连接两个群体的桥梁
]

# 把这些关系添加到图中
G.add_edges_from(relationships)
print("添加了关系边")

# 4. 看看我们创建了什么
print(f"图中有 {G.number_of_nodes()} 个节点")
print(f"图中有 {G.number_of_edges()} 条边")
print("节点列表:", list(G.nodes()))
print("边列表:", list(G.edges()))

# 5. 运行 Louvain 算法来发现社区
print("\n正在运行 Louvain 算法...")
partition = community_louvain.best_partition(G)

# 6. 显示结果
print("\n=== 社区发现结果 ===")
for person, group in partition.items():
    print(f"人物 {person} 属于 社区 {group}")

# 计算划分质量
modularity = community_louvain.modularity(partition, G)
print(f"\n模块度得分: {modularity:.4f} (越接近1表示划分越好)")

# 7. 可视化显示结果
print("\n正在生成可视化图形...")

# 设置图形样式
plt.figure(figsize=(10, 8))

# 为不同社区分配不同颜色
colors = ['red', 'blue', 'green', 'yellow', 'purple']  # 定义几种颜色

# 绘制节点 - 按社区着色
node_colors = [colors[partition[node] % len(colors)] for node in G.nodes()]

# 使用spring布局让图形看起来更整齐
pos = nx.spring_layout(G, seed=42)  # seed参数让每次布局一致

# 画图
nx.draw_networkx_nodes(G, pos, node_size=500, node_color=node_colors, alpha=0.9)
nx.draw_networkx_edges(G, pos, width=1.0, alpha=0.5)
nx.draw_networkx_labels(G, pos, font_size=12, font_color='white')

plt.title(f"Louvain 社区发现算法\n(模块度: {modularity:.3f})", fontsize=14)
plt.axis('off')  # 不显示坐标轴

# 添加图例说明
legend_elements = []
unique_communities = set(partition.values())
for comm in unique_communities:
    legend_elements.append(plt.Line2D([0], [0], marker='o', color='w', 
                          markerfacecolor=colors[comm % len(colors)], 
                          markersize=10, label=f'社区 {comm}'))
plt.legend(handles=legend_elements, loc='best')

plt.tight_layout()
plt.show()

print("完成！")