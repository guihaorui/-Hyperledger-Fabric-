刷单检测系统 - 集成指南
================================

概述
----
本系统实现了基于图论Louvain算法的刷单检测功能，专门用于识别交易网络中的可疑刷单行为。系统包含自定义Louvain算法实现、交易图构建、刷单社区检测和报告生成等功能。

主要文件
--------
1. `custom_louvain.py` - 自定义Louvain算法实现（两个阶段）
2. `shuadan_detection_system.py` - 完整的刷单检测系统
3. `integration_example.py` - 集成示例代码
4. `fraud_detection_report.txt` - 示例报告文件

依赖库
------
- networkx (>= 3.0)
- python-louvain (社区检测库)
- 标准库: random, collections, datetime, json

安装依赖:
```bash
pip install networkx python-louvain
```

快速开始
--------
1. 运行演示系统:
```bash
python shuadan_detection_system.py
```

2. 查看生成的报告: `fraud_detection_report.txt`

集成到现有系统
---------------
### 1. 导入模块
```python
from shuadan_detection_system import (
    TradeGraphBuilder,
    FraudDetector,
    ReportGenerator,
    AccessControl
)
```

### 2. 构建交易图
```python
builder = TradeGraphBuilder(
    transaction_count_weight=1.0,   # 交易次数权重
    transaction_amount_weight=0.01, # 交易金额权重
    rating_weight=2.0               # 评分权重
)

# 从交易数据构建图
transactions = [
    {'buyer': 'user1', 'seller': 'shop1', 'amount': 100.0, 'rating': 4},
    # ... 更多交易
]

graph = builder.build_graph_from_transactions(transactions)
```

### 3. 执行刷单检测
```python
detector = FraudDetector(internal_threshold=0.75)
detection_result = detector.detect(graph)
```

### 4. 权限验证和报告生成
```python
# 用户登录验证
access = AccessControl()
access.login('supervisor1', 'super123')  # 监督审查者

# 生成报告
report_gen = ReportGenerator(access_role=access.get_role())
report = report_gen.generate_report(detection_result, output_file='report.txt')
```

核心组件说明
------------
### TradeGraphBuilder
- 从交易数据构建网络图
- 支持自定义权重: 交易次数、交易金额、评分
- 返回networkx.Graph对象

### FraudDetector
- 执行社区检测和刷单分析
- 基于社区内聚性识别可疑社区
- 可配置检测阈值

### ReportGenerator
- 生成详细检测报告
- 支持权限控制: 只有监督审查者才能查看完整报告
- 可输出到文件或返回文本

### AccessControl
- 简单的用户身份验证
- 角色管理: 'user' 或 'supervisor'
- 扩展性强，可连接现有用户系统

自定义Louvain算法
-----------------
`custom_louvain.py` 实现了用户描述的两个阶段算法:

1. **阶段一: 模块度优化**
   - 初始化: 每个节点独立社区
   - 遍历节点，计算移动节点带来的模块度变化ΔQ
   - 移动节点到ΔQ最大的社区（如果ΔQ为正）
   - 迭代直到无法提升模块度

2. **阶段二: 社区聚合**
   - 将社区压缩为超级节点
   - 构建新图，边权重为社区间连接权重
   - 重复阶段一

算法公式:
- ΔQ = Ai,in/2m - Σtot*ki/(2m)²
- 其中Ai,in是节点与目标社区内部连接权重之和
- Σtot是目标社区总度
- ki是节点度
- m是网络总权重

配置参数
--------
1. **图构建权重**:
   - `transaction_count_weight`: 交易次数权重 (默认: 1.0)
   - `transaction_amount_weight`: 交易金额权重 (默认: 0.01)
   - `rating_weight`: 评分权重 (默认: 2.0)

2. **检测参数**:
   - `internal_threshold`: 内部连接比例阈值 (默认: 0.75)
   - `rating_anomaly_threshold`: 评分异常阈值 (默认: 0.9)

3. **访问控制**:
   - 默认用户: admin/admin123 (监督审查者)
   - 默认用户: user1/user123 (普通用户)
   - 默认用户: supervisor1/super123 (监督审查者)

扩展和定制
----------
1. **连接现有数据库**:
   - 修改`TradeGraphBuilder.build_graph_from_transactions()`从数据库读取

2. **自定义用户系统**:
   - 继承`AccessControl`类，重写`login()`和`get_role()`方法

3. **调整检测逻辑**:
   - 修改`FraudDetector._analyze_rating_anomaly()`实现自定义异常检测

4. **报告格式定制**:
   - 继承`ReportGenerator`类，重写`generate_report()`方法

故障排除
--------
1. **导入错误: No module named 'networkx'**
   ```bash
   pip install networkx python-louvain
   ```

2. **算法不收敛**
   - 调整`max_iterations`参数
   - 检查图数据是否合理

3. **权限验证失败**
   - 检查用户名和密码
   - 确认用户角色为'supervisor'

示例输出
--------
运行`shuadan_detection_system.py`将:
1. 生成示例交易数据
2. 构建交易图
3. 执行刷单检测
4. 演示权限控制
5. 生成检测报告

支持与联系
----------
如有问题，请参考代码注释或联系系统维护者。

版本: 1.0
更新日期: 2026-04-18