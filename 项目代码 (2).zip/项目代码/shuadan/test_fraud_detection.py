"""
刷单检测图论算法 —— 综合测试脚本
测试多种刷单模式，评估算法在不同场景下的表现
"""

import sys
import os
import random
import json
import numpy as np
from collections import defaultdict
from datetime import datetime

# 添加当前目录到路径
sys.path.insert(0, os.path.dirname(__file__))

import networkx as nx
import community as community_louvain

from shuadan_detection_system import (
    TradeGraphBuilder,
    FraudDetector,
    ReportGenerator,
    generate_sample_transactions
)

# ============================================================
# 工具函数
# ============================================================

def print_separator(title):
    """打印分隔标题"""
    width = 70
    print("\n" + "=" * width)
    print(f"  {title}")
    print("=" * width)


def analyze_community_details(graph, partition, suspicious):
    """详细分析可疑社区的图结构特征"""
    print(f"\n  📊 社区结构详细分析:")
    for comm_info in suspicious:
        comm_id = comm_info['community']
        nodes = comm_info['nodes']
        subgraph = graph.subgraph(nodes)

        buyers = [n for n in nodes if str(n).startswith('B') or '买家' in str(n)]
        sellers = [n for n in nodes if str(n).startswith('S') or '卖家' in str(n)]

        dims = comm_info.get('dimension_scores', {})
        print(f"\n  🔍 社区 {comm_id} (综合分: {comm_info['total_score']:.3f}):")
        print(f"     成员: {len(nodes)} ({len(buyers)} 买家, {len(sellers)} 卖家)")
        print(f"     内部连接数: {subgraph.number_of_edges()}")
        print(f"     多维评分: 结构={dims.get('structure',0):.2f}, "
              f"评分={dims.get('rating',0):.2f}, 金额={dims.get('amount_consistency',0):.2f}")

        # 分析子图密度
        if len(nodes) > 1:
            density = nx.density(subgraph)
            max_possible = len(nodes) * (len(nodes) - 1) / 2
            actual = subgraph.number_of_edges()
            print(f"     图密度: {density:.4f} (实际边 {actual}/{int(max_possible)})")

            # 星形特征
            degrees = dict(subgraph.degree())
            if degrees:
                max_deg = max(degrees.values())
                min_deg = min(degrees.values())
                if max_deg > len(nodes) * 0.5 and min_deg == 1:
                    print(f"     结构特征: 星形结构 (中心节点度={max_deg})")


def check_algorithm_parameters(G, suspicious, transactions):
    """评估算法检测结果的各项指标"""
    print(f"\n  📈 检测效果评估:")

    # 1. 检测到的可疑节点占比
    total_nodes = G.number_of_nodes()
    suspicious_nodes = set()
    for comm in suspicious:
        for node in comm['nodes']:
            suspicious_nodes.add(node)
    suspicious_ratio = len(suspicious_nodes) / total_nodes if total_nodes > 0 else 0
    print(f"     可疑节点数: {len(suspicious_nodes)}/{total_nodes} ({suspicious_ratio:.1%})")

    # 2. 交易覆盖率（使用可疑节点覆盖比例近似）
    if suspicious:
        suspicious_nodes = set()
        for comm in suspicious:
            for n in comm['nodes']:
                suspicious_nodes.add(n)
        suspicious_edges = G.subgraph(suspicious_nodes).number_of_edges()
        total_edges = G.number_of_edges()
        print(f"     可疑边覆盖率: {suspicious_edges}/{total_edges} "
              f"({suspicious_edges/total_edges*100:.1f}%)" if total_edges > 0 else "")

    # 3. 模块度评价
    import community as community_louvain
    partition = {node: 0 for node in G.nodes()}
    for i, comm in enumerate(suspicious):
        for node in comm['nodes']:
            partition[node] = i
    # 只报告原始算法的模块度


# ============================================================
# 测试场景
# ============================================================

def test_basic_fraud_ring():
    """测试1: 经典刷单环检测
    多个买家反复向少数卖家购买，高评分，内部交易密集
    """
    print_separator("测试1: 经典刷单环检测")
    print("  场景: 5个买家反复向3个卖家购买，全部5星好评，内部交易密集")

    transactions = []

    # 背景正常交易
    normal_buyers = [f"NB{i:03d}" for i in range(1, 21)]
    normal_sellers = [f"NS{i:03d}" for i in range(1, 16)]
    for _ in range(150):
        buyer = random.choice(normal_buyers)
        seller = random.choice(normal_sellers)
        transactions.append({
            'buyer': buyer, 'seller': seller,
            'amount': random.randint(10, 500),
            'rating': random.randint(3, 5)
        })

    # 刷单团伙: 5个买家 3个卖家，内部密集交易
    fraud_buyers = [f"FB{i:03d}" for i in range(1, 6)]
    fraud_sellers = [f"FS{i:03d}" for i in range(1, 4)]
    for _ in range(80):
        buyer = random.choice(fraud_buyers)
        seller = random.choice(fraud_sellers)
        transactions.append({
            'buyer': buyer, 'seller': seller,
            'amount': random.randint(500, 2000),
            'rating': 5
        })

    random.shuffle(transactions)
    print(f"  总交易数: {len(transactions)} (正常: 150, 刷单: 80)")

    builder = TradeGraphBuilder()
    G = builder.build_graph_from_transactions(transactions)

    detector = FraudDetector(fraud_threshold=0.6)
    result = detector.detect(G)

    suspicious = result['fraud_detection']['suspicious_communities_details']
    print(f"\n  检测到可疑社区数: {len(suspicious)}")
    for comm in suspicious:
        ds = comm.get('dimension_scores', {})
        print(f"    - 社区 {comm['community']}: "
              f"综合分={comm['total_score']:.3f}, "
              f"节点={comm['size']}, "
              f"包含刷单账号={any('FB' in str(n) or 'FS' in str(n) for n in comm['nodes'])}")
        if comm.get('avg_rating'):
            print(f"      评分: 平均{comm['avg_rating']:.2f}, "
                  f"评分异常维度={ds.get('rating', 0):.2f}")
        if comm.get('structure_type', 'none') != 'none':
            print(f"      结构类型: {comm['structure_type']}")

    # 诊断: 查看所有社区的分组情况
    print(f"\n  🔬 社区分组诊断:")
    full_partition = community_louvain.best_partition(G, weight='weight')
    comm_groups = defaultdict(list)
    for node, cid in full_partition.items():
        comm_groups[cid].append(node)

    print(f"     总社区数: {len(comm_groups)}")
    for cid, members in sorted(comm_groups.items()):
        is_fraud = any('FB' in str(n) or 'FS' in str(n) for n in members)
        label = " [刷单]" if is_fraud else ""
        # 计算该社区内部比
        sub = G.subgraph(members)
        internal_w = sum(d.get('weight', 1) for _, _, d in sub.edges(data=True))
        external_w = 0
        for node in members:
            for nbr in G.neighbors(node):
                if full_partition[nbr] != cid:
                    external_w += G[node][nbr].get('weight', 1)
        total = internal_w + external_w
        ratio = internal_w / total if total > 0 else 0
        flagged = " ⚠️可疑" if ratio > 0.8 else ""
        print(f"     社区 {cid}: {len(members)}个节点, "
              f"内部边={sub.number_of_edges()}, 内部比={ratio:.3f}{flagged}{label}")
        if is_fraud:
            print(f"       -> 刷单节点: {[n for n in members if 'FB' in str(n) or 'FS' in str(n)]}")

    # 验证检测效果
    detected_fraud_nodes = set()
    for comm in suspicious:
        for n in comm['nodes']:
            detected_fraud_nodes.add(n)

    actual_fraud = set(fraud_buyers + fraud_sellers)
    tp = len(detected_fraud_nodes & actual_fraud)
    fn = len(actual_fraud - detected_fraud_nodes)
    fp_nodes = detected_fraud_nodes - actual_fraud

    print(f"\n  ✅ 检测效果:")
    print(f"     正确检测(TP): {tp}/{len(actual_fraud)} 个刷单账号")
    print(f"     漏检(FN): {fn} 个")
    print(f"     误报(FP): {len(fp_nodes)} 个正常账号")
    if fp_nodes:
        print(f"     误报账号: {list(fp_nodes)[:5]}")

    return {
        'test': '经典刷单环',
        'total_transactions': len(transactions),
        'suspicious_count': len(suspicious),
        'true_positive': tp,
        'false_negative': fn,
        'false_positive': len(fp_nodes),
        'actual_fraud_count': len(actual_fraud),
        'details': suspicious
    }


def test_hub_and_spoke():
    """测试2: 星形刷单（Hub-and-Spoke）
    一个中心卖家连接大量虚假买家，买家之间无连接
    """
    print_separator("测试2: 星形刷单（Hub-and-Spoke）")
    print("  场景: 1个中心卖家 + 15个虚假买家，买家只与该卖家交易")

    transactions = []

    # 背景正常交易
    for i in range(100):
        transactions.append({
            'buyer': f"U{i:03d}", 'seller': f"Shop{i % 10 + 1:03d}",
            'amount': random.randint(10, 500),
            'rating': random.randint(3, 5)
        })

    # 星形刷单: 1个中心卖家 + 15个虚假买家
    hub_seller = "FRAUD_SHOP"
    fake_buyers = [f"FAKE_B{i:03d}" for i in range(1, 16)]
    for buyer in fake_buyers:
        for _ in range(3):  # 每个买家交易3次
            transactions.append({
                'buyer': buyer, 'seller': hub_seller,
                'amount': random.randint(800, 3000),
                'rating': 5
            })

    random.shuffle(transactions)
    print(f"  总交易数: {len(transactions)} (正常: 100, 刷单: {len(fake_buyers)*3})")

    builder = TradeGraphBuilder()
    G = builder.build_graph_from_transactions(transactions)

    detector = FraudDetector(fraud_threshold=0.6)
    result = detector.detect(G)

    suspicious = result['fraud_detection']['suspicious_communities_details']
    print(f"\n  检测到可疑社区数: {len(suspicious)}")
    for comm in suspicious:
        print(f"    - 社区 {comm['community']}: "
              f"综合分={comm['total_score']:.3f}, "
              f"节点={comm['size']}")
        if comm.get('structure_type', 'none') != 'none':
            print(f"      结构: {comm['structure_type']}")

    # 分析: 星形结构检测难点在于——买家之间没有连接，每个买家只连中心卖家
    # Louvain算法可能将星形结构打散到不同社区
    detected_fraud = set()
    for comm in suspicious:
        for n in comm['nodes']:
            detected_fraud.add(n)

    actual_fraud = set(fake_buyers + [hub_seller])
    tp = len(detected_fraud & actual_fraud)
    fn = len(actual_fraud - detected_fraud)
    fp_nodes = detected_fraud - actual_fraud

    print(f"\n  ✅ 检测效果:")
    print(f"     正确检测(TP): {tp}/{len(actual_fraud)} 个刷单账号")
    print(f"     漏检(FN): {fn} 个")
    print(f"     误报(FP): {len(fp_nodes)} 个正常账号")

    if fn > 0:
        print(f"\n  ⚠️  注意: 星形结构下，如果买家之间没有互连，Louvain算法可能")
        print(f"     将每个买家分到不同社区，导致刷单团伙无法被聚类识别。")

    return {
        'test': '星形刷单',
        'total_transactions': len(transactions),
        'suspicious_count': len(suspicious),
        'true_positive': tp,
        'false_negative': fn,
        'false_positive': len(fp_nodes),
        'actual_fraud_count': len(actual_fraud),
        'details': suspicious
    }


def test_cross_community_fraud():
    """测试3: 跨社区伪装刷单（对抗性测试）
    刷单团伙同时与外部正常账号交易来伪装自己
    """
    print_separator("测试3: 跨社区伪装刷单（对抗性测试）")
    print("  场景: 刷单团伙同时做少量真实外部交易来降低内部连接比")

    transactions = []

    # 正常交易
    normal_users = [f"N{i:04d}" for i in range(1, 31)]
    normal_shops = [f"Shop{i:03d}" for i in range(1, 16)]
    for _ in range(200):
        transactions.append({
            'buyer': random.choice(normal_users),
            'seller': random.choice(normal_shops),
            'amount': random.randint(10, 500),
            'rating': random.randint(3, 5)
        })

    # 伪装刷单团伙: 6买家 + 2卖家
    # 大部分是内部交易，但也做少量外部交易
    fraud_buyers = [f"FB{i:03d}" for i in range(1, 7)]
    fraud_sellers = [f"FS{i:03d}" for i in range(1, 3)]

    # 内部交易: 密集
    for _ in range(100):
        transactions.append({
            'buyer': random.choice(fraud_buyers),
            'seller': random.choice(fraud_sellers),
            'amount': random.randint(500, 2000),
            'rating': 5
        })

    # 外部交易: 每个刷单买家做少量外部交易来"洗白"
    for buyer in fraud_buyers:
        for _ in range(2):
            transactions.append({
                'buyer': buyer,
                'seller': random.choice(normal_shops),
                'amount': random.randint(10, 100),
                'rating': random.randint(3, 4)
            })

    # 刷单卖家也做少量外部交易
    for seller in fraud_sellers:
        for _ in range(3):
            transactions.append({
                'buyer': random.choice(normal_users),
                'seller': seller,
                'amount': random.randint(10, 100),
                'rating': random.randint(3, 4)
            })

    random.shuffle(transactions)
    print(f"  总交易数: {len(transactions)} (内部刷单: 100, 外部伪装: {len(fraud_buyers)*2 + len(fraud_sellers)*3})")

    builder = TradeGraphBuilder()
    G = builder.build_graph_from_transactions(transactions)

    # 先用保守阈值
    detector1 = FraudDetector(fraud_threshold=0.6)
    result1 = detector1.detect(G)
    susp1 = result1['fraud_detection']['suspicious_communities_details']

    # 再用更严格的阈值
    detector2 = FraudDetector(fraud_threshold=0.75)
    result2 = detector2.detect(G)
    susp2 = result2['fraud_detection']['suspicious_communities_details']

    print(f"\n  阈值 = 0.6: 检测到 {len(susp1)} 个可疑社区")
    print(f"  阈值 = 0.75: 检测到 {len(susp2)} 个可疑社区")

    # 验证
    for label, suspicious, threshold in [("阈值0.6", susp1, 0.6), ("阈值0.75", susp2, 0.75)]:
        detected = set()
        for comm in suspicious:
            for n in comm['nodes']:
                detected.add(n)

        actual = set(fraud_buyers + fraud_sellers)
        tp = len(detected & actual)
        fn = len(actual - detected)
        fp = len(detected - actual)

        print(f"\n  {label}:")
        print(f"     TP={tp}/{len(actual)}, FN={fn}, FP={fp}")

        if len(suspicious) > 0:
            scores = [c['total_score'] for c in suspicious]
            print(f"     所有可疑社区综合分: {[f'{s:.3f}' for s in scores]}")

    return {
        'test': '跨社区伪装刷单',
        'total_transactions': len(transactions),
        'result_08': {
            'suspicious_count': len(susp1),
            'details': susp1
        },
        'result_06': {
            'suspicious_count': len(susp2),
            'details': susp2
        }
    }


def test_legitimate_dense_community():
    """测试4: 密集正常社区（误报测试）
    模拟一个真实的密集交易网络，如团购群或小商品市场
    """
    print_separator("测试4: 密集正常社区测试（误报率测试）")
    print("  场景: 模拟正常但交易密集的社区（如团购群），验证是否误报")

    transactions = []

    # 团购社区: 买家之间共享多个卖家，密集但正常
    group_buyers = [f"GB{i:03d}" for i in range(1, 31)]
    group_sellers = [f"GS{i:03d}" for i in range(1, 6)]

    for buyer in group_buyers:
        for seller in group_sellers:
            for _ in range(random.randint(1, 5)):
                transactions.append({
                    'buyer': buyer, 'seller': seller,
                    'amount': random.randint(50, 300),
                    'rating': random.randint(3, 5)
                })

    # 外部正常交易（作为背景）
    other_users = [f"OU{i:04d}" for i in range(1, 21)]
    other_shops = [f"OS{i:03d}" for i in range(1, 11)]
    for _ in range(80):
        transactions.append({
            'buyer': random.choice(other_users),
            'seller': random.choice(other_shops),
            'amount': random.randint(10, 500),
            'rating': random.randint(3, 5)
        })

    # 团购成员也与外部交易
    for buyer in group_buyers[:10]:
        for _ in range(2):
            transactions.append({
                'buyer': buyer, 'seller': random.choice(other_shops),
                'amount': random.randint(50, 200),
                'rating': random.randint(3, 5)
            })

    random.shuffle(transactions)
    print(f"  总交易数: {len(transactions)} (团购社区内部密集交易 + 外部正常交易)")

    builder = TradeGraphBuilder()
    G = builder.build_graph_from_transactions(transactions)

    for threshold in [0.6, 0.5, 0.4, 0.3]:
        detector = FraudDetector(fraud_threshold=threshold)
        result = detector.detect(G)
        suspicious = result['fraud_detection']['suspicious_communities_details']

        # 检查是否误报了正常团购社区
        false_alarm = False
        for comm in suspicious:
            nodes = comm['nodes']
            if all('GB' in str(n) or 'GS' in str(n) for n in nodes):
                false_alarm = True
                break

        print(f"\n  综合阈值={threshold}: 发现 {len(suspicious)} 个可疑社区"
              f"{' (⚠️ 误报团购社区!)' if false_alarm else ' (✅ 无团购社区误报)'}")

        if suspicious and threshold <= 0.5:
            for comm in suspicious:
                nodes_str = [str(n) for n in comm['nodes']]
                print(f"    社区 {comm['community']}: 综合分={comm['total_score']:.3f}, "
                      f"节点数={comm['size']}, 节点={nodes_str[:5]}")

    return {'test': '密集正常社区误报测试'}


def test_multiple_fraud_rings():
    """测试5: 多个独立刷单团伙同时检测"""
    print_separator("测试5: 多个独立刷单团伙检测")
    print("  场景: 3个独立的刷单团伙同时存在于网络中")

    transactions = []

    # 背景正常交易
    for _ in range(200):
        transactions.append({
            'buyer': f"U{random.randint(1, 50):04d}",
            'seller': f"S{random.randint(1, 20):03d}",
            'amount': random.randint(10, 500),
            'rating': random.randint(3, 5)
        })

    # 刷单团伙A: 大团伙（8买家 + 4卖家）
    ringA_buyers = [f"RA_B{i:02d}" for i in range(1, 9)]
    ringA_sellers = [f"RA_S{i:02d}" for i in range(1, 5)]
    for _ in range(120):
        transactions.append({
            'buyer': random.choice(ringA_buyers),
            'seller': random.choice(ringA_sellers),
            'amount': random.randint(500, 2000),
            'rating': 5
        })

    # 刷单团伙B: 中等团伙（4买家 + 2卖家）
    ringB_buyers = [f"RB_B{i:02d}" for i in range(1, 5)]
    ringB_sellers = [f"RB_S{i:02d}" for i in range(1, 3)]
    for _ in range(60):
        transactions.append({
            'buyer': random.choice(ringB_buyers),
            'seller': random.choice(ringB_sellers),
            'amount': random.randint(1000, 5000),
            'rating': 5
        })

    # 刷单团伙C: 小团伙（3买家 + 1卖家）
    ringC_buyers = [f"RC_B{i:02d}" for i in range(1, 4)]
    ringC_sellers = [f"RC_S01"]
    for _ in range(30):
        transactions.append({
            'buyer': random.choice(ringC_buyers),
            'seller': random.choice(ringC_sellers),
            'amount': random.randint(200, 1000),
            'rating': 5
        })

    random.shuffle(transactions)
    print(f"  总交易数: {len(transactions)}")
    print(f"  刷单团伙A: {len(ringA_buyers)}买家 + {len(ringA_sellers)}卖家 (120笔)")
    print(f"  刷单团伙B: {len(ringB_buyers)}买家 + {len(ringB_sellers)}卖家 (60笔)")
    print(f"  刷单团伙C: {len(ringC_buyers)}买家 + {len(ringC_sellers)}卖家 (30笔)")

    builder = TradeGraphBuilder()
    G = builder.build_graph_from_transactions(transactions)

    detector = FraudDetector(fraud_threshold=0.6)
    result = detector.detect(G)

    suspicious = result['fraud_detection']['suspicious_communities_details']
    print(f"\n  检测到可疑社区数: {len(suspicious)}")

    # 检查每个刷单团伙的检测情况
    rings = [
        ("团伙A", set(ringA_buyers + ringA_sellers)),
        ("团伙B", set(ringB_buyers + ringB_sellers)),
        ("团伙C", set(ringC_buyers + ringC_sellers)),
    ]

    all_actual_fraud = set()
    for name, members in rings:
        all_actual_fraud |= members
        detected_members = set()
        for comm in suspicious:
            for n in comm['nodes']:
                if n in members:
                    detected_members.add(n)
        print(f"  {name}: {len(detected_members)}/{len(members)} 被检测到")

    detected_all = set()
    for comm in suspicious:
        for n in comm['nodes']:
            detected_all.add(n)

    tp = len(detected_all & all_actual_fraud)
    fn = len(all_actual_fraud - detected_all)
    fp = len(detected_all - all_actual_fraud)
    print(f"\n  ✅ 总检测效果:")
    print(f"     TP={tp}/{len(all_actual_fraud)}, FN={fn}, FP={fp}")

    return {
        'test': '多团伙检测',
        'total_transactions': len(transactions),
        'total_rings': 3,
        'true_positive': tp,
        'false_negative': fn,
        'false_positive': fp,
        'suspicious_count': len(suspicious),
    }


def test_weight_sensitivity():
    """测试6: 权重参数敏感性分析"""
    print_separator("测试6: 权重参数敏感性分析")
    print("  场景: 固定交易数据，调整权重参数观察检测结果变化")

    transactions = []

    # 正常交易
    for _ in range(100):
        transactions.append({
            'buyer': f"U{random.randint(1, 20):03d}",
            'seller': f"S{random.randint(1, 10):03d}",
            'amount': random.randint(10, 500),
            'rating': random.randint(3, 5)
        })

    # 刷单交易
    fraud_buyers = [f"FB{i:02d}" for i in range(1, 6)]
    fraud_sellers = [f"FS{i:02d}" for i in range(1, 3)]
    for _ in range(50):
        transactions.append({
            'buyer': random.choice(fraud_buyers),
            'seller': random.choice(fraud_sellers),
            'amount': random.randint(500, 2000),
            'rating': 5
        })

    random.shuffle(transactions)
    print(f"  总交易数: {len(transactions)}")

    # 测试不同的权重组合
    weight_configs = [
        {"name": "均衡 (1, 0.01, 1)", "tw": 1.0, "aw": 0.01, "rw": 1.0},
        {"name": "强调评分 (1, 0.01, 5)", "tw": 1.0, "aw": 0.01, "rw": 5.0},
        {"name": "强调金额 (1, 0.1, 1)", "tw": 1.0, "aw": 0.1, "rw": 1.0},
        {"name": "强调次数 (5, 0.01, 1)", "tw": 5.0, "aw": 0.01, "rw": 1.0},
        {"name": "纯次数 (1, 0, 0)", "tw": 1.0, "aw": 0, "rw": 0},
    ]

    results = []
    for cfg in weight_configs:
        builder = TradeGraphBuilder(
            transaction_count_weight=cfg['tw'],
            transaction_amount_weight=cfg['aw'],
            rating_weight=cfg['rw']
        )
        G = builder.build_graph_from_transactions(transactions)
        detector = FraudDetector(fraud_threshold=0.6)
        result = detector.detect(G)
        suspicious = result['fraud_detection']['suspicious_communities_details']

        detected = set()
        for comm in suspicious:
            for n in comm['nodes']:
                detected.add(n)
        actual = set(fraud_buyers + fraud_sellers)
        tp = len(detected & actual)

        print(f"\n  {cfg['name']}:")
        print(f"     边权重范围: {min(d.get('weight',0) for _,_,d in G.edges(data=True)):.1f} ~ "
              f"{max(d.get('weight',0) for _,_,d in G.edges(data=True)):.1f}")
        print(f"     可疑社区: {len(suspicious)}, TP={tp}/{len(actual)}")
        results.append({"config": cfg['name'], "tp": tp, "suspicious_count": len(suspicious)})

    return {"test": "权重敏感性分析", "results": results}


def test_edge_cases():
    """测试7: 边界情况测试"""
    print_separator("测试7: 边界情况测试")

    # 7.1 空图
    print("\n  7.1 空交易数据:")
    builder = TradeGraphBuilder()
    G = builder.build_graph_from_transactions([])
    detector = FraudDetector()
    try:
        result = detector.detect(G)
        print(f"     节点数: {G.number_of_nodes()}, 边数: {G.number_of_edges()}")
        print(f"     检测完成 (不应崩溃)")
    except Exception as e:
        print(f"     ⚠️ 空图检测失败: {e}")
        print(f"     节点数: {G.number_of_nodes()}, 边数: {G.number_of_edges()}")

    # 7.2 极少数交易
    print("\n  7.2 极少数交易:")
    transactions = [
        {'buyer': 'A', 'seller': 'X', 'amount': 100, 'rating': 5},
        {'buyer': 'B', 'seller': 'Y', 'amount': 200, 'rating': 4},
    ]
    G = builder.build_graph_from_transactions(transactions)
    result = detector.detect(G)
    print(f"     节点数: {G.number_of_nodes()}, 边数: {G.number_of_edges()}")
    print(f"     社区数: {result['community_stats']['total_communities']}")

    # 7.3 只有刷单，没有正常交易
    print("\n  7.3 全刷单交易（无正常背景）:")
    transactions = []
    for i in range(5):
        for j in range(3):
            transactions.append({
                'buyer': f"B{i:02d}", 'seller': f"S{j:02d}",
                'amount': 1000, 'rating': 5
            })
    G = builder.build_graph_from_transactions(transactions)
    result = detector.detect(G)
    suspicious = result['fraud_detection']['suspicious_communities_details']
    print(f"     节点数: {G.number_of_nodes()}, 边数: {G.number_of_edges()}")
    print(f"     可疑社区数: {len(suspicious)}")
    print(f"     （如果全图都是刷单，算法可能无法区分——因为缺乏外部对比）")

    # 7.4 大规模图性能测试
    print("\n  7.4 大规模交易图性能测试:")
    transactions = []
    for i in range(100):
        for j in range(50):
            if random.random() < 0.1:
                transactions.append({
                    'buyer': f"UB{i:04d}", 'seller': f"US{j:03d}",
                    'amount': random.randint(10, 1000),
                    'rating': random.randint(3, 5)
                })

    import time
    start = time.time()
    G = builder.build_graph_from_transactions(transactions)
    result = detector.detect(G)
    elapsed = time.time() - start
    print(f"     交易数: {len(transactions)}, 节点: {G.number_of_nodes()}, 边: {G.number_of_edges()}")
    print(f"     耗时: {elapsed:.3f}秒")

    return {"test": "边界情况"}


# ============================================================
# 主测试运行器
# ============================================================

def run_all_tests():
    """运行所有测试并汇总结果"""
    print("\n" + "★" * 35)
    print("  刷单检测图论算法 —— 综合测试套件")
    print("★" * 35 + "\n")

    all_results = []

    # 运行测试
    all_results.append(test_basic_fraud_ring())
    all_results.append(test_hub_and_spoke())
    all_results.append(test_cross_community_fraud())
    all_results.append(test_legitimate_dense_community())
    all_results.append(test_multiple_fraud_rings())
    all_results.append(test_weight_sensitivity())
    all_results.append(test_edge_cases())

    # 汇总报告
    print("\n\n" + "=" * 70)
    print("  测试汇总报告")
    print("=" * 70)

    for r in all_results:
        name = r.get('test', 'Unknown')
        print(f"\n  📋 {name}:")
        if 'true_positive' in r:
            total = r.get('actual_fraud_count', r.get('true_positive', 0) + r.get('false_negative', 0))
            if total > 0:
                recall = r['true_positive'] / total * 100
                print(f"     召回率: {r['true_positive']}/{total} ({recall:.1f}%)")
            print(f"     误报数: {r.get('false_positive', 'N/A')}")
        if 'suspicious_count' in r:
            print(f"     可疑社区数: {r['suspicious_count']}")

    print("\n" + "=" * 70)
    print("  测试完成！")
    print("=" * 70)


if __name__ == "__main__":
    run_all_tests()
