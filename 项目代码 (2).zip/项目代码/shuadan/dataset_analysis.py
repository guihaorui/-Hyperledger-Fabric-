# 第一课：使用经典数据集
print("=== 使用空手道俱乐部数据集 ===")

import networkx as nx
import community as community_louvain
import matplotlib.pyplot as plt

print("✅ 库导入成功")


G = nx.karate_club_graph()

print("📊 数据集信息：")
print(f"   名称: 空手道俱乐部网络 (Zachary's Karate Club)")
print(f"   节点数: {G.number_of_nodes()}")  # 34个成员
print(f"   边数: {G.number_of_edges()}")   # 78个社交关系

# 2. 查看网络的基本信息
print(f"\n🔍 网络基本属性：")
print(f"   是否连通: {nx.is_connected(G)}")
print(f"   平均度: {sum(dict(G.degree()).values()) / G.number_of_nodes():.2f}")
print(f"   聚类系数: {nx.average_clustering(G):.3f}")

# 3. 查看前10个节点的连接情况
print(f"\n👥 前10个成员的连接数：")
for node in list(G.nodes())[:10]:
    degree = G.degree(node)
    print(f"   成员 {node}: {degree} 个连接")

# 4. 运行 Louvain 算法
print(f"\n🔍 正在运行 Louvain 算法...")
partition = community_louvain.best_partition(G)

# 5. 显示社区发现结果
communities = set(partition.values())
print(f"\n🎯 社区发现结果：")
print(f"   发现了 {len(communities)} 个社区")

# 统计每个社区的大小
from collections import Counter
community_sizes = Counter(partition.values())
print(f"   各社区规模: {dict(community_sizes)}")

# 6. 计算模块度（社区划分质量指标）
modularity = community_louvain.modularity(partition, G)
print(f"   模块度: {modularity:.4f} (越接近1越好)")

print("\n✅ 数据分析完成！")