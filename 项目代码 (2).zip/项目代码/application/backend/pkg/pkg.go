package pkg

import (
	"crypto/md5"
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"io"
	"os"

	"github.com/bwmarrin/snowflake"
	"github.com/gin-gonic/gin"
)

// 本文件包含雪花ID、MD5函数
func GenerateID() string {
	node, _ := snowflake.NewNode(1)

	id := node.Generate()
	return id.String()
}

func EncryptByMD5(str string) string {
	data := []byte(str)
	hash := md5.Sum(data)
	hashstr := hex.EncodeToString(hash[:])
	return hashstr
}

// 计算文件的 SHA-256 哈希值
func CalculateFileSHA256(filePath string) (string, error) {
	file, err := os.Open(filePath)
	if err != nil {
		return "", err
	}
	defer file.Close()

	hash := sha256.New()
	if _, err := io.Copy(hash, file); err != nil {
		return "", err
	}

	hashBytes := hash.Sum(nil)
	return hex.EncodeToString(hashBytes), nil
}

// 上传文件至IPFS，返回cid与sha256
func UploadFile(filePath string) (string, string, error) {
	cid, err := IpfsAdd(filePath)
	if err != nil {
		return "", "", err
	}
	sha256, err := CalculateFileSHA256(filePath)
	if err != nil {
		return "", "", err
	}
	return cid, sha256, nil
}

func Download(c *gin.Context) {
	cid := c.Param("cid")
	filename := c.Query("filename")
	err := IpfsGet(cid, filename)
	if err != nil {
		c.JSON(200, gin.H{
			"message": "下载失败",
		})
		return
	}
	c.File(fmt.Sprintf("./files/downloadfiles/%v", filename))
	c.JSON(200, gin.H{
		"message":  "下载成功",
		"cid":      cid,
		"filename": filename,
	})
}
