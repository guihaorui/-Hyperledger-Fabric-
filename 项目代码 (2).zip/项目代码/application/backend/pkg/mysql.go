package pkg

import (
	"backend/model"
	"database/sql"
	"time"

	_ "github.com/go-sql-driver/mysql"
	"github.com/pkg/errors"
	"github.com/spf13/viper"
)

// 定义一个全局对象db
var db *sql.DB

func MysqlInit() (err error) {
	// 初始化数据库
	dsn := viper.GetString("mysql.user") + ":" + viper.GetString("mysql.password") + "@tcp(" + viper.GetString("mysql.host") + ":" + viper.GetString("mysql.port") + ")/?tls=skip-verify&allowNativePasswords=true"
	// 不会校验账号密码是否正确
	// 注意！！！这里不要使用:=，我们是给全局变量赋值，然后在main函数中使用全局变量db
	db, err = sql.Open("mysql", dsn)
	if err != nil {
		return err
	}
	db.SetConnMaxLifetime(time.Minute)
	// 创建数据库与表（如果不存在的话）
	db.Exec("CREATE DATABASE IF NOT EXISTS " + viper.GetString("mysql.db"))
	db.Exec("USE " + viper.GetString("mysql.db"))
	_, err = db.Exec("CREATE TABLE IF NOT EXISTS users (user_id VARCHAR(50) PRIMARY KEY, username VARCHAR(50) UNIQUE NOT NULL, password VARCHAR(50) NOT NULL, realInfo VARCHAR(100))")
	if err != nil {
		panic(err.Error())
	}
	// 重新配置下数据库连接信息
	dsn = viper.GetString("mysql.user") + ":" + viper.GetString("mysql.password") + "@tcp(" + viper.GetString("mysql.host") + ":" + viper.GetString("mysql.port") + ")/" + viper.GetString("mysql.db") + "?tls=skip-verify&allowNativePasswords=true"
	db, err = sql.Open("mysql", dsn)
	if err != nil {
		return err
	}
	// 创建刷单检测相关表
	_, err = db.Exec(`CREATE TABLE IF NOT EXISTS fraud_detection_results (
		id INT AUTO_INCREMENT PRIMARY KEY,
		timestamp VARCHAR(50) NOT NULL,
		total_nodes INT NOT NULL,
		total_edges INT NOT NULL,
		transaction_count INT NOT NULL,
		high_risk_count INT NOT NULL,
		medium_risk_count INT NOT NULL,
		low_risk_count INT NOT NULL,
		processing_time FLOAT NOT NULL,
		report_summary TEXT,
		created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
	)`)
	if err != nil {
		panic(err.Error())
	}
	_, err = db.Exec(`CREATE TABLE IF NOT EXISTS suspicious_users (
		id INT AUTO_INCREMENT PRIMARY KEY,
		detection_id INT NOT NULL,
		user_id VARCHAR(50) NOT NULL,
		suspicion_score FLOAT NOT NULL,
		reasons TEXT,
		transaction_count INT NOT NULL,
		total_amount INT NOT NULL,
		last_active_time VARCHAR(50),
		created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
		FOREIGN KEY (detection_id) REFERENCES fraud_detection_results(id) ON DELETE CASCADE
	)`)
	if err != nil {
		panic(err.Error())
	}
	_, err = db.Exec(`CREATE TABLE IF NOT EXISTS fraud_communities (
		id INT AUTO_INCREMENT PRIMARY KEY,
		detection_id INT NOT NULL,
		community_id INT NOT NULL,
		suspicion_score FLOAT NOT NULL,
		members TEXT,
		real_buyers INT NOT NULL,
		fraud_buyers INT NOT NULL,
		honest_sellers INT NOT NULL,
		fraud_sellers INT NOT NULL,
		avg_rating FLOAT NOT NULL,
		fraud_ratio FLOAT NOT NULL,
		transaction_count INT NOT NULL,
		total_amount INT NOT NULL,
		created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
		FOREIGN KEY (detection_id) REFERENCES fraud_detection_results(id) ON DELETE CASCADE
	)`)
	if err != nil {
		panic(err.Error())
	}
	// 尝试与数据库建立连接（校验dsn是否正确）
	err = db.Ping()
	if err != nil {
		panic(err.Error())
	}
	return nil
}

// 注册
func InsertUser(user *model.MysqlUser) (err error) {
	sqlStr := "select count(user_id) from users where username = ?"
	var count int64
	err = db.QueryRow(sqlStr, user.Username).Scan(&count)
	if err != nil {
		return err
	}
	if count > 0 {
		return errors.New("用户名已存在")
	}
	sqlStr = "insert into users(user_id,username,password,realInfo) values(?,?,?,?)"
	_, err = db.Exec(sqlStr, user.UserID, user.Username, EncryptByMD5(user.Password), EncryptByMD5(user.RealInfo))
	if err != nil {
		return err
	}
	return nil
}

// 登录
func Login(user *model.MysqlUser) (err error) {
	sqlStr := "select username,password from users where username = ?"
	var password string
	err = db.QueryRow(sqlStr, user.Username).Scan(&user.Username, &password)
	if err != nil {
		return err
	}
	if EncryptByMD5(user.Password) != password {
		return errors.New("密码错误")
	}
	return nil
}

// 获取用户ID
func GetUserID(username string) (userID string, err error) {
	sqlStr := "select user_id from users where username = ?"
	err = db.QueryRow(sqlStr, username).Scan(&userID)
	if err != nil {
		return "", err
	}
	return userID, nil
}

// 获取用户姓名
func GetUsername(userID string) (username string, err error) {
	sqlStr := "select username from users where user_id = ?"
	err = db.QueryRow(sqlStr, userID).Scan(&username)
	if err != nil {
		return "", err
	}
	return username, nil
}

// 插入刷单检测结果
func InsertFraudDetectionResult(result map[string]interface{}) (int64, error) {
	sqlStr := `INSERT INTO fraud_detection_results
		(timestamp, total_nodes, total_edges, transaction_count,
		 high_risk_count, medium_risk_count, low_risk_count,
		 processing_time, report_summary)
		VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
	res, err := db.Exec(sqlStr,
		result["timestamp"],
		result["total_nodes"],
		result["total_edges"],
		result["transaction_count"],
		result["high_risk_count"],
		result["medium_risk_count"],
		result["low_risk_count"],
		result["processing_time"],
		result["report_summary"],
	)
	if err != nil {
		return 0, err
	}
	id, err := res.LastInsertId()
	if err != nil {
		return 0, err
	}
	return id, nil
}

// 插入可疑用户
func InsertSuspiciousUsers(detectionId int64, users []map[string]interface{}) error {
	for _, user := range users {
		sqlStr := `INSERT INTO suspicious_users
			(detection_id, user_id, suspicion_score, reasons,
			 transaction_count, total_amount, last_active_time)
			VALUES (?, ?, ?, ?, ?, ?, ?)`
		_, err := db.Exec(sqlStr,
			detectionId,
			user["user_id"],
			user["suspicion_score"],
			user["reasons"],
			user["transaction_count"],
			user["total_amount"],
			user["last_active_time"],
		)
		if err != nil {
			return err
		}
	}
	return nil
}

// 插入社区分析结果
func InsertFraudCommunities(detectionId int64, communities []map[string]interface{}) error {
	for _, comm := range communities {
		sqlStr := `INSERT INTO fraud_communities
			(detection_id, community_id, suspicion_score, members,
			 real_buyers, fraud_buyers, honest_sellers, fraud_sellers,
			 avg_rating, fraud_ratio, transaction_count, total_amount)
			VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
		_, err := db.Exec(sqlStr,
			detectionId,
			comm["community_id"],
			comm["suspicion_score"],
			comm["members"],
			comm["real_buyers"],
			comm["fraud_buyers"],
			comm["honest_sellers"],
			comm["fraud_sellers"],
			comm["avg_rating"],
			comm["fraud_ratio"],
			comm["transaction_count"],
			comm["total_amount"],
		)
		if err != nil {
			return err
		}
	}
	return nil
}

// 获取最新的检测结果
func GetLatestDetectionResult() (map[string]interface{}, error) {
	sqlStr := `SELECT * FROM fraud_detection_results
		ORDER BY created_at DESC LIMIT 1`
	row := db.QueryRow(sqlStr)

	var id int64
	var timestamp string
	var totalNodes, totalEdges, transactionCount int
	var highRisk, mediumRisk, lowRisk int
	var processingTime float64
	var reportSummary sql.NullString
	var createdAt string

	err := row.Scan(&id, &timestamp, &totalNodes, &totalEdges,
		&transactionCount, &highRisk, &mediumRisk, &lowRisk,
		&processingTime, &reportSummary, &createdAt)
	if err != nil {
		if err == sql.ErrNoRows {
			return nil, nil
		}
		return nil, err
	}

	result := map[string]interface{}{
		"id": id,
		"timestamp": timestamp,
		"total_nodes": totalNodes,
		"total_edges": totalEdges,
		"transaction_count": transactionCount,
		"high_risk_count": highRisk,
		"medium_risk_count": mediumRisk,
		"low_risk_count": lowRisk,
		"processing_time": processingTime,
		"report_summary": reportSummary.String,
		"created_at": createdAt,
	}
	return result, nil
}

// 获取检测结果的可疑用户
func GetSuspiciousUsersByDetectionId(detectionId int64) ([]map[string]interface{}, error) {
	sqlStr := `SELECT * FROM suspicious_users
		WHERE detection_id = ? ORDER BY suspicion_score DESC`
	rows, err := db.Query(sqlStr, detectionId)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	users := []map[string]interface{}{}
	for rows.Next() {
		var id int64
		var detId int64
		var userId string
		var score float64
		var reasons sql.NullString
		var txCount, totalAmount int
		var lastActive sql.NullString
		var createdAt string

		err = rows.Scan(&id, &detId, &userId, &score, &reasons,
			&txCount, &totalAmount, &lastActive, &createdAt)
		if err != nil {
			return nil, err
		}

		user := map[string]interface{}{
			"id": id,
			"detection_id": detId,
			"user_id": userId,
			"suspicion_score": score,
			"reasons": reasons.String,
			"transaction_count": txCount,
			"total_amount": totalAmount,
			"last_active_time": lastActive.String,
			"created_at": createdAt,
		}
		users = append(users, user)
	}
	return users, nil
}

// 获取检测结果的社区分析
func GetCommunitiesByDetectionId(detectionId int64) ([]map[string]interface{}, error) {
	sqlStr := `SELECT * FROM fraud_communities
		WHERE detection_id = ? ORDER BY suspicion_score DESC`
	rows, err := db.Query(sqlStr, detectionId)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	communities := []map[string]interface{}{}
	for rows.Next() {
		var id int64
		var detId int64
		var commId int
		var score float64
		var members sql.NullString
		var realBuyers, fraudBuyers, honestSellers, fraudSellers int
		var avgRating, fraudRatio float64
		var txCount, totalAmount int
		var createdAt string

		err = rows.Scan(&id, &detId, &commId, &score, &members,
			&realBuyers, &fraudBuyers, &honestSellers, &fraudSellers,
			&avgRating, &fraudRatio, &txCount, &totalAmount, &createdAt)
		if err != nil {
			return nil, err
		}

		comm := map[string]interface{}{
			"id": id,
			"detection_id": detId,
			"community_id": commId,
			"suspicion_score": score,
			"members": members.String,
			"real_buyers": realBuyers,
			"fraud_buyers": fraudBuyers,
			"honest_sellers": honestSellers,
			"fraud_sellers": fraudSellers,
			"avg_rating": avgRating,
			"fraud_ratio": fraudRatio,
			"transaction_count": txCount,
			"total_amount": totalAmount,
			"created_at": createdAt,
		}
		communities = append(communities, comm)
	}
	return communities, nil
}

// 获取历史检测记录总数
func GetDetectionHistoryCount() (int, error) {
	var count int
	err := db.QueryRow("SELECT COUNT(*) FROM fraud_detection_results").Scan(&count)
	if err != nil {
		return 0, err
	}
	return count, nil
}

// 获取可疑用户总数
func GetTotalSuspiciousCount() (int, error) {
	var count int
	err := db.QueryRow("SELECT COUNT(*) FROM suspicious_users").Scan(&count)
	if err != nil {
		return 0, err
	}
	return count, nil
}

// 获取所有历史检测记录
func GetAllDetectionResults() ([]map[string]interface{}, error) {
	sqlStr := "SELECT * FROM fraud_detection_results ORDER BY created_at DESC"
	rows, err := db.Query(sqlStr)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	results := []map[string]interface{}{}
	for rows.Next() {
		var id int64
		var timestamp string
		var totalNodes, totalEdges, transactionCount int
		var highRisk, mediumRisk, lowRisk int
		var processingTime float64
		var reportSummary sql.NullString
		var createdAt string

		err = rows.Scan(&id, &timestamp, &totalNodes, &totalEdges,
			&transactionCount, &highRisk, &mediumRisk, &lowRisk,
			&processingTime, &reportSummary, &createdAt)
		if err != nil {
			return nil, err
		}

		result := map[string]interface{}{
			"id":                id,
			"timestamp":         timestamp,
			"total_nodes":       totalNodes,
			"total_edges":       totalEdges,
			"transaction_count": transactionCount,
			"high_risk_count":   highRisk,
			"medium_risk_count": mediumRisk,
			"low_risk_count":    lowRisk,
			"processing_time":   processingTime,
			"report_summary":    reportSummary.String,
			"created_at":        createdAt,
		}
		results = append(results, result)
	}
	return results, nil
}

// 删除可疑用户标记
func DeleteSuspiciousMark(userID string) error {
	_, err := db.Exec("DELETE FROM suspicious_users WHERE user_id = ?", userID)
	return err
}
