package router

// 路由文件
import (
	con "backend/controller"
	"backend/middleware"
	pkg "backend/pkg"
	"time"

	"github.com/gin-contrib/cors"
	"github.com/gin-gonic/gin"
)

func SetupRouter() *gin.Engine {
	r := gin.Default()
	// 解决跨域问题
	r.Use(cors.New(cors.Config{
		AllowOrigins:     []string{"*"},                                       // 允许的来源
		AllowMethods:     []string{"GET", "POST", "PUT", "DELETE"},            // 允许的请求方法
		AllowHeaders:     []string{"Origin", "Authorization", "Content-Type"}, // 允许的请求头
		ExposeHeaders:    []string{"Content-Length"},                          // 暴露的响应头
		AllowCredentials: true,                                                // 允许传递凭据（例如 Cookie）
		MaxAge:           12 * time.Hour,                                      // 预检请求的有效期
	}))
	// 设置静态文件目录
	// r.Static("/static", "./dist/static")
	// r.LoadHTMLGlob("dist/*.html")
	r.GET("/", func(c *gin.Context) {
		c.HTML(200, "index.html", nil)
	})
	// 测试GET请求
	r.GET("/ping", func(c *gin.Context) {
		c.JSON(200, gin.H{
			"message": "pong",
		})
	})
	//注册
	r.POST("/register", con.Register)
	//登录
	r.POST("/login", con.Login)
	//登出
	r.POST("/logout", con.Logout)
	//查询用户的类型
	r.POST("/getInfo", middleware.JWTAuthMiddleware(), con.GetInfo)
	//质押相关
	r.POST("/stake", middleware.JWTAuthMiddleware(), con.StakeTokens)
	r.POST("/unstake", middleware.JWTAuthMiddleware(), con.UnstakeTokens)
	r.POST("/checkStake", middleware.JWTAuthMiddleware(), con.CheckStakeStatus)
	r.POST("/getStakeRecords", middleware.JWTAuthMiddleware(), con.GetStakeRecords)
	r.POST("/getReputation", middleware.JWTAuthMiddleware(), con.GetReputation)
	//评分相关
	r.POST("/rateAsset", middleware.JWTAuthMiddleware(), con.RateAsset)
	r.POST("/getAssetRatings", middleware.JWTAuthMiddleware(), con.GetAssetRatings)
	r.POST("/getUserRatings", middleware.JWTAuthMiddleware(), con.GetUserRatings)
	//创建资产上链
	r.POST("/createAsset", middleware.JWTAuthMiddleware(), con.CreateAsset)
	// 获取数据资产的上链信息
	r.POST("/getAsset", con.ReadAsset)
	// 获取用户的资产列表
	r.POST("/getUserAssets", middleware.JWTAuthMiddleware(), con.GetUserAssets)
	// 获取所有资产信息
	r.POST("/getAllAssets", middleware.JWTAuthMiddleware(), con.GetAllAssets)
	// 用户转账
	r.POST("/transfer", middleware.JWTAuthMiddleware(), con.Transfer)
	// 购买资产
	r.POST("/buyAsset", middleware.JWTAuthMiddleware(), con.BuyAsset)
	// 余额流水查询
	r.POST("/getBalanceRecords", middleware.JWTAuthMiddleware(), con.GetBalanceRecords)
	// 资产历史价格
	r.POST("/getAssetPriceHistory", middleware.JWTAuthMiddleware(), con.GetAssetPriceHistory)
	r.GET("/downloadAsset", con.DownloadAsset)
	r.GET("/download/:cid", pkg.Download)

	// 设置管理员路由组,管理员路由组添加是否是管理员的中间件
	admin := r.Group("/admin")
	// admin.Use(middleware.JWTAuthMiddleware(), middleware.IsAdminMiddleware())
	admin.Use(middleware.JWTAuthMiddleware())
	{
		// 获取用户信息
		admin.POST("/getUser", con.GetUser)
		// 获取所有用户信息
		admin.POST("/getAllUsers", con.GetAllUsers)
		// 更新用户信息
		admin.POST("/updateUser", con.UpdateUser)
		// 删除用户
		admin.POST("/deleteUser", con.DeleteUser)
		// 获取所有资产信息
		admin.POST("/getAllAssets", con.GetAllAssets)
		// 更新资产信息
		admin.POST("/updateAsset", con.UpdateAsset)
		// 删除资产
		admin.POST("/deleteAsset", con.DeleteAsset)
		// 重新计算用户信誉分
		admin.POST("/calculateReputation", con.CalculateReputation)
		// 审核相关
		admin.POST("/auditAsset", con.AuditAsset)
		admin.POST("/getPendingAssets", con.GetPendingAssets)
		admin.POST("/updateAssetPriority", con.UpdateAssetPriority)
		admin.POST("/getAuditRewards", con.GetAuditRewards)
			// 价格常量配置
			admin.POST("/getPriceConstants", con.GetPriceConstants)
			admin.POST("/updatePriceConstants", con.UpdatePriceConstants)
			// 刷单检测相关
			admin.POST("/fraud/detect", con.DetectWashTrading)
			admin.GET("/fraud/report", con.GetDetectionReport)
			admin.GET("/fraud/suspicious-users", con.GetSuspiciousUsers)
			admin.GET("/fraud/community-analysis", con.GetCommunityAnalysis)
			admin.POST("/fraud/mark-suspicious", con.MarkUserAsSuspicious)
				admin.GET("/fraud/stats", con.GetFraudStats)
				admin.GET("/fraud/history", con.GetDetectionHistory)
				admin.POST("/fraud/clear-mark", con.ClearSuspiciousMark)
	}

	return r
}
