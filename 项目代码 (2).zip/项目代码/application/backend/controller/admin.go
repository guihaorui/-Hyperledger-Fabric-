package controller

import (
	"backend/pkg"

	"github.com/gin-gonic/gin"
)

// 获取用户信息
// 传入用户ID
func GetUser(c *gin.Context) {
	// 获取用户ID
	userID := c.PostForm("userID")
	// 调用链码查询用户信息
	user, err := pkg.ChaincodeQuery("ReadUser", userID)
	if err != nil {
		c.JSON(200, gin.H{
			"message": "获取用户信息失败：" + err.Error(),
		})
		return
	}
	c.JSON(200, gin.H{
		"code":    200,
		"message": "获取用户信息成功",
		"data":    user,
	})
}

func GetAllUsers(c *gin.Context) {
	userList, err := pkg.ChaincodeQuery("GetAllUsers", "")
	if err != nil {
		c.JSON(200, gin.H{
			"message": "获取用户信息失败：" + err.Error(),
		})
		return
	}
	c.JSON(200, gin.H{
		"code":    200,
		"message": "获取用户信息成功",
		"data":    userList,
	})
}

func UpdateUser(c *gin.Context) {
	// 获取用户ID
	userID := c.PostForm("userID")
	// 获取用户姓名
	userName := c.PostForm("userName")
	// 获取用户类型
	userType := c.PostForm("userType")
	// 获取用户余额
	balance := c.PostForm("balance")
	// 调用链码更新用户信息
	res, err := pkg.ChaincodeInvoke("UpdateUser", []string{userID, userName, userType, balance})
	if err != nil {
		c.JSON(200, gin.H{
			"message": "更新用户信息失败：" + err.Error(),
		})
		return
	}
	c.JSON(200, gin.H{
		"code":    200,
		"message": "更新用户信息成功",
		"txid":    res,
	})
}

func DeleteUser(c *gin.Context) {
	// 获取用户ID
	userID := c.PostForm("userID")
	// 调用链码删除用户信息
	res, err := pkg.ChaincodeInvoke("DeleteUser", []string{userID})
	if err != nil {
		c.JSON(200, gin.H{
			"message": "删除用户失败：" + err.Error(),
		})
		return
	}
	c.JSON(200, gin.H{
		"code":    200,
		"message": "删除用户成功",
		"txid":    res,
	})
}

func AssetDelfromUser(c *gin.Context) {
	// 获取用户ID
	userID := c.PostForm("userID")
	// 获取资产ID
	assetID := c.PostForm("assetID")
	// 调用链码删除用户资产
	res, err := pkg.ChaincodeInvoke("AssetDelfromUser", []string{userID, assetID})
	if err != nil {
		c.JSON(200, gin.H{
			"message": "删除用户资产失败：" + err.Error(),
		})
		return
	}
	c.JSON(200, gin.H{
		"code":    200,
		"message": "删除用户资产成功",
		"txid":    res,
	})
}

// GetPriceConstants 获取价格算法常量配置
func GetPriceConstants(c *gin.Context) {
	constants, err := pkg.ChaincodeQuery("GetPriceConstants", "")
	if err != nil {
		c.JSON(200, gin.H{
			"message": "获取价格常量失败：" + err.Error(),
		})
		return
	}
	c.JSON(200, gin.H{
		"code":    200,
		"message": "获取价格常量成功",
		"data":    constants,
	})
}

// UpdatePriceConstants 更新价格算法常量配置
func UpdatePriceConstants(c *gin.Context) {
	// 从表单中获取常量参数
	k_up := c.PostForm("k_up")
	k_down := c.PostForm("k_down")
	s := c.PostForm("s")
	lambda := c.PostForm("lambda")
	c_val := c.PostForm("c")
	rating_threshold := c.PostForm("rating_threshold")
	max_change_rate := c.PostForm("max_change_rate")
	increase_rate_per_point := c.PostForm("increase_rate_per_point")
	decrease_rate_per_point := c.PostForm("decrease_rate_per_point")
	// 调用链码更新常量
	res, err := pkg.ChaincodeInvoke("UpdatePriceConstants", []string{k_up, k_down, s, lambda, c_val, rating_threshold, max_change_rate, increase_rate_per_point, decrease_rate_per_point})
	if err != nil {
		c.JSON(200, gin.H{
			"message": "更新价格常量失败：" + err.Error(),
		})
		return
	}
	c.JSON(200, gin.H{
		"code":    200,
		"message": "更新价格常量成功",
		"txid":    res,
	})
}
