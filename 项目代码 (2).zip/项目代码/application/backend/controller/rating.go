package controller

import (
	"backend/pkg"
	"strconv"

	"github.com/gin-gonic/gin"
)

// 给资产评分
func RateAsset(c *gin.Context) {
	userID, exist := c.Get("userID")
	if !exist {
		c.JSON(200, gin.H{
			"message": "获取用户ID失败",
		})
		return
	}

	assetID := c.PostForm("assetID")
	ratingStr := c.PostForm("rating")
	comment := c.PostForm("comment")

	if assetID == "" {
		c.JSON(200, gin.H{
			"message": "资产ID不能为空",
		})
		return
	}

	if ratingStr == "" {
		c.JSON(200, gin.H{
			"message": "评分不能为空",
		})
		return
	}

	// 验证评分范围
	rating, err := strconv.Atoi(ratingStr)
	if err != nil || rating < 1 || rating > 10 {
		c.JSON(200, gin.H{
			"message": "评分必须是1-10之间的整数",
		})
		return
	}

	// 调用链码评分函数
	res, err := pkg.ChaincodeInvoke("RateAsset", []string{assetID, userID.(string), ratingStr, comment})
	if err != nil {
		c.JSON(200, gin.H{
			"message": "评分失败：" + err.Error(),
		})
		return
	}

	c.JSON(200, gin.H{
		"code":    200,
		"message": "评分成功",
		"txid":    res,
	})
}

// 获取资产评分记录
func GetAssetRatings(c *gin.Context) {
	assetID := c.PostForm("assetID")
	if assetID == "" {
		c.JSON(200, gin.H{
			"message": "资产ID不能为空",
		})
		return
	}

	// 调用链码获取评分记录
	res, err := pkg.ChaincodeQuery("GetAssetRatings", assetID)
	if err != nil {
		c.JSON(200, gin.H{
			"message": "获取评分记录失败：" + err.Error(),
		})
		return
	}

	c.JSON(200, gin.H{
		"code":    200,
		"message": "查询成功",
		"ratings": res,
	})
}

// 获取用户收到的评分记录
func GetUserRatings(c *gin.Context) {
	userID, exist := c.Get("userID")
	if !exist {
		c.JSON(200, gin.H{
			"message": "获取用户ID失败",
		})
		return
	}

	// 调用链码获取用户评分记录
	res, err := pkg.ChaincodeQuery("GetUserRatings", userID.(string))
	if err != nil {
		c.JSON(200, gin.H{
			"message": "获取用户评分记录失败：" + err.Error(),
		})
		return
	}

	c.JSON(200, gin.H{
		"code":    200,
		"message": "查询成功",
		"ratings": res,
	})
}