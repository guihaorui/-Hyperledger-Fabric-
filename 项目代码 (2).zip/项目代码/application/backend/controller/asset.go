package controller

import (
	"backend/pkg"
	"fmt"

	"github.com/gin-gonic/gin"
)

// // 资产结构体，包含资产ID、资产名称、资产作者、当前持有者、资产详情、资产价格、租借时间
// type Asset struct {
// 	ID           string      `json:"id"`
// 	Name         string      `json:"name"`
// 	AssetType    string      `json:"asset_type"`
// 	Org          string      `json:"org"`
// 	Detail       string      `json:"detail"`
// 	Author       string      `json:"author"`
// 	Sha256       string      `json:"sha256"`
// 	IPFSHash     string      `json:"ipfs_hash"`
// 	CurrentOwner string      `json:"current_owner"`
// 	Price        int         `json:"price"`
// 	ForSell      bool        `json:"for_sell"`
// 	AuthPrice    int         `json:"auth_price"`
// 	ForAuth      bool        `json:"for_auth"`
// 	CreateTime   string      `json:"create_time"`
// 	ExList       []ExHistory `json:"ex_list"`
// }

// 资产的增删改查
// CreateAsset 创建资产
func CreateAsset(c *gin.Context) {
	// 与userID不一样，取ID从第10位作为溯源码
	// +--------------------------------------------------------------------------+
	// | 1 Bit Unused | 41 Bit Timestamp |  10 Bit NodeID  |   12 Bit Sequence ID |
	// +--------------------------------------------------------------------------+
	asset_traceability_code := pkg.GenerateID()[9:]
	userID, exist := c.Get("userID")
	if !exist {
		c.JSON(200, gin.H{
			"message": "获取用户ID失败",
		})
		return
	}
	// 计算文件的 SHA-256 哈希值
	file, err := c.FormFile("file")
	if err != nil {
		c.JSON(200, gin.H{
			"message": "获取文件失败",
		})
		return
	}
	err = c.SaveUploadedFile(file, fmt.Sprintf("./files/uploadfiles/%v", file.Filename))
	if err != nil {
		c.JSON(200, gin.H{
			"message": "保存文件失败",
		})
		return
	}
	ipfs_hash, sha256, err := pkg.UploadFile(fmt.Sprintf("./files/uploadfiles/%v", file.Filename))
	if err != nil {
		c.JSON(200, gin.H{
			"message": "上传文件失败：" + err.Error(),
		})
		return
	}

	// 构建上链args
	args := []string{
		asset_traceability_code,
		c.PostForm("name"),
		c.PostForm("asset_type"),
		c.PostForm("org"),
		c.PostForm("detail"),
		userID.(string),
		sha256,
		ipfs_hash,
		c.PostForm("price"),
		c.PostForm("for_sell"),
		c.PostForm("auth_price"),
		c.PostForm("for_auth"),
	}

	if len(args) == 0 {
		c.JSON(200, gin.H{
			"message": "args is empty",
		})
		return
	}
	res, err := pkg.ChaincodeInvoke("CreateAsset", args)
	if err != nil {
		c.JSON(200, gin.H{
			"message": "uplink failed" + err.Error(),
		})
		return
	}
	c.JSON(200, gin.H{
		"code":              200,
		"message":           "uplink success",
		"txid":              res,
		"traceability_code": args[0],
	})
}

// GetAssetInfo 获取资产的上链信息
func ReadAsset(c *gin.Context) {
	res, err := pkg.ChaincodeQuery("ReadAsset", c.PostForm("traceability_code"))
	if err != nil {
		c.JSON(200, gin.H{
			"message": "查询失败：" + err.Error(),
		})
		return
	}
	c.JSON(200, gin.H{
		"code":    200,
		"message": "query success",
		"data":    res,
	})
}

func GetUserAssets(c *gin.Context) {
	userID, exist := c.Get("userID")
	if !exist {
		c.JSON(200, gin.H{
			"message": "获取用户ID失败",
		})
		return
	}
	res, err := pkg.ChaincodeQuery("GetUserAssets", userID.(string))
	if err != nil {
		c.JSON(200, gin.H{
			"message": "查询失败：" + err.Error(),
		})
		return
	}
	c.JSON(200, gin.H{
		"code":    200,
		"message": "query success",
		"data":    res,
	})
}

// GetAssetList 获取资产列表
func GetAllAssets(c *gin.Context) {
	res, err := pkg.ChaincodeQuery("GetAllAssets", "")
	if err != nil {
		c.JSON(200, gin.H{
			"message": "查询失败：" + err.Error(),
		})
		return
	}
	c.JSON(200, gin.H{
		"code":    200,
		"message": "query success",
		"data":    res,
	})
}

func UpdateAsset(c *gin.Context) {

	// 构建上链args
	args := []string{
		c.PostForm("traceability_code"),
		c.PostForm("name"),
		c.PostForm("asset_type"),
		c.PostForm("org"),
		c.PostForm("detail"),
		c.PostForm("author"),
		c.PostForm("current_owner"),
		c.PostForm("sha256"),
		c.PostForm("ipfs_hash"),
		c.PostForm("price"),
		c.PostForm("for_sell"),
		c.PostForm("auth_price"),
		c.PostForm("for_auth"),
	}
	if len(args) == 0 {
		c.JSON(200, gin.H{
			"message": "args is empty",
		})
		return
	}

	// 构建args
	res, err := pkg.ChaincodeInvoke("UpdateAsset", args)
	if err != nil {
		c.JSON(200, gin.H{
			"message": "update failed" + err.Error(),
		})
		return
	}
	c.JSON(200, gin.H{
		"code":    200,
		"message": "update success",
		"txid":    res,
	})
}

func DeleteAsset(c *gin.Context) {

	res, err := pkg.ChaincodeInvoke("DeleteAsset", []string{c.PostForm("traceability_code")})
	if err != nil {
		c.JSON(200, gin.H{
			"message": "删除失败：" + err.Error(),
		})
		return
	}
	c.JSON(200, gin.H{
		"code":    200,
		"message": "删除成功！",
		"txid":    res,
	})
}

// 获取资产历史价格
func GetAssetPriceHistory(c *gin.Context) {
	assetID := c.PostForm("traceability_code")
	if assetID == "" {
		c.JSON(200, gin.H{
			"message": "资产ID不能为空",
		})
		return
	}

	priceHistory, err := pkg.ChaincodeQuery("GetAssetPriceHistory", assetID)
	if err != nil {
		c.JSON(200, gin.H{
			"message": "获取价格历史失败：" + err.Error(),
		})
		return
	}

	c.JSON(200, gin.H{
		"code":     200,
		"message":  "查询成功",
		"history":  priceHistory,
	})
}

func DownloadAsset(c *gin.Context) {
	cid := c.Query("cid")
	filename := c.Query("filename")

	filePath := fmt.Sprintf("./files/downloadfiles/%v", filename)

	err := pkg.IpfsGet(cid, filename)
	if err != nil {
		c.JSON(500, gin.H{
			"message": "下载失败：" + err.Error(),
		})
		return
	}

	c.Header("Content-Description", "File Transfer")
	c.Header("Content-Disposition", "attachment; filename="+filename)
	c.Header("Content-Type", "application/octet-stream")

	c.File(filePath)
}
