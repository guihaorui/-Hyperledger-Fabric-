package controller

import (
	"backend/pkg"
	"backend/pkg/fraud_detection"
	"encoding/json"
	"fmt"
	"sort"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
)

// DetectWashTrading 触发刷单检测分析
func DetectWashTrading(c *gin.Context) {
	// 获取请求参数
	startTime := c.PostForm("start_time")
	endTime := c.PostForm("end_time")
	highFreqThreshold := c.PostForm("high_freq_threshold")
	communityDetection := c.PostForm("community_detection")

	// 构建请求参数
	args := []string{}
	if startTime != "" && endTime != "" {
		args = []string{startTime, endTime}
	}

	// 调用链码获取交易数据
	var transactionsData []map[string]interface{}

	if len(args) == 2 {
		// 获取时间范围内的交易
		result, err := pkg.ChaincodeQuery("GetTransactionsByTimeRange", args...)
		if err != nil {
			c.JSON(200, gin.H{
				"code":    500,
				"message": fmt.Sprintf("获取交易数据失败: %v", err),
			})
			return
		}

		// 解析JSON结果
		if err := json.Unmarshal([]byte(result), &transactionsData); err != nil {
			c.JSON(200, gin.H{
				"code":    500,
				"message": fmt.Sprintf("解析交易数据失败: %v", err),
			})
			return
		}
	} else {
		// 获取所有交易
		result, err := pkg.ChaincodeQuery("GetAllTransactions")
		if err != nil {
			c.JSON(200, gin.H{
				"code":    500,
				"message": fmt.Sprintf("获取所有交易数据失败: %v", err),
			})
			return
		}

		// 解析JSON结果
		if err := json.Unmarshal([]byte(result), &transactionsData); err != nil {
			c.JSON(200, gin.H{
				"code":    500,
				"message": fmt.Sprintf("解析所有交易数据失败: %v", err),
			})
			return
		}
	}

	// 转换交易数据
	startTimeObj := time.Now()
	transactions := []*fraud_detection.Transaction{}

	for _, txData := range transactionsData {
		// 解析时间
		timeStr, ok := txData["time"].(string)
		if !ok {
			continue
		}

		parsedTime, err := fraud_detection.ParseTime(timeStr)
		if err != nil {
			// 如果解析失败，使用当前时间
			parsedTime = time.Now()
		}

		tx := &fraud_detection.Transaction{
			ID:     toString(txData["id"]),
			From:   toString(txData["from"]),
			To:     toString(txData["to"]),
			Price:  toInt(txData["price"]),
			IsAuth: toBool(txData["is_auth"]),
			Txid:   toString(txData["txid"]),
			Time:   parsedTime,
		}
		transactions = append(transactions, tx)
	}

	// 执行刷单检测
	processingStart := time.Now()

	// 1. 检测高频交易
	highFreqThresholdInt := 10
	if highFreqThreshold != "" {
		fmt.Sscanf(highFreqThreshold, "%d", &highFreqThresholdInt)
	}
	highFreqUsers := fraud_detection.DetectHighFrequencyTrading(transactions, 60, highFreqThresholdInt) // 60分钟内

	// 2. 检测循环交易
	circularUsers := fraud_detection.DetectCircularTrading(transactions)

	// 合并可疑用户
	suspiciousUsersMap := make(map[string]*fraud_detection.SuspiciousUser)

	for _, user := range highFreqUsers {
		suspiciousUsersMap[user.UserID] = user
	}

	for _, user := range circularUsers {
		if existing, exists := suspiciousUsersMap[user.UserID]; exists {
			// 合并原因和分数
			existing.SuspicionScore = (existing.SuspicionScore + user.SuspicionScore) / 2
			existing.Reasons = append(existing.Reasons, user.Reasons...)
			existing.TransactionCount += user.TransactionCount
			existing.TotalAmount += user.TotalAmount
		} else {
			suspiciousUsersMap[user.UserID] = user
		}
	}

	// 转换为切片
	suspiciousUsers := []fraud_detection.SuspiciousUser{}
	for _, user := range suspiciousUsersMap {
		suspiciousUsers = append(suspiciousUsers, *user)
	}

	// 3. 社区检测（如果启用）
	var communities []fraud_detection.Community
	var communityMap map[string]int
	var totalNodes, totalEdges int

	if communityDetection == "true" {
		// 构建交易图
		graph := fraud_detection.BuildTransactionGraph(transactions)
		totalNodes = len(graph.Nodes)
		totalEdges = len(graph.Edges)

		// 检测社区
		communityMap = fraud_detection.DetectCommunitiesSimple(graph)
		communities = fraud_detection.CalculateCommunitySuspicion(communityMap, graph, transactions)
	} else {
		// 简单统计
		graph := fraud_detection.BuildTransactionGraph(transactions)
		totalNodes = len(graph.Nodes)
		totalEdges = len(graph.Edges)
		communityMap = make(map[string]int)
		communities = []fraud_detection.Community{}
	}

	// 统计风险分布
	highRiskCount, mediumRiskCount, lowRiskCount := 0, 0, 0
	for _, comm := range communities {
		if comm.SuspicionScore >= 70 {
			highRiskCount++
		} else if comm.SuspicionScore >= 40 {
			mediumRiskCount++
		} else {
			lowRiskCount++
		}
	}

	// 计算处理时间
	processingTime := time.Since(processingStart).Seconds()

	// 4. 提取可疑交易（含溯源码）
	suspiciousTransactions := extractSuspiciousTransactions(
		transactions, suspiciousUsersMap, communities, communityMap,
	)

	// 创建检测结果
	result := &fraud_detection.DetectionResult{
		Timestamp:              startTimeObj.Format("2006-01-02 15:04:05"),
		TotalNodes:             totalNodes,
		TotalEdges:             totalEdges,
		Communities:            communities,
		SuspiciousUsers:        suspiciousUsers,
		SuspiciousTransactions: suspiciousTransactions,
		ProcessingTime:         processingTime,
		TransactionCount:       len(transactions),
		HighRiskCount:          highRiskCount,
		MediumRiskCount:        mediumRiskCount,
		LowRiskCount:           lowRiskCount,
	}

	// 生成报告（传入交易数据用于详细分析）
	result.ReportSummary = fraud_detection.GenerateDetectionReportWithTx(result, transactions)

	// 保存结果到数据库
	detectionData := map[string]interface{}{
		"timestamp": result.Timestamp,
		"total_nodes": result.TotalNodes,
		"total_edges": result.TotalEdges,
		"transaction_count": result.TransactionCount,
		"high_risk_count": result.HighRiskCount,
		"medium_risk_count": result.MediumRiskCount,
		"low_risk_count": result.LowRiskCount,
		"processing_time": result.ProcessingTime,
		"report_summary": result.ReportSummary,
	}
	detectionId, err := pkg.InsertFraudDetectionResult(detectionData)
	if err == nil && detectionId > 0 {
		// 保存可疑用户
		suspiciousUsersData := []map[string]interface{}{}
		for _, user := range result.SuspiciousUsers {
			userData := map[string]interface{}{
				"user_id": user.UserID,
				"suspicion_score": user.SuspicionScore,
				"reasons": strings.Join(user.Reasons, ";"),
				"transaction_count": user.TransactionCount,
				"total_amount": user.TotalAmount,
				"last_active_time": user.LastActiveTime.Format("2006-01-02 15:04:05"),
			}
			suspiciousUsersData = append(suspiciousUsersData, userData)
		}
		if len(suspiciousUsersData) > 0 {
			pkg.InsertSuspiciousUsers(detectionId, suspiciousUsersData)
		}
		// 保存社区分析
		communitiesData := []map[string]interface{}{}
		for _, comm := range result.Communities {
			membersStr := strings.Join(comm.Members, ",")
			commData := map[string]interface{}{
				"community_id": comm.ID,
				"suspicion_score": comm.SuspicionScore,
				"members": membersStr,
				"real_buyers": comm.RealBuyers,
				"fraud_buyers": comm.FraudBuyers,
				"honest_sellers": comm.HonestSellers,
				"fraud_sellers": comm.FraudSellers,
				"avg_rating": comm.AvgRating,
				"fraud_ratio": comm.FraudRatio,
				"transaction_count": comm.TransactionCount,
				"total_amount": comm.TotalAmount,
			}
			communitiesData = append(communitiesData, commData)
		}
		if len(communitiesData) > 0 {
			pkg.InsertFraudCommunities(detectionId, communitiesData)
		}
	}

	c.JSON(200, gin.H{
		"code":    200,
		"message": "刷单检测完成",
		"data":    result,
	})
}

// GetDetectionReport 获取最新的检测报告
func GetDetectionReport(c *gin.Context) {
	// 从数据库获取最新的检测报告
	result, err := pkg.GetLatestDetectionResult()
	if err != nil || result == nil {
		// 没有检测记录，返回空数据
		c.JSON(200, gin.H{
			"code": 200,
			"message": "暂无检测报告",
			"data": gin.H{},
		})
		return
	}

	// 获取可疑用户和社区分析
	detectionId := result["id"].(int64)
	suspiciousUsers, _ := pkg.GetSuspiciousUsersByDetectionId(detectionId)
	communities, _ := pkg.GetCommunitiesByDetectionId(detectionId)

	c.JSON(200, gin.H{
		"code": 200,
		"message": "获取检测报告成功",
		"data": gin.H{
			"detection_result": result,
			"suspicious_users": suspiciousUsers,
			"communities": communities,
		},
	})
}

// GetSuspiciousUsers 获取可疑用户列表
func GetSuspiciousUsers(c *gin.Context) {
	// 获取最新检测结果
	result, err := pkg.GetLatestDetectionResult()
	if err != nil || result == nil {
		// 没有检测记录，返回空数组
		c.JSON(200, gin.H{
			"code":    200,
			"message": "暂无检测数据",
			"data":    []gin.H{},
		})
		return
	}

	// 获取可疑用户
	detectionId := result["id"].(int64)
	suspiciousUsersData, err := pkg.GetSuspiciousUsersByDetectionId(detectionId)
	if err != nil {
		suspiciousUsersData = []map[string]interface{}{}
	}

	// 转换为前端需要的格式
	suspiciousUsers := []gin.H{}
	for _, user := range suspiciousUsersData {
		suspiciousUsers = append(suspiciousUsers, gin.H{
			"user_id":       user["user_id"],
			"score":         user["suspicion_score"],
			"reasons":       strings.Split(user["reasons"].(string), ";"),
			"tx_count":      user["transaction_count"],
			"total_amount":  user["total_amount"],
		})
	}

	c.JSON(200, gin.H{
		"code":    200,
		"message": "获取可疑用户列表成功",
		"data":    suspiciousUsers,
	})
}

// GetCommunityAnalysis 获取社区分析结果
func GetCommunityAnalysis(c *gin.Context) {
	// 获取最新检测结果
	result, err := pkg.GetLatestDetectionResult()
	if err != nil || result == nil {
		// 没有检测记录，返回空数组
		c.JSON(200, gin.H{
			"code":    200,
			"message": "暂无检测数据",
			"data":    []gin.H{},
		})
		return
	}

	// 获取社区分析
	detectionId := result["id"].(int64)
	communitiesData, err := pkg.GetCommunitiesByDetectionId(detectionId)
	if err != nil {
		communitiesData = []map[string]interface{}{}
	}

	// 转换为前端需要的格式
	communities := []gin.H{}
	for _, comm := range communitiesData {
		// 计算风险等级
		riskLevel := "low"
		score := comm["suspicion_score"].(float64)
		if score >= 70 {
			riskLevel = "high"
		} else if score >= 40 {
			riskLevel = "medium"
		}

		communities = append(communities, gin.H{
			"id":           comm["community_id"],
			"score":        score,
			"members":      len(strings.Split(comm["members"].(string), ",")),
			"buyers":       comm["real_buyers"],
			"sellers":      comm["honest_sellers"],
			"tx_count":     comm["transaction_count"],
			"total_amount": comm["total_amount"],
			"risk_level":   riskLevel,
		})
	}

	c.JSON(200, gin.H{
		"code":    200,
		"message": "获取社区分析成功",
		"data":    communities,
	})
}

// MarkUserAsSuspicious 手动标记用户为可疑
func MarkUserAsSuspicious(c *gin.Context) {
	userID := c.PostForm("user_id")
	reason := c.PostForm("reason")

	if userID == "" {
		c.JSON(200, gin.H{
			"code":    400,
			"message": "用户ID不能为空",
		})
		return
	}

	if reason == "" {
		reason = "手动标记"
	}

	// TODO: 保存到数据库

	c.JSON(200, gin.H{
		"code":    200,
		"message": fmt.Sprintf("用户 %s 已标记为可疑，原因: %s", userID, reason),
	})
}

// 辅助函数
func toString(value interface{}) string {
	if str, ok := value.(string); ok {
		return str
	}
	return ""
}

func toInt(value interface{}) int {
	switch v := value.(type) {
	case float64:
		return int(v)
	case int:
		return v
	case int32:
		return int(v)
	case int64:
		return int(v)
	default:
		return 0
	}
}

// GetFraudStats 获取刷单检测统计信息
func GetFraudStats(c *gin.Context) {
	// 获取最新的检测结果
	result, err := pkg.GetLatestDetectionResult()
	if err != nil || result == nil {
		c.JSON(200, gin.H{
			"code":    200,
			"message": "暂无检测数据",
			"data": gin.H{
				"total_detections":   0,
				"total_suspicious":   0,
				"high_risk_count":    0,
				"medium_risk_count":  0,
				"low_risk_count":     0,
				"last_detection":     nil,
			},
		})
		return
	}

	// 获取所有历史检测次数
	historyCount, _ := pkg.GetDetectionHistoryCount()

	// 获取可疑用户总数
	suspiciousCount, _ := pkg.GetTotalSuspiciousCount()

	c.JSON(200, gin.H{
		"code":    200,
		"message": "获取统计信息成功",
		"data": gin.H{
			"total_detections":   historyCount,
			"total_suspicious":   suspiciousCount,
			"high_risk_count":    result["high_risk_count"],
			"medium_risk_count":  result["medium_risk_count"],
			"low_risk_count":     result["low_risk_count"],
			"last_detection":     result,
		},
	})
}

// GetDetectionHistory 获取历史检测记录
func GetDetectionHistory(c *gin.Context) {
	results, err := pkg.GetAllDetectionResults()
	if err != nil {
		c.JSON(200, gin.H{
			"code":    500,
			"message": fmt.Sprintf("获取历史记录失败: %v", err),
			"data":    []gin.H{},
		})
		return
	}
	if results == nil {
		results = []map[string]interface{}{}
	}

	c.JSON(200, gin.H{
		"code":    200,
		"message": "获取历史记录成功",
		"data":    results,
	})
}

// ClearSuspiciousMark 清除可疑用户标记
func ClearSuspiciousMark(c *gin.Context) {
	userID := c.PostForm("user_id")
	if userID == "" {
		c.JSON(200, gin.H{
			"code":    400,
			"message": "用户ID不能为空",
		})
		return
	}

	err := pkg.DeleteSuspiciousMark(userID)
	if err != nil {
		c.JSON(200, gin.H{
			"code":    500,
			"message": fmt.Sprintf("清除标记失败: %v", err),
		})
		return
	}

	c.JSON(200, gin.H{
		"code":    200,
		"message": fmt.Sprintf("用户 %s 的可疑标记已清除", userID),
	})
}

func toBool(value interface{}) bool {
	if b, ok := value.(bool); ok {
		return b
	}
	return false
}

// extractSuspiciousTransactions 从检测结果中提取可疑交易列表（含溯源码）
func extractSuspiciousTransactions(
	transactions []*fraud_detection.Transaction,
	suspiciousUsersMap map[string]*fraud_detection.SuspiciousUser,
	communities []fraud_detection.Community,
	communityMap map[string]int,
) []fraud_detection.SuspiciousTransaction {
	suspiciousTxMap := make(map[string]*fraud_detection.SuspiciousTransaction)

	// 构建高风险社区成员集合
	highRiskMembers := make(map[string]bool)
	highRiskCommIDs := make(map[int]bool)
	for _, comm := range communities {
		if comm.SuspicionScore >= 40 { // 中高风险社区
			highRiskCommIDs[comm.ID] = true
			for _, member := range comm.Members {
				highRiskMembers[member] = true
			}
		}
	}

	// 构建可疑用户集合
	suspiciousUserSet := make(map[string]*fraud_detection.SuspiciousUser)
	for _, user := range suspiciousUsersMap {
		suspiciousUserSet[user.UserID] = user
	}

	// 筛选可疑交易
	for _, tx := range transactions {
		isSuspicious := false
		var riskReasons []string
		riskScore := 0.0

		// 检查交易双方是否在可疑用户列表中
		if su, ok := suspiciousUserSet[tx.From]; ok {
			isSuspicious = true
			riskScore = su.SuspicionScore
			riskReasons = append(riskReasons, su.Reasons...)
		}
		if su, ok := suspiciousUserSet[tx.To]; ok {
			isSuspicious = true
			if su.SuspicionScore > riskScore {
				riskScore = su.SuspicionScore
			}
			riskReasons = append(riskReasons, su.Reasons...)
		}

		// 检查交易双方是否在高风险社区中
		if highRiskMembers[tx.From] || highRiskMembers[tx.To] {
			isSuspicious = true
			if riskScore < 50 {
				riskScore = 50
			}
			riskReasons = append(riskReasons, "高风险社区成员交易")
		}

		// 检查社区内交易
		if fromComm, fromOk := communityMap[tx.From]; fromOk {
			if toComm, toOk := communityMap[tx.To]; toOk {
				if fromComm == toComm && highRiskCommIDs[fromComm] {
					isSuspicious = true
					if riskScore < 60 {
						riskScore = 60
					}
					riskReasons = append(riskReasons,
						fmt.Sprintf("高风险社区 %d 内部交易", fromComm))
				}
			}
		}

		if isSuspicious {
			// 去重（同一笔交易的溯源码唯一）
			key := tx.Txid
			if key == "" {
				key = fmt.Sprintf("%s-%s-%d", tx.From, tx.To, tx.Price)
			}

			if existing, ok := suspiciousTxMap[key]; ok {
				// 更新风险评分（取最高）
				if riskScore > existing.RiskScore {
					existing.RiskScore = riskScore
				}
				existing.RiskReasons = append(existing.RiskReasons, riskReasons...)
			} else {
				commID := 0
				if cid, ok := communityMap[tx.From]; ok {
					commID = cid
				}

				suspiciousTxMap[key] = &fraud_detection.SuspiciousTransaction{
					TxID:        tx.Txid,
					AssetID:     tx.ID,
					From:        tx.From,
					To:          tx.To,
					Price:       tx.Price,
					Time:        tx.Time.Format("2006-01-02 15:04:05"),
					RiskScore:   riskScore,
					RiskReasons: riskReasons,
					CommunityID: commID,
				}
			}
		}
	}

	// 转换为切片并按风险评分降序排列
	result := make([]fraud_detection.SuspiciousTransaction, 0, len(suspiciousTxMap))
	for _, tx := range suspiciousTxMap {
		result = append(result, *tx)
	}

	sort.Slice(result, func(i, j int) bool {
		return result[i].RiskScore > result[j].RiskScore
	})

	return result
}