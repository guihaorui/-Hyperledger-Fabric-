package controller

import (
	"backend/pkg"
	"fmt"

	"github.com/gin-gonic/gin"
)

// 转账
func Transfer(c *gin.Context) {
	// 获取用户ID
	from, exist := c.Get("userID")
	if !exist {
		c.JSON(200, gin.H{
			"message": "获取用户ID失败",
		})
		return
	}
	// 获取接收方地址
	to := c.PostForm("to")
	// 获取转账金额
	amount := c.PostForm("amount")

	// 构建上链args
	args := []string{
		from.(string),
		to,
		amount,
	}
	if len(args) == 0 {
		c.JSON(200, gin.H{
			"message": "args is empty",
		})
		return
	}
	_, err := pkg.ChaincodeInvoke("Transfer", args)
	if err != nil {
		c.JSON(200, gin.H{
			"message": "转账失败，检查余额与对方ID是否正确！",
		})
		return
	}
	c.JSON(200, gin.H{
		"code":    200,
		"message": "transfer success",
	})
}

// 购买资产
func BuyAsset(c *gin.Context) {
	// 获取用户ID
	userID, exist := c.Get("userID")
	if !exist {
		c.JSON(200, gin.H{
			"message": "获取用户ID失败",
		})
		return
	}

	// 获取资产ID
	assetID := c.PostForm("assetID")
	// 获取是否租赁
	is_auth := c.PostForm("is_auth")
	fmt.Printf("assetID: %s, is_auth: %s\n", assetID, is_auth)
	// 构建上链args
	args := []string{
		userID.(string),
		assetID,
		is_auth,
	}
	if len(args) == 0 {
		c.JSON(200, gin.H{
			"message": "args is empty",
		})
		return
	}
	_, err := pkg.ChaincodeInvoke("Buy", args)
	if err != nil {
		c.JSON(200, gin.H{
			"message": "购买失败，检查权限与余额！",
		})
		return
	}
	c.JSON(200, gin.H{
		"code":    200,
		"message": "buy asset success",
	})
}

// 获取用户余额变动流水
func GetBalanceRecords(c *gin.Context) {
	userID, exist := c.Get("userID")
	if !exist {
		c.JSON(200, gin.H{
			"message": "获取用户ID失败",
		})
		return
	}

	res, err := pkg.ChaincodeQuery("GetBalanceRecords", userID.(string))
	if err != nil {
		c.JSON(200, gin.H{
			"message": "获取余额流水失败：" + err.Error(),
		})
		return
	}

	c.JSON(200, gin.H{
		"code":    200,
		"message": "查询成功",
		"records": res,
	})
}
