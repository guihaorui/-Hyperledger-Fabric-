package controller

import (
	"backend/pkg"
	"strconv"

	"github.com/gin-gonic/gin"
)

// 质押代币
func StakeTokens(c *gin.Context) {
	userID, exist := c.Get("userID")
	if !exist {
		c.JSON(200, gin.H{
			"message": "获取用户ID失败",
		})
		return
	}

	// 调用链码质押函数
	res, err := pkg.ChaincodeInvoke("StakeTokens", []string{userID.(string)})
	if err != nil {
		c.JSON(200, gin.H{
			"message": "质押失败：" + err.Error(),
		})
		return
	}

	c.JSON(200, gin.H{
		"code":    200,
		"message": "质押成功",
		"txid":    res,
	})
}

// 解押代币
func UnstakeTokens(c *gin.Context) {
	userID, exist := c.Get("userID")
	if !exist {
		c.JSON(200, gin.H{
			"message": "获取用户ID失败",
		})
		return
	}

	// 调用链码解押函数
	res, err := pkg.ChaincodeInvoke("UnstakeTokens", []string{userID.(string)})
	if err != nil {
		c.JSON(200, gin.H{
			"message": "解押失败：" + err.Error(),
		})
		return
	}

	c.JSON(200, gin.H{
		"code":    200,
		"message": "解押成功",
		"txid":    res,
	})
}

// 检查质押状态
func CheckStakeStatus(c *gin.Context) {
	userID, exist := c.Get("userID")
	if !exist {
		c.JSON(200, gin.H{
			"message": "获取用户ID失败",
		})
		return
	}

	// 调用链码检查质押状态
	res, err := pkg.ChaincodeQuery("CheckStakeStatus", userID.(string))
	if err != nil {
		c.JSON(200, gin.H{
			"message": "查询质押状态失败：" + err.Error(),
		})
		return
	}

	c.JSON(200, gin.H{
		"code":    200,
		"message": "查询成功",
		"status":  res,
	})
}

// 获取质押记录
func GetStakeRecords(c *gin.Context) {
	userID, exist := c.Get("userID")
	if !exist {
		c.JSON(200, gin.H{
			"message": "获取用户ID失败",
		})
		return
	}

	// 调用链码获取质押记录
	res, err := pkg.ChaincodeQuery("GetStakeRecords", userID.(string))
	if err != nil {
		c.JSON(200, gin.H{
			"message": "获取质押记录失败：" + err.Error(),
		})
		return
	}

	c.JSON(200, gin.H{
		"code":    200,
		"message": "查询成功",
		"records": res,
	})
}

// 获取用户信誉分
func GetReputation(c *gin.Context) {
	userID, exist := c.Get("userID")
	if !exist {
		c.JSON(200, gin.H{
			"message": "获取用户ID失败",
		})
		return
	}

	// 调用链码获取信誉分
	res, err := pkg.ChaincodeQuery("GetReputation", userID.(string))
	if err != nil {
		c.JSON(200, gin.H{
			"message": "获取信誉分失败：" + err.Error(),
		})
		return
	}

	// 解析信誉分（链码返回的是字符串）
	reputation, err := strconv.ParseFloat(res, 64)
	if err != nil {
		c.JSON(200, gin.H{
			"message": "解析信誉分失败：" + err.Error(),
		})
		return
	}

	c.JSON(200, gin.H{
		"code":        200,
		"message":     "查询成功",
		"reputation":  reputation,
	})
}

// 重新计算信誉分（管理员功能）
func CalculateReputation(c *gin.Context) {
	userID := c.PostForm("userID")
	if userID == "" {
		c.JSON(200, gin.H{
			"message": "用户ID不能为空",
		})
		return
	}

	// 调用链码重新计算信誉分
	res, err := pkg.ChaincodeInvoke("CalculateReputation", []string{userID})
	if err != nil {
		c.JSON(200, gin.H{
			"message": "重新计算信誉分失败：" + err.Error(),
		})
		return
	}

	// 解析结果
	reputation, err := strconv.ParseFloat(res, 64)
	if err != nil {
		c.JSON(200, gin.H{
			"message": "解析信誉分失败：" + err.Error(),
		})
		return
	}

	c.JSON(200, gin.H{
		"code":        200,
		"message":     "重新计算成功",
		"reputation":  reputation,
	})
}