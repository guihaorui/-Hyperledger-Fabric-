package controller

import (
	"backend/pkg"
	"strconv"

	"github.com/gin-gonic/gin"
)

// 审核资产
func AuditAsset(c *gin.Context) {
	userID, exist := c.Get("userID")
	if !exist {
		c.JSON(200, gin.H{
			"message": "获取用户ID失败",
		})
		return
	}

	assetID := c.PostForm("assetID")
	action := c.PostForm("action") // approve/reject

	if assetID == "" {
		c.JSON(200, gin.H{
			"message": "资产ID不能为空",
		})
		return
	}

	if action != "approve" && action != "reject" {
		c.JSON(200, gin.H{
			"message": "action必须是approve或reject",
		})
		return
	}

	// 调用链码审核资产
	res, err := pkg.ChaincodeInvoke("AuditAsset", []string{assetID, userID.(string), action})
	if err != nil {
		c.JSON(200, gin.H{
			"message": "审核失败：" + err.Error(),
		})
		return
	}

	c.JSON(200, gin.H{
		"code":    200,
		"message": "审核成功",
		"txid":    res,
	})
}

// 获取待审核资产列表
func GetPendingAssets(c *gin.Context) {
	_, exist := c.Get("userID")
	if !exist {
		c.JSON(200, gin.H{
			"message": "获取用户ID失败",
		})
		return
	}

	// 可选：检查用户是否是监督审查者
	// 这里简化，直接调用链码

	res, err := pkg.ChaincodeQuery("GetPendingAssets", "")
	if err != nil {
		c.JSON(200, gin.H{
			"message": "获取待审核资产列表失败：" + err.Error(),
		})
		return
	}

	c.JSON(200, gin.H{
		"code":    200,
		"message": "获取成功",
		"data":    res,
	})
}

// 更新资产优先级（例如评分变化后）
func UpdateAssetPriority(c *gin.Context) {
	assetID := c.PostForm("assetID")
	priorityStr := c.PostForm("priority")

	if assetID == "" || priorityStr == "" {
		c.JSON(200, gin.H{
			"message": "资产ID和优先级不能为空",
		})
		return
	}

	// 验证优先级是否为有效数字
	_, err := strconv.ParseFloat(priorityStr, 64)
	if err != nil {
		c.JSON(200, gin.H{
			"message": "优先级必须是数字",
		})
		return
	}

	// 调用链码更新优先级
	res, err := pkg.ChaincodeInvoke("UpdateAssetPriority", []string{assetID, priorityStr})
	if err != nil {
		c.JSON(200, gin.H{
			"message": "更新优先级失败：" + err.Error(),
		})
		return
	}

	c.JSON(200, gin.H{
		"code":    200,
		"message": "更新优先级成功",
		"txid":    res,
	})
}

// 获取审核激励记录（可选）
func GetAuditRewards(c *gin.Context) {
	_, exist := c.Get("userID")
	if !exist {
		c.JSON(200, gin.H{
			"message": "获取用户ID失败",
		})
		return
	}

	// 需要实现链码函数来查询用户的审核激励记录
	// 暂时返回空
	c.JSON(200, gin.H{
		"code":    200,
		"message": "获取成功",
		"data":    []interface{}{},
	})
}